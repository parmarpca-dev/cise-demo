<?php
/**
 * Template helpers.
 *
 * @package cise
 */

defined( 'ABSPATH' ) || exit;

/**
 * Default values for every Customizer setting. Templates read through cise_mod()
 * so the site looks complete before anyone opens the Customizer.
 */
function cise_defaults() {
	return array(
		'address'          => '9504 37 Avenue, Edmonton, AB T6E 5K3',
		'venue_name'       => 'India Centre',
		'email'            => 'cise@ciseedmonton.com',
		'phone'            => '780-436-5367',
		'office_hours'     => 'Saturdays, 11 am to 2 pm',
		'facebook'         => 'https://www.facebook.com/profile.php?id=100009578860668',
		'member_login_url' => '',
		'founded'          => '1976',
		'footer_blurb'     => 'Council of India Societies of Edmonton. A not-for-profit umbrella organization representing Indo-Canadians in Edmonton since 1976.',

		'hero_badge'       => 'Golden Jubilee: 50 years of unity in diversity, 1976–2026',
		'hero_title'       => 'Welcome To Council of India Societies of Edmonton',
		'hero_lead'        => 'CISE brings member associations together through celebrations, community programs and the India Centre in Mill Woods — a place for classes, rehearsals, meetings and gatherings all year round.',
		'hero_image_1'     => get_theme_file_uri( 'assets/starter/legislature.jpg' ),
		'hero_image_2'     => get_theme_file_uri( 'assets/starter/india-day.jpg' ),

		'wwd_title'        => 'An umbrella for the whole community',
		'wwd_1_title'      => 'Celebrations',
		'wwd_1_text'       => 'India (Republic) Day, Canada Day, Independence Day and the India pavilion at Heritage Festival, with our member associations.',
		'wwd_2_title'      => 'Consular Camp',
		'wwd_2_text'       => 'Officers from the Consulate General of India in Vancouver come to the India Centre each November for life certificate attestation.',
		'wwd_3_title'      => 'India Day Award',
		'wwd_3_text'       => 'Republic Day celebration with cultural programs, dignitaries and academic excellence awards for students.',
		'wwd_4_title'      => 'Hall booking',
		'wwd_4_text'       => 'The Main Hall and Basement for classes, AGMs, cultural events, family celebrations and festival gatherings.',

		'hall_title'       => 'Book the hall for your next event',
		'hall_text'        => 'Check open dates, send your event details and hold your date online. Member societies receive discounted rates.',
		'hall_image'       => get_theme_file_uri( 'assets/starter/hall.jpg' ),

		'gi_1_title'       => 'Youth Wing',
		'gi_1_text'        => 'High school and university students building leadership, cultural pride and community service.',
		'gi_2_title'       => "Women's Wing",
		'gi_2_text'        => 'Together we rise: education, mentorship and a supportive community for women.',
		'gi_3_title'       => 'Library',
		'gi_3_text'        => 'A reading room at the India Centre, plus information on Canada, India and grants.',
		'gi_4_title'       => 'Member associations',
		'gi_4_text'        => 'Twenty societies under the CISE umbrella. See them all, or apply to join.',
	);
}

/**
 * Read a Customizer value, falling back to the default.
 */
function cise_mod( $key ) {
	$defaults = cise_defaults();
	$value    = get_theme_mod( 'cise_' . $key, null );
	if ( null === $value || '' === $value ) {
		return isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	}
	return $value;
}

/**
 * Read a setting owned by the CISE Core plugin (hall rates, award dates…).
 */
function cise_setting( $key, $default = '' ) {
	if ( function_exists( 'cise_core_get' ) ) {
		$value = cise_core_get( $key );
		if ( '' !== $value && null !== $value ) {
			return $value;
		}
	}
	return $default;
}

/**
 * URL of a page by slug (falls back to home + slug).
 */
function cise_page_url( $slug ) {
	$page = get_page_by_path( $slug );
	return $page ? get_permalink( $page ) : home_url( '/' . $slug . '/' );
}

/**
 * Photo block: an image if one is set, otherwise a labelled placeholder.
 *
 * @param int|string $image Attachment ID or URL.
 */
function cise_photo( $image, $label, $class = '' ) {
	$html = '';
	if ( $image ) {
		if ( is_numeric( $image ) ) {
			$html = wp_get_attachment_image( (int) $image, 'large', false, array( 'alt' => $label, 'loading' => 'lazy' ) );
		} else {
			$html = sprintf( '<img src="%s" alt="%s" loading="lazy">', esc_url( $image ), esc_attr( $label ) );
		}
	}
	if ( ! $html ) {
		$html = '<span class="photo__label">[' . esc_html__( 'Photo:', 'cise' ) . ' ' . esc_html( $label ) . ']</span>';
	}
	printf( '<div class="photo %s">%s</div>', esc_attr( $class ), $html ); // phpcs:ignore WordPress.Security.EscapeOutput
}

/**
 * Inline SVG icons (stroke style, inherits currentColor).
 */
function cise_icon( $name ) {
	$paths = array(
		'people'   => '<circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5"/><circle cx="17" cy="9" r="2.5"/><path d="M16 14.2c2.4.1 4 1.7 4.5 4.3"/>',
		'document' => '<rect x="5" y="3.5" width="14" height="17" rx="2"/><path d="M8.5 8h7M8.5 12h7M8.5 16h4"/>',
		'award'    => '<circle cx="12" cy="9" r="5"/><path d="M9 13.5 8 20.5l4-2 4 2-1-7"/>',
		'home'     => '<path d="M4 11 12 4l8 7"/><path d="M6 9.5V20h12V9.5"/><path d="M10 20v-5h4v5"/>',
		'upload'   => '<path d="M12 15V4"/><path d="m7.5 8.5 4.5-4.5 4.5 4.5"/><path d="M5 15v4h14v-4"/>',
	);
	if ( ! isset( $paths[ $name ] ) ) {
		return '';
	}
	return '<svg class="card__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $paths[ $name ] . '</svg>';
}

/**
 * Date badge parts for an event post: array( month, day ) or ( month, 'TBC' ).
 */
function cise_event_badge( $post_id ) {
	$date = get_post_meta( $post_id, '_cise_event_date', true );
	$tbc  = get_post_meta( $post_id, '_cise_event_tbc', true );
	if ( ! $date ) {
		return array( '', 'TBC' );
	}
	$ts = strtotime( $date );
	return array( date_i18n( 'M', $ts ), $tbc ? 'TBC' : date_i18n( 'j', $ts ) );
}

/**
 * Human date line for an event ("February 14, 2027" / "November 2026 · date TBC").
 */
function cise_event_date_text( $post_id ) {
	$date = get_post_meta( $post_id, '_cise_event_date', true );
	if ( ! $date ) {
		return __( 'Date to be confirmed', 'cise' );
	}
	$ts = strtotime( $date );
	if ( get_post_meta( $post_id, '_cise_event_tbc', true ) ) {
		/* translators: %s: month and year */
		return sprintf( __( '%s · date TBC', 'cise' ), date_i18n( 'F Y', $ts ) );
	}
	return date_i18n( get_option( 'date_format' ), $ts );
}

/**
 * Upcoming events (needs the CISE Core plugin's Event post type).
 */
function cise_upcoming_events( $count = 3 ) {
	if ( ! post_type_exists( 'cise_event' ) ) {
		return array();
	}
	return get_posts( array(
		'post_type'      => 'cise_event',
		'posts_per_page' => $count,
		'meta_key'       => '_cise_event_date',
		'orderby'        => 'meta_value',
		'order'          => 'ASC',
		'meta_query'     => array(
			array(
				'key'     => '_cise_event_date',
				'value'   => wp_date( 'Y-m-01' ),
				'compare' => '>=',
				'type'    => 'DATE',
			),
		),
	) );
}

/**
 * Yearly celebrations as array of [name, when].
 */
function cise_yearly_celebrations() {
	$raw = cise_setting( 'yearly_celebrations', "India (Republic) Day|February\nInternational Yoga Day|June 21\nCanada Day|July 1\nSummer Camp|July\nHeritage Festival|August long weekend\nIndia (Independence) Day|August 15\nHindi Divas|September 14\nGandhi Jayanti|October 2\nConsular Camp|November" );
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
		$parts = array_map( 'trim', explode( '|', $line ) );
		if ( '' !== $parts[0] ) {
			$out[] = array( $parts[0], isset( $parts[1] ) ? $parts[1] : '' );
		}
	}
	return $out;
}

/**
 * Page hero used by inner pages.
 */
function cise_page_hero( $title, $lead = '', $badge = '' ) {
	?>
	<section class="page-hero">
		<div class="wrap">
			<a class="back-link" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'cise' ); ?></a>
			<?php if ( $badge ) : ?>
				<div style="margin-top:14px"><span class="pill"><?php echo esc_html( $badge ); ?></span></div>
			<?php endif; ?>
			<h1><?php echo esc_html( $title ); ?></h1>
			<?php if ( $lead ) : ?>
				<p><?php echo wp_kses_post( $lead ); ?></p>
			<?php endif; ?>
		</div>
	</section>
	<?php
}

/**
 * Lead line for a page: its manual excerpt if set.
 */
function cise_page_lead( $post = null ) {
	$post = get_post( $post );
	return ( $post && has_excerpt( $post ) ) ? get_the_excerpt( $post ) : '';
}

/**
 * Notice shown when the CISE Core plugin is missing.
 */
function cise_needs_plugin_notice( $what ) {
	if ( current_user_can( 'activate_plugins' ) ) {
		/* translators: %s: feature name */
		printf( '<div class="notice notice--warn">%s</div>', esc_html( sprintf( __( 'Activate the CISE Core plugin to show the %s here.', 'cise' ), $what ) ) );
	}
}

/**
 * Menu shown before a menu is assigned.
 */
function cise_menu_fallback() {
	$links = array(
		'about'             => __( 'About', 'cise' ),
		'events'            => __( 'Events', 'cise' ),
		'recognition-award' => __( 'Recognition Award', 'cise' ),
		'community'         => __( 'Community', 'cise' ),
		'gallery'           => __( 'Gallery', 'cise' ),
		'resources'         => __( 'Resources', 'cise' ),
		'contact'           => __( 'Contact', 'cise' ),
	);
	echo '<ul>';
	foreach ( $links as $slug => $label ) {
		printf( '<li><a href="%s">%s</a></li>', esc_url( cise_page_url( $slug ) ), esc_html( $label ) );
	}
	echo '</ul>';
}
