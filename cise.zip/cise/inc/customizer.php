<?php
/**
 * Customizer: contact details and homepage text/photos.
 *
 * @package cise
 */

defined( 'ABSPATH' ) || exit;

add_action( 'customize_register', function ( WP_Customize_Manager $wp_customize ) {
	$d = cise_defaults();

	$wp_customize->add_panel( 'cise', array(
		'title'    => __( 'CISE site options', 'cise' ),
		'priority' => 30,
	) );

	$sections = array(
		'cise_contact' => array(
			'title'  => __( 'Contact & footer', 'cise' ),
			'fields' => array(
				'venue_name'       => array( __( 'Venue name', 'cise' ), 'text' ),
				'address'          => array( __( 'Address', 'cise' ), 'text' ),
				'email'            => array( __( 'Email', 'cise' ), 'email' ),
				'phone'            => array( __( 'Phone (optional)', 'cise' ), 'text' ),
				'office_hours'     => array( __( 'Office hours (optional)', 'cise' ), 'text' ),
				'facebook'         => array( __( 'Facebook page URL', 'cise' ), 'url' ),
				'member_login_url' => array( __( 'Member login URL (blank = WordPress login)', 'cise' ), 'url' ),
				'founded'          => array( __( 'Founded (year)', 'cise' ), 'text' ),
				'footer_blurb'     => array( __( 'Footer description', 'cise' ), 'textarea' ),
			),
		),
		'cise_hero'    => array(
			'title'  => __( 'Homepage: top banner', 'cise' ),
			'fields' => array(
				'hero_badge'   => array( __( 'Small badge text', 'cise' ), 'text' ),
				'hero_title'   => array( __( 'Headline', 'cise' ), 'text' ),
				'hero_lead'    => array( __( 'Intro paragraph', 'cise' ), 'textarea' ),
				'hero_image_1' => array( __( 'Large photo (e.g. India Day crowd)', 'cise' ), 'image' ),
				'hero_image_2' => array( __( 'Small photo (e.g. dance performance)', 'cise' ), 'image' ),
			),
		),
		'cise_wwd'     => array(
			'title'  => __( 'Homepage: what we do', 'cise' ),
			'fields' => array(
				'wwd_title'   => array( __( 'Section headline', 'cise' ), 'text' ),
				'wwd_1_title' => array( __( 'Card 1 title', 'cise' ), 'text' ),
				'wwd_1_text'  => array( __( 'Card 1 text', 'cise' ), 'textarea' ),
				'wwd_2_title' => array( __( 'Card 2 title', 'cise' ), 'text' ),
				'wwd_2_text'  => array( __( 'Card 2 text', 'cise' ), 'textarea' ),
				'wwd_3_title' => array( __( 'Card 3 title', 'cise' ), 'text' ),
				'wwd_3_text'  => array( __( 'Card 3 text', 'cise' ), 'textarea' ),
				'wwd_4_title' => array( __( 'Card 4 title', 'cise' ), 'text' ),
				'wwd_4_text'  => array( __( 'Card 4 text', 'cise' ), 'textarea' ),
			),
		),
		'cise_hall'    => array(
			'title'  => __( 'Homepage: hall booking', 'cise' ),
			'fields' => array(
				'hall_title' => array( __( 'Headline', 'cise' ), 'text' ),
				'hall_text'  => array( __( 'Text', 'cise' ), 'textarea' ),
				'hall_image' => array( __( 'Hall photo', 'cise' ), 'image' ),
			),
		),
		'cise_gi'      => array(
			'title'  => __( 'Homepage: get involved', 'cise' ),
			'fields' => array(
				'gi_1_title' => array( __( 'Card 1 title', 'cise' ), 'text' ),
				'gi_1_text'  => array( __( 'Card 1 text', 'cise' ), 'textarea' ),
				'gi_2_title' => array( __( 'Card 2 title', 'cise' ), 'text' ),
				'gi_2_text'  => array( __( 'Card 2 text', 'cise' ), 'textarea' ),
				'gi_3_title' => array( __( 'Card 3 title', 'cise' ), 'text' ),
				'gi_3_text'  => array( __( 'Card 3 text', 'cise' ), 'textarea' ),
				'gi_4_title' => array( __( 'Card 4 title', 'cise' ), 'text' ),
				'gi_4_text'  => array( __( 'Card 4 text', 'cise' ), 'textarea' ),
			),
		),
	);

	foreach ( $sections as $section_id => $section ) {
		$wp_customize->add_section( $section_id, array(
			'title' => $section['title'],
			'panel' => 'cise',
		) );
		foreach ( $section['fields'] as $key => $field ) {
			list( $label, $type ) = $field;
			$id = 'cise_' . $key;

			$sanitize = 'sanitize_text_field';
			if ( 'textarea' === $type ) {
				$sanitize = 'sanitize_textarea_field';
			} elseif ( 'url' === $type || 'image' === $type ) {
				$sanitize = 'esc_url_raw';
			} elseif ( 'email' === $type ) {
				$sanitize = 'sanitize_email';
			}

			$wp_customize->add_setting( $id, array(
				'default'           => 'image' === $type ? '' : ( isset( $d[ $key ] ) ? $d[ $key ] : '' ),
				'sanitize_callback' => $sanitize,
			) );

			if ( 'image' === $type ) {
				$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, $id, array(
					'label'   => $label,
					'section' => $section_id,
				) ) );
			} else {
				$wp_customize->add_control( $id, array(
					'label'   => $label,
					'section' => $section_id,
					'type'    => $type,
				) );
			}
		}
	}
} );
