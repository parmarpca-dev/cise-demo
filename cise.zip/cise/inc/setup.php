<?php
/**
 * One-time site setup: creates the pages and menus the design needs.
 *
 * Runs when the theme is activated and can be re-run from Appearance > CISE setup.
 * It never overwrites or deletes anything: pages whose slug already exists are
 * reused as they are, and existing menus are left alone. Starter events, sponsors
 * and news posts (taken from the previous ciseedmonton.com) are only added when
 * none exist yet.
 *
 * @package cise
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pages the theme expects, keyed by slug.
 *
 * @param array $files Starter media from cise_setup_media(): key => array( id, url ).
 */
function cise_setup_pages( $files ) {
	return array(
		'home'              => array( 'title' => 'Home', 'content' => '', 'excerpt' => '' ),
		'about'             => array(
			'title'   => 'About CISE',
			'excerpt' => 'CISE is a not-for-profit umbrella organization representing Indo-Canadians in Edmonton and the surrounding area since 1976.',
			'content' => cise_starter_about( $files ),
		),
		'events'            => array(
			'title'   => 'Events',
			'excerpt' => 'Celebrations, camps and community gatherings at the India Centre and around Edmonton, all year round.',
			'content' => '<!-- wp:paragraph --><p>Everyone is welcome at CISE events. Follow us on Facebook for program details and timely updates. Member societies can request the hall for their own programs on the <a href="/hall-booking/">hall booking</a> page.</p><!-- /wp:paragraph -->',
		),
		'recognition-award' => array(
			'title'   => 'India Day Recognition Award',
			'excerpt' => 'Nominate a deserving student, or apply for yourself. Recipients are honoured at the India (Republic) Day celebration. The form takes about 10 minutes.',
			'content' => cise_starter_award( $files ),
		),
		'hall-booking'      => array(
			'title'   => 'Hall Booking',
			'excerpt' => 'Pick an open date, tell us about your event and hold your date. The CISE office confirms every booking by email and sends your invoice.',
			'content' => cise_starter_hall_rules( $files ),
		),
		'community'         => array(
			'title'   => 'Community',
			'excerpt' => 'The Youth Wing, the Women’s Wing, our library and the member associations that make up CISE.',
			'content' => cise_starter_community( $files ),
		),
		'gallery'           => array(
			'title'   => 'Gallery',
			'excerpt' => 'Photos and videos from CISE celebrations over the years.',
			'content' => cise_starter_gallery( $files ),
		),
		'resources'         => array(
			'title'   => 'Resources',
			'excerpt' => 'Bylaws, hall fees, forms and useful links for the community.',
			'content' => cise_starter_resources( $files ),
		),
		'contact'           => array(
			'title'   => 'Contact',
			'excerpt' => 'Visit us at the India Centre, send us a message or follow us on Facebook.',
			'content' => '<!-- wp:paragraph --><p>The CISE office in the India Centre basement is open on Saturdays from 11 am to 2 pm. Our volunteers check messages regularly. For hall bookings please use the <a href="/hall-booking/">booking form</a> so we have all your event details.</p><!-- /wp:paragraph -->',
		),
		'news'              => array( 'title' => 'News', 'content' => '', 'excerpt' => '' ),
	);
}

/**
 * Create missing pages, set the front page and build menus.
 *
 * @return array Log lines.
 */
function cise_run_setup() {
	// One run at a time: two overlapping requests (e.g. theme activation and a first page load) would both add the starter posts.
	global $wpdb;
	$locked = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES ('cise_setup_lock', %s, 'no')", (string) time() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	if ( ! $locked ) {
		$since = (int) $wpdb->get_var( "SELECT option_value FROM {$wpdb->options} WHERE option_name = 'cise_setup_lock'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( time() - $since < 300 ) {
			return array( 'Setup is already running in another request. Reload this page in a minute.' );
		}
		$wpdb->update( $wpdb->options, array( 'option_value' => (string) time() ), array( 'option_name' => 'cise_setup_lock' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	$log   = array();
	$ids   = array();
	$files = cise_setup_media();

	foreach ( cise_setup_pages( $files ) as $slug => $page ) {
		$existing = get_page_by_path( $slug );
		if ( $existing ) {
			$ids[ $slug ] = $existing->ID;
			$log[]        = sprintf( 'Kept existing page "%s" (/%s/)', $existing->post_title, $slug );
			continue;
		}
		$id = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $page['title'],
			'post_name'    => $slug,
			'post_content' => $page['content'],
			'post_excerpt' => $page['excerpt'],
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			$ids[ $slug ] = $id;
			$log[]        = sprintf( 'Created page "%s" (/%s/)', $page['title'], $slug );
		}
	}

	if ( ! empty( $ids['home'] ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $ids['home'] );
		$log[] = 'Set Home as the front page';
	}
	if ( ! empty( $ids['news'] ) ) {
		update_option( 'page_for_posts', $ids['news'] );
	}

	$locations = get_theme_mod( 'nav_menu_locations', array() );

	if ( empty( $locations['primary'] ) || ! wp_get_nav_menu_object( $locations['primary'] ) ) {
		$menu_id = cise_make_menu( 'CISE Main Menu', array(
			array( 'about', 'About' ),
			array( 'events', 'Events' ),
			array( 'recognition-award', 'Recognition Award' ),
			array( 'community', 'Community' ),
			array( 'gallery', 'Gallery' ),
			array( 'resources', 'Resources' ),
			array( 'contact', 'Contact' ),
		), $ids );
		if ( $menu_id ) {
			$locations['primary'] = $menu_id;
			$log[]                = 'Created the main menu';
		}
	}

	if ( empty( $locations['footer'] ) || ! wp_get_nav_menu_object( $locations['footer'] ) ) {
		$menu_id = cise_make_menu( 'CISE Footer Menu', array(
			array( 'events', 'Events calendar' ),
			array( 'hall-booking', 'Hall booking' ),
			array( 'about', 'Executive committee', '#committee' ),
			array( 'resources', 'Bylaws & publications', '#bylaws' ),
			array( 'gallery', 'Photo & video gallery' ),
		), $ids );
		if ( $menu_id ) {
			$locations['footer'] = $menu_id;
			$log[]               = 'Created the footer menu';
		}
	}

	set_theme_mod( 'nav_menu_locations', $locations );

	$log = array_merge( $log, cise_setup_starter_posts( $files ) );

	update_option( 'cise_setup_done', CISE_THEME_VERSION );
	delete_option( 'cise_setup_lock' );
	flush_rewrite_rules();

	return $log;
}

/**
 * Copy the starter photos and PDFs bundled with the theme into the Media Library
 * (once; later runs reuse them).
 *
 * @return array key => array( 'id' => attachment ID, 'url' => URL ).
 */
function cise_setup_media() {
	$files = array(
		'bylaws'      => array( 'cise-bylaws.pdf', 'CISE Bylaws' ),
		'fees'        => array( 'cise-hall-usage-fees-2026.pdf', 'CISE Hall Booking Usage Fees 2026' ),
		'legislature' => array( 'legislature.jpg', 'CISE executives at the Alberta Legislature' ),
		'india_day'   => array( 'india-day.jpg', 'Lamp lighting at the India Day celebration' ),
		'awards'      => array( 'republic-day-awards.jpg', 'Award recipients at the Republic Day celebration' ),
		'library'     => array( 'library.jpg', 'Opening of the India Centre library' ),
		'hall'        => array( 'hall.jpg', 'The India Centre hall decorated for a celebration' ),
		'youth'       => array( 'youth-wing.jpg', 'CISE Youth Wing logo' ),
		'remax'       => array( 'sponsor-remax-syamal-raha.jpg', 'Syamal Raha, RE/MAX Excellence' ),
		'punjab'      => array( 'sponsor-punjab-insurance.jpg', 'Punjab Insurance' ),
		'kp'          => array( 'sponsor-kp-accounting.jpg', 'K.P. Accounting & Tax Services' ),
		'ptc'         => array( 'sponsor-physical-therapy-centres.jpg', 'Physical Therapy Centres' ),
		'fmp'         => array( 'sponsor-future-mind-prodigy.jpg', 'Future Mind Prodigy' ),
	);
	$out = array();
	foreach ( $files as $key => $file ) {
		$path  = get_theme_file_path( 'assets/starter/' . $file[0] );
		$found = get_posts( array(
			'post_type'   => 'attachment',
			'post_status' => 'inherit',
			'numberposts' => 1,
			'meta_key'    => '_cise_starter',
			'meta_value'  => $file[0],
			'fields'      => 'ids',
		) );
		$id = $found ? (int) $found[0] : 0;
		if ( ! $id && is_readable( $path ) ) {
			$upload = wp_upload_bits( $file[0], null, file_get_contents( $path ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( empty( $upload['error'] ) ) {
				$type = wp_check_filetype( $upload['file'] );
				$id   = wp_insert_attachment( array(
					'post_title'     => $file[1],
					'post_mime_type' => $type['type'],
					'post_status'    => 'inherit',
				), $upload['file'] );
				if ( $id && ! is_wp_error( $id ) ) {
					require_once ABSPATH . 'wp-admin/includes/image.php';
					wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $upload['file'] ) );
					update_post_meta( $id, '_cise_starter', $file[0] );
					if ( 0 === strpos( $type['type'], 'image/' ) ) {
						update_post_meta( $id, '_wp_attachment_image_alt', $file[1] );
					}
				} else {
					$id = 0;
				}
			}
		}
		$out[ $key ] = array(
			'id'  => $id,
			'url' => $id ? wp_get_attachment_url( $id ) : get_theme_file_uri( 'assets/starter/' . $file[0] ),
		);
	}
	return $out;
}

/**
 * Starter events, sponsors and news from the previous website (only when none exist yet).
 */
function cise_setup_starter_posts( $files ) {
	$log = array();

	if ( post_type_exists( 'cise_event' ) && ! get_posts( array( 'post_type' => 'cise_event', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids' ) ) ) {
		foreach ( cise_starter_events() as $e ) {
			$id = wp_insert_post( array(
				'post_type'    => 'cise_event',
				'post_status'  => 'publish',
				'post_title'   => $e['title'],
				'post_excerpt' => $e['excerpt'],
				'post_content' => '<!-- wp:paragraph --><p>' . implode( '</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>', $e['content'] ) . '</p><!-- /wp:paragraph -->',
			) );
			if ( $id && ! is_wp_error( $id ) ) {
				update_post_meta( $id, '_cise_event_date', $e['date'] );
				update_post_meta( $id, '_cise_event_tbc', $e['tbc'] ? '1' : '' );
				update_post_meta( $id, '_cise_event_location', $e['location'] );
				if ( ! empty( $e['image'] ) && ! empty( $files[ $e['image'] ]['id'] ) ) {
					set_post_thumbnail( $id, $files[ $e['image'] ]['id'] );
				}
			}
		}
		$log[] = 'Added the yearly CISE events (check the dates under CISE > Events)';
	}

	if ( post_type_exists( 'cise_sponsor' ) && ! get_posts( array( 'post_type' => 'cise_sponsor', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids' ) ) ) {
		$sponsors = array(
			array( 'Syamal Raha, RE/MAX Excellence', 'remax', '' ),
			array( 'Punjab Insurance', 'punjab', '' ),
			array( 'K.P. Accounting & Tax Services', 'kp', 'https://www.kpaccounting.ca/' ),
			array( 'Physical Therapy Centres', 'ptc', 'https://www.physicaltherapycentres.com/' ),
			array( 'Future Mind Prodigy', 'fmp', '' ),
		);
		foreach ( $sponsors as $order => $s ) {
			$id = wp_insert_post( array(
				'post_type'   => 'cise_sponsor',
				'post_status' => 'publish',
				'post_title'  => $s[0],
				'menu_order'  => $order,
			) );
			if ( $id && ! is_wp_error( $id ) ) {
				if ( ! empty( $files[ $s[1] ]['id'] ) ) {
					set_post_thumbnail( $id, $files[ $s[1] ]['id'] );
				}
				update_post_meta( $id, '_cise_sponsor_url', $s[2] );
			}
		}
		$log[] = 'Added the five current sponsors';
	}

	if ( ! get_posts( array( 'post_type' => 'post', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => '_cise_starter' ) ) ) {
		$cat = term_exists( 'India Day 2026', 'category' );
		$cat = $cat ? $cat : wp_insert_term( 'India Day 2026', 'category' );
		foreach ( cise_starter_news() as $i => $n ) {
			$id = wp_insert_post( array(
				'post_type'     => 'post',
				'post_status'   => 'publish',
				'post_title'    => $n['title'],
				'post_excerpt'  => $n['excerpt'],
				'post_content'  => '<!-- wp:paragraph --><p>' . implode( '</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>', $n['content'] ) . '</p><!-- /wp:paragraph -->',
				'post_date'     => gmdate( 'Y-m-d H:i:s', strtotime( '2026-02-14 10:00:00' ) - $i * 60 ),
				'post_category' => is_array( $cat ) ? array( (int) $cat['term_id'] ) : array(),
			) );
			if ( $id && ! is_wp_error( $id ) ) {
				update_post_meta( $id, '_cise_starter', '1' );
				if ( ! empty( $n['image'] ) && ! empty( $files[ $n['image'] ]['id'] ) ) {
					set_post_thumbnail( $id, $files[ $n['image'] ]['id'] );
				}
			}
		}
		$log[] = 'Added the India Day 2026 Golden Jubilee articles to News';
	}

	return $log;
}

/**
 * Create (or reuse by name) a menu and fill it with page links.
 */
function cise_make_menu( $name, $items, $ids ) {
	$menu = wp_get_nav_menu_object( $name );
	if ( $menu ) {
		return $menu->term_id;
	}
	$menu_id = wp_create_nav_menu( $name );
	if ( is_wp_error( $menu_id ) ) {
		return 0;
	}
	foreach ( $items as $item ) {
		$slug = $item[0];
		if ( empty( $ids[ $slug ] ) ) {
			continue;
		}
		if ( ! empty( $item[2] ) ) {
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'  => $item[1],
				'menu-item-url'    => get_permalink( $ids[ $slug ] ) . $item[2],
				'menu-item-type'   => 'custom',
				'menu-item-status' => 'publish',
			) );
		} else {
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'     => $item[1],
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $ids[ $slug ],
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
			) );
		}
	}
	return $menu_id;
}

add_action( 'after_switch_theme', function () {
	if ( ! get_option( 'cise_setup_done' ) ) {
		set_transient( 'cise_setup_log', cise_run_setup(), 300 );
	}
} );

add_action( 'admin_menu', function () {
	add_theme_page( __( 'CISE setup', 'cise' ), __( 'CISE setup', 'cise' ), 'manage_options', 'cise-setup', 'cise_setup_screen' );
} );

add_action( 'admin_post_cise_run_setup', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'cise' ) );
	}
	check_admin_referer( 'cise_run_setup' );
	set_transient( 'cise_setup_log', cise_run_setup(), 300 );
	wp_safe_redirect( admin_url( 'themes.php?page=cise-setup' ) );
	exit;
} );

add_action( 'admin_notices', function () {
	$log = get_transient( 'cise_setup_log' );
	if ( ! $log || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	delete_transient( 'cise_setup_log' );
	echo '<div class="notice notice-success is-dismissible"><p><strong>' . esc_html__( 'CISE setup finished.', 'cise' ) . '</strong></p><ul style="list-style:disc;padding-left:20px">';
	foreach ( $log as $line ) {
		echo '<li>' . esc_html( $line ) . '</li>';
	}
	echo '</ul></div>';
} );

function cise_setup_screen() {
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'CISE setup', 'cise' ); ?></h1>
		<p><?php esc_html_e( 'Creates any missing CISE pages (About, Events, Recognition Award, Hall Booking, Community, Gallery, Resources, Contact, News), sets Home as the front page and builds the main and footer menus if none are assigned. If there are no events, sponsors or news posts yet, it also adds the ones from the previous CISE website. Existing pages, posts and menus are never changed or deleted.', 'cise' ); ?></p>
		<?php if ( ! function_exists( 'cise_core_get' ) ) : ?>
			<div class="notice notice-warning inline"><p><?php esc_html_e( 'The CISE Core plugin is not active. Activate it for events, hall booking and award nominations.', 'cise' ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="cise_run_setup">
			<?php wp_nonce_field( 'cise_run_setup' ); ?>
			<?php submit_button( __( 'Run setup', 'cise' ) ); ?>
		</form>
		<h2><?php esc_html_e( 'Where to edit things', 'cise' ); ?></h2>
		<ul style="list-style:disc;padding-left:20px">
			<li><?php esc_html_e( 'Logo: Appearance > Customize > Site Identity.', 'cise' ); ?></li>
			<li><?php esc_html_e( 'Homepage text and photos, address, email, phone, office hours, Facebook: Appearance > Customize > CISE site options.', 'cise' ); ?></li>
			<li><?php esc_html_e( 'Events, sponsors, hall bookings, nominations, rates and award dates: the CISE menu in the left sidebar.', 'cise' ); ?></li>
			<li><?php esc_html_e( 'About, Community, Gallery, Resources and the hall rules: edit those pages like any other page.', 'cise' ); ?></li>
		</ul>
	</div>
	<?php
}

/* ---------- Starter content (block markup, editable in the block editor) ---------- */

/**
 * Block markup for a single image.
 */
function cise_starter_image( $files, $key, $caption = '' ) {
	if ( empty( $files[ $key ] ) ) {
		return '';
	}
	$f   = $files[ $key ];
	$cap = $caption ? '<figcaption class="wp-element-caption">' . esc_html( $caption ) . '</figcaption>' : '';
	return sprintf(
		'<!-- wp:image {%1$s"sizeSlug":"large"} --><figure class="wp-block-image size-large"><img src="%2$s" alt="%3$s"%4$s/>%5$s</figure><!-- /wp:image -->',
		$f['id'] ? '"id":' . (int) $f['id'] . ',' : '',
		esc_url( $f['url'] ),
		esc_attr( $caption ),
		$f['id'] ? ' class="wp-image-' . (int) $f['id'] . '"' : '',
		$cap
	);
}

/**
 * Block markup for a file download link.
 */
function cise_starter_file( $files, $key, $label ) {
	if ( empty( $files[ $key ] ) ) {
		return '';
	}
	$f = $files[ $key ];
	return sprintf(
		'<!-- wp:file {%1$s"href":"%2$s"} --><div class="wp-block-file"><a href="%2$s">%3$s</a><a href="%2$s" class="wp-block-file__button wp-element-button" download>Download</a></div><!-- /wp:file -->',
		$f['id'] ? '"id":' . (int) $f['id'] . ',' : '',
		esc_url( $f['url'] ),
		esc_html( $label )
	);
}

function cise_starter_about( $files ) {
	$photo = cise_starter_image( $files, 'legislature', 'CISE executives at the Alberta Legislature' );
	$html  = <<<'HTML'
<!-- wp:paragraph -->
<p>The Council of India Societies of Edmonton (CISE), established in 1976, is a not-for-profit umbrella organization representing Indo-Canadians in Edmonton and the surrounding area. It serves individuals as well as social and cultural organizations through a variety of programs.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Our premises, popularly called the <strong>India Centre</strong>, sit in the heart of the Mill Woods industrial park. The India Centre is used for sports and recreation, social and community gatherings, dance, music and language classes, rehearsals for CISE celebrations, member association meetings, drop-in time for youth and seniors, the library and reading room, and seminars and workshops.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>CISE organizes the celebrations of India (Republic) Day, Canada Day, Heritage Day and India (Independence) Day. We keep close ties with Edmonton's other ethnic and multicultural associations, take part in their functions, and invite them to ours.</p>
<!-- /wp:paragraph -->

%PHOTO%

<!-- wp:heading {"anchor":"objectives"} -->
<h2 class="wp-block-heading" id="objectives">Our objectives</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><li>To develop and encourage co-operation and goodwill among our members.</li><li>To foster appreciation and a sense of duty and responsibility towards the multicultural society of Canada.</li><li>To safeguard, promote and support the Indian cultural, social and general interests and the well-being of Albertans of Indian origin.</li><li>To establish liaison with, and where prudent join, other organizations with similar objectives.</li><li>To help co-ordinate activities among the member associations of the Council.</li><li>To participate in local, provincial and national bodies and institutions as a society of persons of Indian origin.</li><li>To act as a general representative and spokesperson for persons of Indian ancestry on issues of interest or concern.</li><li>To support, object to or express an opinion on issues at the municipal, provincial, federal or international level that are important to Indians. The Council does not join or actively take part in any political party.</li><li>To serve the Indian community in areas such as settlement of immigrants, the welfare of senior citizens, counselling for vulnerable groups such as abused women, and assistance to Indian students in Edmonton. Where other organizations already provide such services, the Council actively supports their work.</li></ul>
<!-- /wp:list -->

<!-- wp:heading {"anchor":"history"} -->
<h2 class="wp-block-heading" id="history">Our history</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>CISE was founded in 1976. Its founding President, Mr. Robinson Koilpillai, led the Council from 1976 to 1978 and again from 1981 to 1983. A teacher and principal with Edmonton Public Schools and later a Member of the Order of Canada, he introduced the student awards that are still presented at our India Day celebration.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>In 2026 CISE celebrates its Golden Jubilee under the theme <em>“Golden Threads of India: 50 Years of Unity in Diversity”</em>, honouring the founding leaders, families, elders and volunteers who built the Council.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"committee"} -->
<h2 class="wp-block-heading" id="committee">Executive committee 2026–2027</h2>
<!-- /wp:heading -->

<!-- wp:table -->
<figure class="wp-block-table"><table><thead><tr><th>Role</th><th>Name</th></tr></thead><tbody><tr><td>President</td><td>Digraj Parmar</td></tr><tr><td>VP (Admin)</td><td>Rohit Sati</td></tr><tr><td>VP (Programs)</td><td>Sasidevi Caster</td></tr><tr><td>VP (Communications)</td><td>Archana Tiwari</td></tr><tr><td>General Secretary</td><td>Dr. Mithun Rajshekar</td></tr><tr><td>Treasurer</td><td>Lalabhai Shah</td></tr><tr><td>Executive Assistant</td><td>Akhilesh Munipally</td></tr><tr><td>Executive Assistant</td><td>Renu Narang</td></tr><tr><td>Past President</td><td>Puneet Manchanda</td></tr><tr><td>Auditor</td><td>Malay Samanta</td></tr><tr><td>Auditor</td><td>Dhirubhai Ladwa</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:heading {"anchor":"meetings"} -->
<h2 class="wp-block-heading" id="meetings">Meeting schedule 2026–27</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The executive committee meets at the India Centre from 9:30 to 11:00 am. Dates and times are subject to change.</p>
<!-- /wp:paragraph -->

<!-- wp:table -->
<figure class="wp-block-table"><table><thead><tr><th>Meeting</th><th>Date</th></tr></thead><tbody><tr><td>Executive meetings 2026</td><td>Sun Apr 5 · Sat May 9 · Sat Jun 13 · Sat Jul 18 · Sat Aug 2 · Sat Sep 12 · Sat Oct 10 · Sat Nov 14 · Sat Dec 12</td></tr><tr><td>Executive meetings 2027</td><td>Sat Jan 9 · Sat Feb 6 · Sat Mar 13</td></tr><tr><td>General Body Meetings (GBM)</td><td>June 22, 2026 · August 23, 2026 · November 21, 2026</td></tr><tr><td>Annual General Body Meeting (AGM)</td><td>March 21, 2027</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:heading {"anchor":"membership"} -->
<h2 class="wp-block-heading" id="membership">Membership</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>Regular members</strong> are registered non-profit societies in good standing under the Alberta Societies Act, whose membership is mostly of Indian origin or ancestry, with at least 50 paid-up individual members. Each member society names two delegates to the Council (one of them an executive of the society), plus one more if it has over 100 paid-up members.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Ex-officio delegates</strong> are the elected executive committee and the immediate past president, with the same rights as delegates, including the vote.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Together the delegates form the <strong>General Body</strong>, the policy-making body of the Council. It decides by consensus, or by majority vote when there is no consensus. The full rules are in the <a href="/resources/#bylaws">CISE bylaws</a>; see the <a href="/community/#member-associations">member associations</a>.</p>
<!-- /wp:paragraph -->
HTML;
	return str_replace( '%PHOTO%', $photo, $html );
}

function cise_starter_award( $files ) {
	$photo = cise_starter_image( $files, 'awards', 'Award recipients at the Republic Day celebration' );
	$html  = <<<'HTML'
<!-- wp:heading {"anchor":"criteria"} -->
<h2 class="wp-block-heading" id="criteria">Award &amp; criteria</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Each year at the India (Republic) Day celebration, CISE presents academic excellence awards to meritorious students. The student awards were introduced by our founding President, Mr. Robinson Koilpillai, and have been a highlight of the celebration ever since.</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><li>Lives in Edmonton or the surrounding area [confirm]</li><li>Currently in Grade 12 or post-secondary [confirm]</li><li>Minimum average of [X]% [confirm]</li><li>One nomination per person per year</li></ul>
<!-- /wp:list -->

%PHOTO%

<!-- wp:heading {"anchor":"past-recipients"} -->
<h2 class="wp-block-heading" id="past-recipients">Past recipients</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>[List past award recipients here.]</p>
<!-- /wp:paragraph -->
HTML;
	return str_replace( '%PHOTO%', $photo, $html );
}

function cise_starter_hall_rules( $files ) {
	$fees = cise_starter_file( $files, 'fees', 'CISE Hall Booking Usage Fees 2026 (PDF)' );
	$html = <<<'HTML'
<!-- wp:heading {"anchor":"about-halls"} -->
<h2 class="wp-block-heading" id="about-halls">About the halls</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The India Centre has two halls for rent to member societies and others: the <strong>Main Hall</strong> and the <strong>Basement</strong>. The maximum approved capacity of the India Centre is 200 people, with 25 round tables and about 250 chairs available.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"fees"} -->
<h2 class="wp-block-heading" id="fees">Usage fees 2026</h2>
<!-- /wp:heading -->

<!-- wp:table -->
<figure class="wp-block-table"><table><thead><tr><th>Booking</th><th>Main Hall</th><th>Basement</th><th>Both</th></tr></thead><tbody><tr><td>Hourly</td><td>$106 / hr</td><td>$75 / hr</td><td></td></tr><tr><td>Half day, 8 am – 3 pm</td><td>$500</td><td>$300</td><td>$815</td></tr><tr><td>Half day, 5 pm – midnight</td><td>$565</td><td>$300</td><td>$815</td></tr><tr><td>Full day, 8 am – midnight</td><td>$750</td><td>$500</td><td>$1,125</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:table -->
<figure class="wp-block-table"><table><thead><tr><th>Extras</th><th>Fee</th></tr></thead><tbody><tr><td>Decoration time (check with the office manager, subject to availability)</td><td>$50 / hr</td></tr><tr><td>Food cleaning (mandatory if food is served)</td><td>$155</td></tr><tr><td>General cleaning (no food served)</td><td>$95</td></tr><tr><td>Damage deposit (refundable; cheque or card preferred)</td><td>$250</td></tr><tr><td>Setup (tables and chairs)</td><td>$55</td></tr><tr><td>Portable speaker (if available)</td><td>$32</td></tr><tr><td>PA system</td><td>$55</td></tr></tbody></table></figure>
<!-- /wp:table -->

%FEES%

<!-- wp:heading {"anchor":"rules"} -->
<h2 class="wp-block-heading" id="rules">Hall rental rules &amp; booking policy</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><li>Your request places a hold on the date. You then have 14 days to pay and confirm the booking; unpaid holds are cancelled automatically and you would need to book again.</li><li>You can book up to four months ahead. To confirm a booking further out, visit the CISE office on a Saturday between 11 am and 1 pm.</li><li>No cooking is permitted on the premises. Catered food may be served.</li><li>Guests supply their own plates, cutlery, tablecloths, decorations and other supplies.</li><li>Half-day bookings must finish within the time slot, or a penalty of $100 per hour is charged.</li><li>Any city tickets or violations during an event are the responsibility of the organizers.</li><li>The member society discount applies to half-day or longer bookings made from the society's official email address (not a personal email).</li><li>Non-profit organizations planning a community or people-development event can contact <a href="mailto:cise@ciseedmonton.com">cise@ciseedmonton.com</a> to explore support options.</li></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p><strong>Office hours:</strong> Saturdays, 11 am to 2 pm, in the India Centre basement (9504 37 Avenue). Phone 780-700-7979 or email <a href="mailto:cise@ciseedmonton.com">cise@ciseedmonton.com</a>.</p>
<!-- /wp:paragraph -->
HTML;
	return str_replace( '%FEES%', $fees, $html );
}

function cise_starter_community( $files ) {
	$library = cise_starter_image( $files, 'library', 'The India Centre library' );
	$assoc   = array(
		array( 'Alberta Gujarati Association', 'Brijesh Patel', 'alberta.gujarati.association@gmail.com' ),
		array( 'Alberta Hindi Parishad', 'Amit Aery', '' ),
		array( 'Asian Youth Club', 'Ashok Sharma', '' ),
		array( 'Bhartiya Cultural Society of Alberta', 'Arvind Aery', '' ),
		array( 'Canadian Kerala Cultural Association', 'Thomas Eapen', '' ),
		array( 'Edmonton Bengali Association', 'Rama Lall', 'ebaedm@gmail.com' ),
		array( 'Edmonton Kannada Association', 'Dr. Sumangala Desaigoudar', 'kcaexecutive@gmail.com' ),
		array( 'Edmonton Tamil Cultural Association', 'Ravindaran Subramaniam', '' ),
		array( 'Garvi Gujarat Association of Canada', 'Lalabhai Shah', 'info@ggac.ca' ),
		array( 'Gujarat Cultural Society', 'Sanjay Patel', '' ),
		array( 'Hindu Society of Alberta', 'Hari Rawat', 'hindusocietyofalberta@gmail.com' ),
		array( 'Indo-Canadian Women’s Association', 'Jodi Zabludowski', '' ),
		array( 'Krishti Bengali Cultural Society of Edmonton', 'Malay Samanta', '' ),
		array( 'Manoranjan Club', 'Kapil Sharma', '' ),
		array( 'Millwoods Culture Society for Retired & Semi-Retired', 'Balbir Singh Kullar', 'Millwoodscsretd@gmail.com' ),
		array( 'Shantiniketan Society of Retired and Semi-retired', 'Rashmi Sinha', '' ),
		array( 'Shirdi Sai Baba Mandir', 'Prabhat Chaturvedi', 'contact@shirdisaibabaedmonton.ca' ),
		array( 'Society for the Education and Assistance of Rural Indian Children (SEARIC)', 'Dr. Ram Mehta', '' ),
		array( 'Telugu Cultural Association of Edmonton', 'Varsha Makarla', '' ),
		array( 'University of Alberta Indian Students Association', 'Priyanka Maripuri', 'indsa@ualberta.ca' ),
	);
	$rows = '';
	foreach ( $assoc as $a ) {
		$rows .= '<tr><td>' . esc_html( $a[0] ) . '</td><td>' . esc_html( $a[1] ) . ( $a[2] ? '<br><a href="mailto:' . esc_attr( $a[2] ) . '">' . esc_html( $a[2] ) . '</a>' : '' ) . '</td></tr>';
	}
	$html = <<<'HTML'
<!-- wp:heading {"anchor":"youth-wing"} -->
<h2 class="wp-block-heading" id="youth-wing">Youth Wing</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The CISE Youth Wing brings together high school and university students to build engagement within the Indo-Canadian and South Asian communities. Through workshops, volunteer projects and cultural events, it empowers young people with cultural pride, community service and leadership.</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><li><strong>Leadership:</strong> teamwork, public speaking and problem-solving through workshops and group projects.</li><li><strong>Cultural engagement:</strong> connect with your roots and celebrate your heritage.</li><li><strong>Community impact:</strong> work with peers and older generations on projects that build cross-cultural understanding.</li></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Follow the Youth Wing on <a href="https://www.instagram.com/ciseyouthwing">Instagram</a> and <a href="https://www.facebook.com/share/1A5AC2daVc/">Facebook</a>, or <a href="/contact/">contact us</a> to join.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"womens-wing"} -->
<h2 class="wp-block-heading" id="womens-wing">Women's Wing</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>“Together we rise.”</strong> The CISE Women's Wing empowers and supports women through initiatives, programs and resources, fostering a community that promotes equality, growth and opportunity.</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><li>Education, training and mentorship for women.</li><li>A supportive community to share experiences and resources.</li><li>Promoting women's rights, equality and social justice.</li><li>Platforms for women to showcase their talents and achievements.</li><li>Collaboration with organizations to amplify women's voices.</li><li>Recreational and social activities.</li></ul>
<!-- /wp:list -->

<!-- wp:heading {"anchor":"library"} -->
<h2 class="wp-block-heading" id="library">Library</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The library and reading room at the India Centre is open to the community. Online, members can find <a href="https://docs.google.com/document/d/1uhNIFZj2o0vPHMBpKBX0j-I-qbp2hY6FWqa5PsYOXj8/edit">Canada information</a>, <a href="https://docs.google.com/document/d/1Hl11QpuiwxoNFQQXyOVWY4EQVDbSP14De4zXOD55mqw/edit">India and grant information</a> and the <a href="https://docs.google.com/document/d/131_sxblLLD3-4sNH-Q0bdKXKCV-U83-4FSjZGcJA4OU/edit">newsletter</a>.</p>
<!-- /wp:paragraph -->

%LIBRARY%

<!-- wp:heading {"anchor":"member-associations"} -->
<h2 class="wp-block-heading" id="member-associations">Member associations</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The societies under the CISE umbrella. To apply to join, see <a href="/about/#membership">membership</a> and <a href="/contact/">contact us</a>.</p>
<!-- /wp:paragraph -->

<!-- wp:table -->
<figure class="wp-block-table"><table><thead><tr><th>Association</th><th>Contact</th></tr></thead><tbody>%ROWS%</tbody></table></figure>
<!-- /wp:table -->

<!-- wp:heading {"anchor":"indian-communities"} -->
<h2 class="wp-block-heading" id="indian-communities">Indian communities in Edmonton</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>Former CISE members:</strong> Edmonton Goan Association, Maple Leaf Writer Foundation, Millwoods Ex-servicemen Association, All World Gayatri Pariwar, Edmonton Bongo Society, Edmonton Rajput Association, Edmonton Senior Sports Association, Maanaw Seva Association, Nepalese Canadian Society of Edmonton.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Spiritual societies:</strong> BAPS Shri Swaminarayan Mandir, Gurdwara Millwoods, Gurdwara Dukh Nivaran Sahib, ISHA Foundation, Nanaksar Gurdwara, Pushtimargiya Vaishnav Samaj of Canada, Radha Soami Satsang Beas, Sri Sri Radha Govindaji Vedic Cultural Society, Swaminarayan Temple, Yogi Divine Society.</p>
<!-- /wp:paragraph -->
HTML;
	return str_replace( array( '%LIBRARY%', '%ROWS%' ), array( $library, $rows ), $html );
}

function cise_starter_gallery( $files ) {
	$imgs = '';
	foreach ( array( 'india_day', 'awards', 'legislature', 'library' ) as $key ) {
		$imgs .= cise_starter_image( $files, $key );
	}
	return '<!-- wp:paragraph --><p>Add photos with the Gallery block: edit this page, click the + button and choose <strong>Gallery</strong>.</p><!-- /wp:paragraph -->'
		. '<!-- wp:heading --><h2 class="wp-block-heading">CISE through the years</h2><!-- /wp:heading -->'
		. '<!-- wp:gallery {"linkTo":"none"} --><figure class="wp-block-gallery has-nested-images columns-default is-cropped">' . $imgs . '</figure><!-- /wp:gallery -->'
		. '<!-- wp:heading --><h2 class="wp-block-heading">Videos</h2><!-- /wp:heading -->'
		. '<!-- wp:embed {"url":"https://www.youtube.com/watch?v=ScZTu8Sa7S8","type":"video","providerNameSlug":"youtube","responsive":true,"className":"wp-embed-aspect-16-9 wp-has-aspect-ratio"} --><figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">https://www.youtube.com/watch?v=ScZTu8Sa7S8</div><figcaption class="wp-element-caption">A presentation by Ranjit Singh Khaira</figcaption></figure><!-- /wp:embed -->'
		. '<!-- wp:paragraph --><p>Paste a YouTube or Facebook video link on its own line to embed it.</p><!-- /wp:paragraph -->';
}

function cise_starter_resources( $files ) {
	$bylaws = cise_starter_file( $files, 'bylaws', 'CISE Bylaws (PDF)' );
	$fees   = cise_starter_file( $files, 'fees', 'Hall Booking Usage Fees 2026 (PDF)' );
	$html   = <<<'HTML'
<!-- wp:heading {"anchor":"bylaws"} -->
<h2 class="wp-block-heading" id="bylaws">Bylaws &amp; publications</h2>
<!-- /wp:heading -->

%BYLAWS%

%FEES%

<!-- wp:paragraph -->
<p>[Upload the India Day and Independence Day eMagazines (PDF) here with the File block.]</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"forms"} -->
<h2 class="wp-block-heading" id="forms">Forms &amp; documents</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><li><a href="https://docs.google.com/forms/d/e/1FAIpQLSf46nIxHR_d9TpLyfHRYtKcNOssJqSKp8ZdPtjclCRVzwe3Gg/viewform">Suggestion form</a></li><li><a href="https://docs.google.com/forms/d/e/1FAIpQLSe3MZO1MafnUr8Y8sKgvt3CvKUkPJvaPFTpACd3H3IbqWlrrQ/viewform">RSVP form</a></li><li><a href="https://drive.google.com/file/d/1kX4CdEEzmcTrreVKJH_um7zpHrIAhDdQ/view">Fundraising for CISE</a></li><li><a href="https://docs.google.com/document/d/1YsWz6-_NOZ3fLbuo9ebuaBuUNc7IVk7qUEoTFpFF76w/edit">CISE building maintenance plan &amp; schedule</a></li><li><a href="https://docs.google.com/document/d/1uhNIFZj2o0vPHMBpKBX0j-I-qbp2hY6FWqa5PsYOXj8/edit">Canada information</a></li><li><a href="https://docs.google.com/document/d/1Hl11QpuiwxoNFQQXyOVWY4EQVDbSP14De4zXOD55mqw/edit">India and grant information</a></li><li><a href="https://docs.google.com/document/d/131_sxblLLD3-4sNH-Q0bdKXKCV-U83-4FSjZGcJA4OU/edit">Newsletter</a></li></ul>
<!-- /wp:list -->

<!-- wp:heading {"anchor":"consulate"} -->
<h2 class="wp-block-heading" id="consulate">Consulate links</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><li><a href="https://www.cgivancouver.gov.in/">Consulate General of India, Vancouver</a> (life certificate attestation is offered at the CISE Consular Camp each November)</li><li><a href="https://www.hciottawa.gov.in/">High Commission of India, Ottawa</a></li></ul>
<!-- /wp:list -->
HTML;
	return str_replace( array( '%BYLAWS%', '%FEES%' ), array( $bylaws, $fees ), $html );
}

/**
 * The yearly CISE events, from the previous website.
 */
function cise_starter_events() {
	return array(
		array(
			'title'    => 'Consular Camp',
			'date'     => '2026-11-15',
			'tbc'      => true,
			'location' => 'India Centre',
			'excerpt'  => 'Life certificate attestation by officers of the Consulate General of India, Vancouver.',
			'content'  => array( 'CISE hosts an Indian consular camp for life certificate attestation only. Officers from the Consulate General of India in Vancouver come to Edmonton to do the attestation. It is typically held on a Sunday in November.', 'Please note the camp is only for life certificate attestation. For visa and other services, follow the normal application procedures of the Consulate.' ),
		),
		array(
			'title'    => 'India (Republic) Day',
			'date'     => '2027-02-14',
			'tbc'      => false,
			'location' => '',
			'image'    => 'india_day',
			'excerpt'  => 'Cultural program, messages from dignitaries and the India Day academic excellence awards.',
			'content'  => array( 'Indian Republic Day honours the date the Constitution of India came into force: 26 January 1950. The date was chosen because on 26 January 1930 the Declaration of Indian Independence (Purna Swaraj) was proclaimed.', 'CISE celebrates Republic Day with its member associations. In recent years it has been held in early February at the Northern Alberta Jubilee Auditorium, with a cultural program, messages from dignitaries and the presentation of academic excellence awards to meritorious students.' ),
		),
		array(
			'title'    => 'India Day Award',
			'date'     => '2027-02-14',
			'tbc'      => false,
			'location' => '',
			'image'    => 'awards',
			'excerpt'  => 'Academic excellence awards presented at the India (Republic) Day celebration.',
			'content'  => array( 'Meritorious students are honoured with the India Day Recognition Award at the India (Republic) Day celebration. Nominations are made online on the <a href="/recognition-award/">Recognition Award</a> page.' ),
		),
		array(
			'title'    => 'International Yoga Day',
			'date'     => '2027-06-21',
			'tbc'      => true,
			'location' => '',
			'excerpt'  => 'Celebrating the International Day of Yoga together.',
			'content'  => array( 'CISE marks the International Day of Yoga each June. In 2021 the Council held Yog Divas in William Hawrelak Park.' ),
		),
		array(
			'title'    => 'Canada Day',
			'date'     => '2027-07-01',
			'tbc'      => false,
			'location' => '',
			'excerpt'  => 'Flag hoisting, cultural program, messages from dignitaries and snacks.',
			'content'  => array( 'Canada Day celebrates the anniversary of the British North America Act of July 1, 1867, which united three colonies into a single country called Canada. Originally called Dominion Day, the holiday was renamed in 1982.', 'CISE celebrates Canada Day with its member associations, typically with a flag hoisting, cultural program, messages from dignitaries and snacks.' ),
		),
		array(
			'title'    => 'Summer Camp',
			'date'     => '2027-07-12',
			'tbc'      => true,
			'location' => '',
			'excerpt'  => 'A week of summer activities for children and youth.',
			'content'  => array( '[Add the summer camp details, ages and registration link here.]' ),
		),
		array(
			'title'    => 'Heritage Festival',
			'date'     => '2027-07-31',
			'tbc'      => true,
			'location' => '',
			'excerpt'  => 'The India pavilion at Edmonton’s three-day multicultural festival.',
			'content'  => array( 'Heritage Festival is a three-day showcase of Edmonton’s multicultural heritage, with over 60 pavilions representing more than 85 cultures. It is a family-friendly, alcohol-free event with free admission. See <a href="https://heritagefest.ca">heritagefest.ca</a>.', 'CISE takes part every year and manages the India pavilion, with stalls for Indian food, clothing and handicrafts, and Indian dance performances, both Bollywood and regional folk dances.' ),
		),
		array(
			'title'    => 'India (Independence) Day',
			'date'     => '2027-08-15',
			'tbc'      => false,
			'location' => '',
			'excerpt'  => 'Flag hoisting, cultural program, messages from dignitaries and snacks.',
			'content'  => array( 'Indian Independence Day, observed every year on 15 August, commemorates India’s independence from the British Empire on 15 August 1947.', 'CISE celebrates Independence Day with its member associations, typically with a flag hoisting, cultural program, messages from dignitaries and snacks.' ),
		),
		array(
			'title'    => 'Hindi Divas',
			'date'     => '2027-09-14',
			'tbc'      => true,
			'location' => 'India Centre',
			'excerpt'  => 'Celebrating the Hindi language with Alberta Hindi Parishad.',
			'content'  => array( 'CISE organizes Hindi Divas in collaboration with Alberta Hindi Parishad. School children, university students and seniors take part with Hindi kavitas (poems) and presentations.' ),
		),
		array(
			'title'    => 'Gandhi Jayanti',
			'date'     => '2027-10-02',
			'tbc'      => true,
			'location' => '',
			'excerpt'  => 'Marking the birth anniversary of Mahatma Gandhi.',
			'content'  => array( '[Add the Gandhi Jayanti program details here.]' ),
		),
	);
}

/**
 * Golden Jubilee articles from the India Day 2026 page of the previous website.
 */
function cise_starter_news() {
	return array(
		array(
			'title'   => 'Unity of India: the mission and vision of CISE',
			'excerpt' => 'India’s true strength lies in its unity. A message from CISE President Digraj Parmar.',
			'image'   => 'legislature',
			'content' => array(
				'The mission of the Council of India Societies of Edmonton (CISE) is to strengthen India’s national unity, social harmony and democratic values. It strives to build a society where every citizen, regardless of religion, caste or region, feels like a partner in the nation’s progress.',
				'India is one of the most unique countries in the world, characterized by an extraordinary diversity of languages, religions, communities and cultures. Despite this diversity, India has stood for centuries as an indivisible and united nation. “Unity in Diversity” is not merely India’s identity but its very soul, giving the country its inner strength.',
				'In India, people of Hindu, Muslim, Sikh, Christian, Buddhist, Jain and many other faiths live together in harmony. Each religion has enriched the social and cultural fabric of the country. Mutual respect, tolerance and a spirit of brotherhood have bound Indian society together with strong threads of unity. Linguistic diversity is also an important element of that unity: hundreds of languages and dialects are spoken across the country, and this diversity has strengthened the nation’s cultural richness.',
				'The strongest foundation of India’s unity is the Constitution of India. It guarantees equal rights, freedom and justice to all citizens, rejects discrimination based on religion, caste, gender or language, and promotes social harmony.',
				'In this context, the role of CISE is highly significant. Through social, cultural and educational initiatives, CISE works to connect people with one another. It promotes patriotism, mutual cooperation and a sense of social responsibility, making “Unity in Diversity” not just a slogan but a lived experience.',
				'India’s unity is an ongoing journey to which every generation contributes. If we preserve our constitutional values and shared heritage, India will continue to remain a symbol of unity, peace and progress.',
				'<em>Digraj Parmar, President, CISE</em>',
			),
		),
		array(
			'title'   => 'Unity shines in diversity',
			'excerpt' => 'Wherever Indians live across the globe, the many colours of India are visible.',
			'image'   => 'india_day',
			'content' => array(
				'Whether we live in Canada, the United States, Europe or anywhere else in the world, India’s spirit always shines through. We may be known as Non-Resident Indians, but wherever Indians live, the cultural roots of the regions we come from go with us.',
				'In one corner of a shopping mall you may see someone wrapped in a Kashmiri shawl. Elsewhere, Punjabi women in elegant Patiala outfits chat as folk songs fill the air. On a stage nearby, young men in sherwanis and turbans perform Bhangra, while a young woman in a South Indian sari captivates the audience with Bharatanatyam. Maharashtrian women perform Lezim, and during Navratri, Gujaratis in vibrant dress light up the scene with Garba.',
				'Imagine an Indian potluck in a foreign city: parathas, makki di roti and sarson da saag from the north; dal-baati, khaman, dhokla and thepla from the west; masala dosa and sambhar from the south; sandesh from the east. And right at the centre stands pani puri, a symbol of national unity. Amid all these dishes one thing is common: the shared spices that bind them together.',
				'Like a sacred Indian mantra, wherever Indians settle across the world, unity in diversity continues to shine. Jai Hind, Jai Bharat.',
				'<em>Manish Patel</em>',
			),
		),
		array(
			'title'   => 'Golden Threads of India: 50 years with the Tamil community',
			'excerpt' => 'The Edmonton Tamil Cultural Association on its shared history with CISE, from the founding President to the Youth Wing.',
			'image'   => 'awards',
			'content' => array(
				'Since the founding of CISE in 1976, the Edmonton Tamil Cultural Association (ETCA) and the Tamil community have been an integral part of CISE’s journey, contributing leadership, service and cultural richness. As CISE celebrates its Golden Jubilee in 2026 under the theme “Golden Threads of India: 50 Years of Unity in Diversity”, this partnership stands as an example of shared values and collective progress.',
				'A cornerstone of this shared history is Mr. Robinson Koilpillai, a respected leader within the Tamil community. He served as the founding President of CISE from 1976 to 1978, and again from 1981 to 1983, and was also the founding President of ETCA from 1979 to 1981.',
				'Among his most enduring contributions was the introduction of student awards at CISE’s annual celebrations, reflecting his strong belief in education and youth empowerment, values rooted in his career as a teacher and principal with Edmonton Public Schools. Mr. Koilpillai was admitted to the Order of Canada, one of the country’s highest civilian honours.',
				'Over the decades, members of the Tamil community have supported CISE through executive leadership, auditing roles and contributions to the CISE magazine. Tamil children and youth remain a vibrant presence at CISE events, performing, singing the national anthems and receiving student awards.',
				'After a pause in formal membership, ETCA rejoined CISE in 2022. Today its involvement is stronger than ever, at the executive level and within the CISE Youth Wing. As CISE marks its 50th anniversary, ETCA honours the founding leaders, families, elders and volunteers whose words of hope, encouragement and unity became the foundation on which the community was built.',
				'<em>Edmonton Tamil Cultural Association Executive</em>',
			),
		),
	);
}
