/* CISE theme: mobile menu, phone-friendly tables */
(function () {
	// Tables with a header row stack into labelled cards on phones (see .is-stacked in main.css).
	document.querySelectorAll('.content table').forEach(function (table) {
		var heads = table.querySelectorAll('thead th');
		if (heads.length < 2) return;
		table.classList.add('is-stacked');
		table.querySelectorAll('tbody tr').forEach(function (row) {
			Array.prototype.forEach.call(row.children, function (cell, i) {
				var label = heads[i] ? heads[i].textContent.trim() : '';
				if (label) cell.setAttribute('data-label', label);
			});
		});
	});
})();

(function () {
	var toggle = document.querySelector('.nav-toggle');
	var nav = document.getElementById('main-nav');
	if (!toggle || !nav) return;

	toggle.addEventListener('click', function () {
		var open = nav.classList.toggle('is-open');
		toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
	});

	// Close the menu when a link inside it jumps within the page (e.g. #committee).
	nav.addEventListener('click', function (e) {
		if (e.target.closest('a') && nav.classList.contains('is-open')) {
			nav.classList.remove('is-open');
			toggle.setAttribute('aria-expanded', 'false');
		}
	});

	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape' && nav.classList.contains('is-open')) {
			nav.classList.remove('is-open');
			toggle.setAttribute('aria-expanded', 'false');
			toggle.focus();
		}
	});
})();
