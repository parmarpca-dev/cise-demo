/* CISE theme: mobile menu */
(function () {
	var toggle = document.querySelector('.nav-toggle');
	var nav = document.getElementById('main-nav');
	if (!toggle || !nav) return;

	toggle.addEventListener('click', function () {
		var open = nav.classList.toggle('is-open');
		toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
	});

	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape' && nav.classList.contains('is-open')) {
			nav.classList.remove('is-open');
			toggle.setAttribute('aria-expanded', 'false');
			toggle.focus();
		}
	});
})();
