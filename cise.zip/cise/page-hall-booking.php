<?php
/**
 * Hall Booking page (slug "hall-booking"): booking calendar + rental rules.
 *
 * @package cise
 */

get_header();

while ( have_posts() ) :
	the_post();
	cise_page_hero( get_the_title(), cise_page_lead() );
	?>
	<section class="section" style="padding-top:48px">
		<div class="wrap">
			<?php
			if ( function_exists( 'cise_core_booking_app' ) ) {
				cise_core_booking_app();
			} else {
				cise_needs_plugin_notice( __( 'booking calendar', 'cise' ) );
			}
			?>
		</div>
	</section>
	<?php if ( trim( get_the_content() ) ) : ?>
		<section class="section section--cream">
			<div class="wrap">
				<div class="content"><?php the_content(); ?></div>
			</div>
		</section>
	<?php endif; ?>
	<?php
endwhile;

get_footer();
