<?php
/**
 * Fallback template: news posts, archives and search results.
 *
 * @package cise
 */

get_header();

if ( is_home() ) {
	$news_page = get_option( 'page_for_posts' );
	cise_page_hero( $news_page ? get_the_title( $news_page ) : __( 'News', 'cise' ), $news_page ? cise_page_lead( $news_page ) : '' );
} elseif ( is_search() ) {
	/* translators: %s: search query */
	cise_page_hero( sprintf( __( 'Search: %s', 'cise' ), get_search_query() ) );
} else {
	cise_page_hero( wp_strip_all_tags( get_the_archive_title() ), get_the_archive_description() );
}
?>
<section class="section">
	<div class="wrap">
		<?php if ( have_posts() ) : ?>
			<div class="post-list content">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article <?php post_class(); ?>>
						<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<?php the_excerpt(); ?>
						<a class="link-arrow" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read more', 'cise' ); ?></a>
					</article>
				<?php endwhile; ?>
			</div>
			<div class="pagination"><?php echo paginate_links(); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
		<?php else : ?>
			<p><?php esc_html_e( 'Nothing here yet.', 'cise' ); ?></p>
			<?php get_search_form(); ?>
		<?php endif; ?>
	</div>
</section>
<?php
get_footer();
