<?php
/**
 * Event card (homepage).
 *
 * @package cise
 */

$event = $args['event'];
list( $month, $day ) = cise_event_badge( $event->ID );
$summary = has_excerpt( $event ) ? get_the_excerpt( $event ) : wp_trim_words( wp_strip_all_tags( $event->post_content ), 14 );
?>
<article class="event-card">
	<?php cise_photo( get_post_thumbnail_id( $event ), get_the_title( $event ) ); ?>
	<div class="event-card__body">
		<div class="datebadge"><small><?php echo esc_html( $month ); ?></small><strong><?php echo esc_html( $day ); ?></strong></div>
		<div>
			<h3><a href="<?php echo esc_url( get_permalink( $event ) ); ?>"><?php echo esc_html( get_the_title( $event ) ); ?></a></h3>
			<p><?php echo esc_html( $summary ); ?></p>
			<a class="link-arrow" href="<?php echo esc_url( get_permalink( $event ) ); ?>"><?php esc_html_e( 'Details', 'cise' ); ?></a>
		</div>
	</div>
</article>
