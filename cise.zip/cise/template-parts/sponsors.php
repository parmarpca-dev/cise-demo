<?php
/**
 * Sponsor logo strip. Uses the Sponsors list from CISE Core; shows placeholders until sponsors are added.
 *
 * @package cise
 */

$sponsors = post_type_exists( 'cise_sponsor' ) ? get_posts( array(
	'post_type'      => 'cise_sponsor',
	'posts_per_page' => 20,
	'orderby'        => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
) ) : array();

if ( ! $sponsors && ! current_user_can( 'edit_posts' ) ) {
	return;
}
?>
<section class="section section--tight sponsors">
	<div class="wrap">
		<h2><?php esc_html_e( 'With thanks to our sponsors', 'cise' ); ?></h2>
		<ul>
			<?php if ( $sponsors ) : ?>
				<?php foreach ( $sponsors as $sponsor ) : ?>
					<?php
					$link = get_post_meta( $sponsor->ID, '_cise_sponsor_url', true );
					$logo = get_the_post_thumbnail( $sponsor, 'medium', array( 'alt' => get_the_title( $sponsor ) ) );
					$body = $logo ? $logo : esc_html( get_the_title( $sponsor ) );
					?>
					<li class="<?php echo $logo ? 'has-logo' : ''; ?>">
						<?php if ( $link ) : ?>
							<a href="<?php echo esc_url( $link ); ?>" target="_blank" rel="noopener"><?php echo $body; // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
						<?php else : ?>
							<?php echo $body; // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			<?php else : ?>
				<?php for ( $i = 0; $i < 5; $i++ ) : ?>
					<li><?php esc_html_e( '[Sponsor logo]', 'cise' ); ?></li>
				<?php endfor; ?>
			<?php endif; ?>
		</ul>
	</div>
</section>
