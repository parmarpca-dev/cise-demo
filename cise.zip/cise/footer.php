<?php
/**
 * Site footer.
 *
 * @package cise
 */

$login_url = cise_mod( 'member_login_url' ) ? cise_mod( 'member_login_url' ) : wp_login_url();
$address   = cise_mod( 'address' );
$addr_bits = array_map( 'trim', explode( ',', $address, 2 ) );
?>
</main>

<footer class="site-footer">
	<div class="wrap">
		<div class="footer-cols">
			<div>
				<div class="footer-brand">CISE</div>
				<p><?php echo esc_html( cise_mod( 'footer_blurb' ) ); ?></p>
			</div>
			<div>
				<h2><?php esc_html_e( 'Visit', 'cise' ); ?></h2>
				<p>
					<?php echo esc_html( cise_mod( 'venue_name' ) ); ?><br>
					<?php echo esc_html( $addr_bits[0] ); ?><br>
					<?php echo isset( $addr_bits[1] ) ? esc_html( $addr_bits[1] ) : ''; ?>
					<?php if ( cise_mod( 'office_hours' ) ) : ?>
						<br><?php /* translators: %s: office hours */ printf( esc_html__( 'Office: %s', 'cise' ), esc_html( cise_mod( 'office_hours' ) ) ); ?>
					<?php endif; ?>
				</p>
			</div>
			<div>
				<h2><?php esc_html_e( 'Explore', 'cise' ); ?></h2>
				<?php
				wp_nav_menu( array(
					'theme_location' => 'footer',
					'container'      => false,
					'depth'          => 1,
					'fallback_cb'    => 'cise_menu_fallback',
				) );
				?>
			</div>
			<div>
				<h2><?php esc_html_e( 'Stay in touch', 'cise' ); ?></h2>
				<ul>
					<li><a class="footer-email" href="mailto:<?php echo esc_attr( antispambot( cise_mod( 'email' ) ) ); ?>"><?php echo esc_html( antispambot( cise_mod( 'email' ) ) ); ?></a></li>
					<?php if ( cise_mod( 'phone' ) ) : ?>
						<li><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', cise_mod( 'phone' ) ) ); ?>"><?php echo esc_html( cise_mod( 'phone' ) ); ?></a></li>
					<?php endif; ?>
					<?php if ( cise_mod( 'facebook' ) ) : ?>
						<li><a href="<?php echo esc_url( cise_mod( 'facebook' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Follow us on Facebook', 'cise' ); ?></a></li>
					<?php endif; ?>
					<li><a href="<?php echo esc_url( $login_url ); ?>"><?php esc_html_e( 'Member login', 'cise' ); ?></a></li>
				</ul>
			</div>
		</div>
		<div class="footer-bottom">
			<span>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php esc_html_e( 'Council of India Societies of Edmonton', 'cise' ); ?></span>
			<?php if ( get_privacy_policy_url() ) : ?>
				<a href="<?php echo esc_url( get_privacy_policy_url() ); ?>"><?php esc_html_e( 'Privacy policy', 'cise' ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
