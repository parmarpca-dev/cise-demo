<?php
/**
 * Site header.
 *
 * @package cise
 */

$login_url = cise_mod( 'member_login_url' ) ? cise_mod( 'member_login_url' ) : wp_login_url();
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#main"><?php esc_html_e( 'Skip to content', 'cise' ); ?></a>

<div class="topbar">
	<div class="wrap">
		<div>
			<span class="topbar__addr"><?php echo esc_html( cise_mod( 'venue_name' ) . ' · ' . cise_mod( 'address' ) ); ?></span>
			&nbsp;&nbsp;<a href="mailto:<?php echo esc_attr( antispambot( cise_mod( 'email' ) ) ); ?>"><?php echo esc_html( antispambot( cise_mod( 'email' ) ) ); ?></a>
		</div>
		<div class="topbar__links">
			<?php if ( cise_mod( 'facebook' ) ) : ?>
				<a href="<?php echo esc_url( cise_mod( 'facebook' ) ); ?>" target="_blank" rel="noopener">Facebook</a>
			<?php endif; ?>
			<a class="strong" href="<?php echo esc_url( $login_url ); ?>"><?php esc_html_e( 'Member login', 'cise' ); ?></a>
		</div>
	</div>
</div>

<header class="site-header">
	<div class="wrap">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php
			$logo_id = get_theme_mod( 'custom_logo' );
			if ( $logo_id ) {
				echo wp_get_attachment_image( $logo_id, 'thumbnail', false, array( 'alt' => get_bloginfo( 'name' ) ) );
			} else {
				echo '<img src="' . esc_url( get_theme_file_uri( 'assets/starter/cise-emblem.png' ) ) . '" alt="" width="56" height="56">';
			}
			?>
			<span>
				<span class="brand__name">CISE</span>
				<span class="brand__sub"><?php esc_html_e( 'Council of India Societies of Edmonton', 'cise' ); ?></span>
			</span>
		</a>

		<button class="nav-toggle" aria-controls="main-nav" aria-expanded="false">
			<span></span><span class="screen-reader-text"><?php esc_html_e( 'Menu', 'cise' ); ?></span>
		</button>

		<nav class="main-nav" id="main-nav" aria-label="<?php esc_attr_e( 'Main', 'cise' ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'fallback_cb'    => 'cise_menu_fallback',
				'depth'          => 2,
			) );
			?>
			<a class="btn btn--primary" href="<?php echo esc_url( cise_page_url( 'hall-booking' ) ); ?>"><?php esc_html_e( 'Book the hall', 'cise' ); ?></a>
		</nav>
	</div>
</header>

<main id="main">
