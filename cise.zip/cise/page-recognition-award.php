<?php
/**
 * Recognition Award page (slug "recognition-award"): nomination form + criteria.
 *
 * @package cise
 */

get_header();

$year     = cise_setting( 'award_year', wp_date( 'Y' ) + 1 );
$deadline = cise_setting( 'award_deadline' );
$notified = cise_setting( 'award_notified' );
$ceremony = cise_setting( 'award_ceremony' );
$fmt      = function ( $date ) {
	return $date ? date_i18n( 'M j, Y', strtotime( $date ) ) : __( '[DATE]', 'cise' );
};
$eligibility = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', cise_setting( 'award_eligibility', "Lives in Edmonton or the surrounding area\nCurrently in Grade 12 or post-secondary\nOne nomination per person per year" ) ) ) );

while ( have_posts() ) :
	the_post();
	$badge = $deadline
		/* translators: %s: date */
		? sprintf( __( 'Nominations close %s', 'cise' ), date_i18n( 'F j, Y', strtotime( $deadline ) ) )
		: '';
	/* translators: %s: award year */
	cise_page_hero( sprintf( __( 'India Day Recognition Award %s', 'cise' ), $year ), cise_page_lead(), $badge );
	?>
	<section class="section" id="nominate" style="padding-top:48px">
		<div class="wrap with-sidebar with-sidebar--aside-first">
			<div>
				<?php
				if ( function_exists( 'cise_core_nomination_form' ) ) {
					cise_core_nomination_form();
				} else {
					cise_needs_plugin_notice( __( 'nomination form', 'cise' ) );
				}
				?>
			</div>
			<aside class="sidebar">
				<div class="side-card side-card--green">
					<h2><?php esc_html_e( 'Key dates', 'cise' ); ?></h2>
					<div class="kv"><span><?php esc_html_e( 'Nominations close', 'cise' ); ?></span><strong><?php echo esc_html( $fmt( $deadline ) ); ?></strong></div>
					<div class="kv"><span><?php esc_html_e( 'Recipients notified', 'cise' ); ?></span><strong><?php echo esc_html( $fmt( $notified ) ); ?></strong></div>
					<div class="kv"><span><?php esc_html_e( 'Award ceremony', 'cise' ); ?></span><strong><?php echo esc_html( $fmt( $ceremony ) ); ?></strong></div>
				</div>
				<div class="side-card">
					<h2><?php esc_html_e( 'Eligibility', 'cise' ); ?></h2>
					<ul>
						<?php foreach ( $eligibility as $line ) : ?>
							<li><?php echo esc_html( $line ); ?></li>
						<?php endforeach; ?>
					</ul>
					<p style="margin:14px 0 0"><a class="link-arrow" href="#criteria"><?php esc_html_e( 'Full criteria', 'cise' ); ?></a></p>
				</div>
				<div class="side-card side-card--white">
					<h2><?php esc_html_e( 'Have ready', 'cise' ); ?></h2>
					<p><?php esc_html_e( 'A transcript or report card, plus a reference letter and photo if you have them.', 'cise' ); ?></p>
					<p style="margin:0;font-size:.85rem"><?php esc_html_e( 'Questions?', 'cise' ); ?> <a href="mailto:<?php echo esc_attr( antispambot( cise_mod( 'email' ) ) ); ?>"><?php echo esc_html( antispambot( cise_mod( 'email' ) ) ); ?></a></p>
				</div>
			</aside>
		</div>
	</section>
	<section class="section section--cream">
		<div class="wrap">
			<div class="content"><?php the_content(); ?></div>
		</div>
	</section>
	<?php
endwhile;

get_footer();
