<?php
/**
 * Events page (slug "events"): upcoming and past events from CISE Core.
 *
 * @package cise
 */

get_header();

while ( have_posts() ) :
	the_post();
	cise_page_hero( get_the_title(), cise_page_lead() );
endwhile;

$upcoming = cise_upcoming_events( 50 );
$past     = post_type_exists( 'cise_event' ) ? get_posts( array(
	'post_type'      => 'cise_event',
	'posts_per_page' => 6,
	'meta_key'       => '_cise_event_date',
	'orderby'        => 'meta_value',
	'order'          => 'DESC',
	'meta_query'     => array(
		array(
			'key'     => '_cise_event_date',
			'value'   => wp_date( 'Y-m-01' ),
			'compare' => '<',
			'type'    => 'DATE',
		),
	),
) ) : array();

/**
 * One row in the events list.
 */
$cise_event_row = function ( $event ) {
	list( $month, $day ) = cise_event_badge( $event->ID );
	$location            = get_post_meta( $event->ID, '_cise_event_location', true );
	$summary             = has_excerpt( $event ) ? get_the_excerpt( $event ) : wp_trim_words( wp_strip_all_tags( $event->post_content ), 22 );
	?>
	<div class="event-row">
		<div class="datebadge"><small><?php echo esc_html( $month ); ?></small><strong><?php echo esc_html( $day ); ?></strong></div>
		<div>
			<h3><a href="<?php echo esc_url( get_permalink( $event ) ); ?>"><?php echo esc_html( get_the_title( $event ) ); ?></a></h3>
			<p><?php echo esc_html( cise_event_date_text( $event->ID ) . ( $location ? ' · ' . $location : '' ) ); ?></p>
			<?php if ( $summary ) : ?>
				<p><?php echo esc_html( $summary ); ?></p>
			<?php endif; ?>
		</div>
		<a class="link-arrow" href="<?php echo esc_url( get_permalink( $event ) ); ?>"><?php esc_html_e( 'Details', 'cise' ); ?></a>
	</div>
	<?php
};
?>
<section class="section">
	<div class="wrap">
		<div class="with-sidebar">
			<div>
				<h2><?php esc_html_e( 'Coming up', 'cise' ); ?></h2>
				<?php if ( $upcoming ) : ?>
					<div style="border-top:2px solid var(--ink)">
						<?php array_map( $cise_event_row, $upcoming ); ?>
					</div>
				<?php elseif ( post_type_exists( 'cise_event' ) ) : ?>
					<p><?php esc_html_e( 'New events will be posted here soon.', 'cise' ); ?></p>
				<?php else : ?>
					<?php cise_needs_plugin_notice( __( 'events calendar', 'cise' ) ); ?>
				<?php endif; ?>

				<?php if ( $past ) : ?>
					<h2 style="margin-top:64px"><?php esc_html_e( 'Recent events', 'cise' ); ?></h2>
					<div style="border-top:2px solid var(--ink)">
						<?php array_map( $cise_event_row, $past ); ?>
					</div>
				<?php endif; ?>

				<div class="content" style="margin-top:48px"><?php the_content(); ?></div>
			</div>
			<aside class="sidebar">
				<div class="side-card">
					<h2><?php esc_html_e( 'Our yearly celebrations', 'cise' ); ?></h2>
					<?php foreach ( cise_yearly_celebrations() as $row ) : ?>
						<div class="kv"><span><?php echo esc_html( $row[0] ); ?></span><strong><?php echo esc_html( $row[1] ); ?></strong></div>
					<?php endforeach; ?>
				</div>
				<?php if ( function_exists( 'cise_core_ics_url' ) ) : ?>
					<div class="side-card side-card--white">
						<h2><?php esc_html_e( 'Add to your calendar', 'cise' ); ?></h2>
						<p><?php esc_html_e( 'Subscribe once and new CISE events appear in Google, Apple or Outlook calendar automatically.', 'cise' ); ?></p>
						<a class="link-arrow" href="<?php echo esc_url( cise_core_ics_url( 'events' ) ); ?>"><?php esc_html_e( 'Subscribe to events', 'cise' ); ?></a>
					</div>
				<?php endif; ?>
			</aside>
		</div>
	</div>
</section>
<?php
get_footer();
