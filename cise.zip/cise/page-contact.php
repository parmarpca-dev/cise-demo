<?php
/**
 * Contact page (slug "contact").
 *
 * @package cise
 */

get_header();

$address = cise_mod( 'venue_name' ) . ', ' . cise_mod( 'address' );

while ( have_posts() ) :
	the_post();
	cise_page_hero( get_the_title(), cise_page_lead() );
	?>
	<section class="section" style="padding-top:48px">
		<div class="wrap with-sidebar">
			<div>
				<div class="content" style="margin-bottom:28px"><?php the_content(); ?></div>
				<?php
				if ( function_exists( 'cise_core_contact_form' ) ) {
					cise_core_contact_form();
				} else {
					cise_needs_plugin_notice( __( 'contact form', 'cise' ) );
				}
				?>
			</div>
			<aside class="sidebar">
				<div class="side-card side-card--green">
					<h2><?php esc_html_e( 'Visit', 'cise' ); ?></h2>
					<p style="color:#d7e6df;margin:0"><?php echo esc_html( cise_mod( 'venue_name' ) ); ?><br><?php echo esc_html( cise_mod( 'address' ) ); ?></p>
				</div>
				<div class="side-card">
					<h2><?php esc_html_e( 'Get in touch', 'cise' ); ?></h2>
					<div class="kv"><span><?php esc_html_e( 'Email', 'cise' ); ?></span><a href="mailto:<?php echo esc_attr( antispambot( cise_mod( 'email' ) ) ); ?>"><?php echo esc_html( antispambot( cise_mod( 'email' ) ) ); ?></a></div>
					<?php if ( cise_mod( 'phone' ) ) : ?>
						<div class="kv"><span><?php esc_html_e( 'Phone', 'cise' ); ?></span><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', cise_mod( 'phone' ) ) ); ?>"><?php echo esc_html( cise_mod( 'phone' ) ); ?></a></div>
					<?php endif; ?>
					<?php if ( cise_mod( 'office_hours' ) ) : ?>
						<div class="kv"><span><?php esc_html_e( 'Office hours', 'cise' ); ?></span><span><?php echo esc_html( cise_mod( 'office_hours' ) ); ?></span></div>
					<?php endif; ?>
					<?php if ( cise_mod( 'facebook' ) ) : ?>
						<div class="kv"><span>Facebook</span><a href="<?php echo esc_url( cise_mod( 'facebook' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Follow us', 'cise' ); ?></a></div>
					<?php endif; ?>
				</div>
				<div class="photo" style="min-height:260px">
					<iframe title="<?php esc_attr_e( 'Map to the India Centre', 'cise' ); ?>" src="https://maps.google.com/maps?q=<?php echo rawurlencode( $address ); ?>&amp;z=15&amp;output=embed" style="position:absolute;inset:0;width:100%;height:100%;border:0" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
				</div>
			</aside>
		</div>
	</section>
	<?php
endwhile;

get_footer();
