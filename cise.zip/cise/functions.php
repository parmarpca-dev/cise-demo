<?php
/**
 * CISE Community theme functions.
 *
 * @package cise
 */

defined( 'ABSPATH' ) || exit;

define( 'CISE_THEME_VERSION', '1.0.0' );

require get_template_directory() . '/inc/helpers.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/setup.php';

add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'cise', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array(
		'height'      => 200,
		'width'       => 200,
		'flex-height' => true,
		'flex-width'  => true,
	) );

	add_editor_style( array( cise_fonts_url(), 'assets/css/main.css' ) );

	add_theme_support( 'editor-color-palette', array(
		array( 'name' => __( 'CISE green', 'cise' ), 'slug' => 'cise-green', 'color' => '#0e4a37' ),
		array( 'name' => __( 'Deep green', 'cise' ), 'slug' => 'cise-deep', 'color' => '#0a3a2c' ),
		array( 'name' => __( 'Saffron', 'cise' ), 'slug' => 'cise-saffron', 'color' => '#f08a24' ),
		array( 'name' => __( 'Cream', 'cise' ), 'slug' => 'cise-cream', 'color' => '#f4efe7' ),
		array( 'name' => __( 'Ink', 'cise' ), 'slug' => 'cise-ink', 'color' => '#1b1d1c' ),
		array( 'name' => __( 'White', 'cise' ), 'slug' => 'white', 'color' => '#ffffff' ),
	) );

	register_nav_menus( array(
		'primary' => __( 'Main menu', 'cise' ),
		'footer'  => __( 'Footer: Explore', 'cise' ),
	) );

	set_post_thumbnail_size( 900, 600, true );
	add_image_size( 'cise-card', 720, 420, true );
} );

add_action( 'init', function () {
	register_block_style( 'core/group', array(
		'name'  => 'cise-card',
		'label' => __( 'CISE card', 'cise' ),
	) );
} );

/**
 * Google Fonts URL for Bricolage Grotesque.
 */
function cise_fonts_url() {
	return 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;12..96,500;12..96,600;12..96,700;12..96,800&display=swap';
}

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'cise-fonts', cise_fonts_url(), array(), null );
	// Version by file time so browsers pick up edits straight away.
	$css = get_template_directory() . '/assets/css/main.css';
	$js  = get_template_directory() . '/assets/js/main.js';
	wp_enqueue_style( 'cise-main', get_template_directory_uri() . '/assets/css/main.css', array(), (string) filemtime( $css ) );
	wp_enqueue_script( 'cise-main', get_template_directory_uri() . '/assets/js/main.js', array(), (string) filemtime( $js ), true );
} );

add_filter( 'wp_resource_hints', function ( $urls, $relation ) {
	if ( 'preconnect' === $relation ) {
		$urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' );
	}
	return $urls;
}, 10, 2 );

/**
 * The "Book the hall" button is rendered by the header, so drop any menu item
 * pointing at the hall page from the main menu to avoid showing it twice.
 */
add_filter( 'wp_nav_menu_objects', function ( $items, $args ) {
	if ( 'primary' !== $args->theme_location ) {
		return $items;
	}
	$hall = cise_page_url( 'hall-booking' );
	return array_filter( $items, function ( $item ) use ( $hall ) {
		return untrailingslashit( $item->url ) !== untrailingslashit( $hall );
	} );
}, 10, 2 );

add_filter( 'excerpt_length', function () {
	return 24;
} );

add_filter( 'excerpt_more', function () {
	return '&hellip;';
} );
