<?php
/**
 * Homepage.
 *
 * @package cise
 */

get_header();

$events     = cise_upcoming_events( 3 );
$next       = $events ? $events[0] : null;
$award_year = cise_setting( 'award_year', wp_date( 'Y' ) + 1 );
$deadline   = cise_setting( 'award_deadline' );
$ceremony   = cise_setting( 'award_ceremony' );
$award_open = function_exists( 'cise_core_award_is_open' ) ? cise_core_award_is_open() : true;
$capacity   = cise_setting( 'hall_capacity', '[CAPACITY]' );
$hall_rates = array_filter( array( (float) cise_setting( 'rate_main_hour', 0 ), (float) cise_setting( 'rate_base_hour', 0 ) ) );
$rate_from  = $hall_rates ? min( $hall_rates ) : '';
?>

<section class="hero">
	<div class="wrap">
		<div>
			<span class="pill"><?php echo esc_html( cise_mod( 'hero_badge' ) ); ?></span>
			<h1><?php echo esc_html( cise_mod( 'hero_title' ) ); ?></h1>
			<p class="hero__lead"><?php echo esc_html( cise_mod( 'hero_lead' ) ); ?></p>
			<div class="hero__actions">
				<a class="btn btn--primary" href="<?php echo esc_url( cise_page_url( 'events' ) ); ?>"><?php esc_html_e( 'See upcoming events', 'cise' ); ?></a>
				<a class="btn btn--outline" href="<?php echo esc_url( cise_page_url( 'hall-booking' ) ); ?>"><?php esc_html_e( 'Hall booking', 'cise' ); ?></a>
			</div>
		</div>
		<div class="hero__media">
			<?php cise_photo( cise_mod( 'hero_image_1' ), __( 'India Day celebration, wide crowd shot', 'cise' ) ); ?>
			<?php cise_photo( cise_mod( 'hero_image_2' ), __( 'dance performance', 'cise' ) ); ?>
			<?php if ( $next ) : ?>
				<a class="next-up" href="<?php echo esc_url( get_permalink( $next ) ); ?>">
					<small><?php esc_html_e( 'Next up', 'cise' ); ?></small>
					<strong><?php echo esc_html( get_the_title( $next ) ); ?></strong>
					<span><?php echo esc_html( cise_event_date_text( $next->ID ) ); ?></span>
				</a>
			<?php else : ?>
				<a class="next-up" href="<?php echo esc_url( cise_page_url( 'events' ) ); ?>">
					<small><?php esc_html_e( 'Next up', 'cise' ); ?></small>
					<strong><?php esc_html_e( 'See our events calendar', 'cise' ); ?></strong>
				</a>
			<?php endif; ?>
		</div>
	</div>
</section>

<section class="section">
	<div class="wrap">
		<div class="section-head">
			<div>
				<span class="eyebrow"><?php esc_html_e( 'What we do', 'cise' ); ?></span>
				<h2><?php echo esc_html( cise_mod( 'wwd_title' ) ); ?></h2>
			</div>
			<a class="link-arrow" href="<?php echo esc_url( cise_page_url( 'about' ) ); ?>"><?php esc_html_e( 'Our objectives and history', 'cise' ); ?></a>
		</div>
		<div class="grid grid--4">
			<?php
			$cards = array(
				1 => array( 'people', cise_page_url( 'events' ) ),
				2 => array( 'document', cise_page_url( 'events' ) ),
				3 => array( 'award', cise_page_url( 'recognition-award' ) ),
				4 => array( 'home', cise_page_url( 'hall-booking' ) ),
			);
			foreach ( $cards as $i => $card ) :
				?>
				<div class="card">
					<?php echo cise_icon( $card[0] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<h3><?php echo esc_html( cise_mod( "wwd_{$i}_title" ) ); ?></h3>
					<p><?php echo esc_html( cise_mod( "wwd_{$i}_text" ) ); ?></p>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="section section--cream">
	<div class="wrap">
		<div class="section-head">
			<div>
				<span class="eyebrow"><?php esc_html_e( 'Events calendar', 'cise' ); ?></span>
				<h2><?php esc_html_e( 'Celebrate with us all year', 'cise' ); ?></h2>
			</div>
			<a class="link-arrow" href="<?php echo esc_url( cise_page_url( 'events' ) ); ?>"><?php esc_html_e( 'Full calendar', 'cise' ); ?></a>
		</div>

		<?php if ( $events ) : ?>
			<div class="grid grid--3">
				<?php foreach ( $events as $event ) : ?>
					<?php get_template_part( 'template-parts/event-card', null, array( 'event' => $event ) ); ?>
				<?php endforeach; ?>
			</div>
		<?php elseif ( ! post_type_exists( 'cise_event' ) ) : ?>
			<?php cise_needs_plugin_notice( __( 'upcoming events', 'cise' ) ); ?>
		<?php endif; ?>

		<div class="yearly">
			<h3><?php esc_html_e( 'Our yearly celebrations', 'cise' ); ?></h3>
			<ul>
				<?php foreach ( cise_yearly_celebrations() as $row ) : ?>
					<li><span><?php echo esc_html( $row[0] ); ?></span><span><?php echo esc_html( $row[1] ); ?></span></li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
</section>

<section class="section">
	<div class="wrap">
		<div class="award-band">
			<div>
				<?php if ( $award_open && $deadline ) : ?>
					<span class="pill pill--saffron">
						<?php
						/* translators: %s: deadline date */
						echo esc_html( sprintf( __( 'Nominations open · deadline %s', 'cise' ), date_i18n( 'F j, Y', strtotime( $deadline ) ) ) );
						?>
					</span>
				<?php elseif ( ! $award_open ) : ?>
					<span class="pill pill--saffron"><?php esc_html_e( 'Nominations are closed', 'cise' ); ?></span>
				<?php endif; ?>
				<h2>
					<?php
					/* translators: %s: award year */
					echo esc_html( sprintf( __( 'India Day Recognition Award %s', 'cise' ), $award_year ) );
					?>
				</h2>
				<p>
					<?php
					esc_html_e( 'Honouring meritorious students and community members.', 'cise' );
					if ( $ceremony ) {
						echo ' ';
						/* translators: %s: ceremony date */
						echo esc_html( sprintf( __( 'Awards are presented at the India (Republic) Day celebration on %s.', 'cise' ), date_i18n( 'F j, Y', strtotime( $ceremony ) ) ) );
					}
					?>
				</p>
				<div class="award-band__actions">
					<a class="btn btn--light" href="<?php echo esc_url( cise_page_url( 'recognition-award' ) ); ?>#nominate"><?php esc_html_e( 'Submit a nomination', 'cise' ); ?></a>
					<a class="btn btn--ghost-light link-arrow" href="<?php echo esc_url( cise_page_url( 'recognition-award' ) ); ?>#criteria"><?php esc_html_e( 'Eligibility & criteria', 'cise' ); ?></a>
				</div>
			</div>
			<ol class="steps">
				<li><?php esc_html_e( "Fill in the online form with the nominee's details", 'cise' ); ?></li>
				<li><?php esc_html_e( 'Upload transcripts or supporting documents', 'cise' ); ?></li>
				<li><?php esc_html_e( 'The committee reviews and contacts recipients', 'cise' ); ?></li>
			</ol>
		</div>
	</div>
</section>

<section class="section" style="padding-top:0">
	<div class="wrap split">
		<?php cise_photo( cise_mod( 'hall_image' ), __( 'main hall set up for an event', 'cise' ) ); ?>
		<div>
			<span class="eyebrow"><?php esc_html_e( 'Hall booking', 'cise' ); ?></span>
			<h2><?php echo esc_html( cise_mod( 'hall_title' ) ); ?></h2>
			<p><?php echo esc_html( cise_mod( 'hall_text' ) ); ?></p>
			<div class="stats">
				<div class="stat"><small><?php esc_html_e( 'Capacity', 'cise' ); ?></small><strong><?php echo esc_html( $capacity ); ?> <?php esc_html_e( 'guests', 'cise' ); ?></strong></div>
				<div class="stat"><small><?php esc_html_e( 'From', 'cise' ); ?></small><strong><?php echo $rate_from ? esc_html( '$' . number_format_i18n( (float) $rate_from, 0 ) ) : '[RATE]'; ?> / <?php esc_html_e( 'hour', 'cise' ); ?></strong></div>
			</div>
			<a class="btn btn--primary" href="<?php echo esc_url( cise_page_url( 'hall-booking' ) ); ?>"><?php esc_html_e( 'Check availability', 'cise' ); ?></a>
		</div>
	</div>
</section>

<section class="section section--cream">
	<div class="wrap">
		<span class="eyebrow"><?php esc_html_e( 'Get involved', 'cise' ); ?></span>
		<h2 style="margin-bottom:32px"><?php esc_html_e( 'Find your place at CISE', 'cise' ); ?></h2>
		<div class="grid grid--4">
			<?php
			$anchors = array( 1 => 'youth-wing', 2 => 'womens-wing', 3 => 'library', 4 => 'member-associations' );
			foreach ( $anchors as $i => $anchor ) :
				?>
				<div class="card">
					<h3 style="margin-top:0"><?php echo esc_html( cise_mod( "gi_{$i}_title" ) ); ?></h3>
					<p><?php echo esc_html( cise_mod( "gi_{$i}_text" ) ); ?></p>
					<a class="link-arrow" href="<?php echo esc_url( cise_page_url( 'community' ) . '#' . $anchor ); ?>"><?php esc_html_e( 'Learn more', 'cise' ); ?></a>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php get_template_part( 'template-parts/sponsors' ); ?>

<?php
get_footer();
