<?php
/**
 * Not found.
 *
 * @package cise
 */

get_header();
cise_page_hero( __( 'Page not found', 'cise' ), __( "The page you're looking for has moved or no longer exists.", 'cise' ) );
?>
<section class="section">
	<div class="wrap content">
		<p><a class="btn btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to the homepage', 'cise' ); ?></a></p>
		<?php get_search_form(); ?>
	</div>
</section>
<?php
get_footer();
