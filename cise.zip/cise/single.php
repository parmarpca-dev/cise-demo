<?php
/**
 * Single news post.
 *
 * @package cise
 */

get_header();

while ( have_posts() ) :
	the_post();
	cise_page_hero( get_the_title(), get_the_date() );
	?>
	<section class="section">
		<div class="wrap">
			<?php if ( has_post_thumbnail() ) : ?>
				<div style="margin-bottom:40px;max-width:780px"><?php the_post_thumbnail( 'large', array( 'style' => 'border-radius:16px' ) ); ?></div>
			<?php endif; ?>
			<div class="content"><?php the_content(); ?></div>
		</div>
	</section>
	<?php
endwhile;

get_footer();
