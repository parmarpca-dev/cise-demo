<?php
/**
 * Single event.
 *
 * @package cise
 */

get_header();

while ( have_posts() ) :
	the_post();
	$location = get_post_meta( get_the_ID(), '_cise_event_location', true );
	$time     = get_post_meta( get_the_ID(), '_cise_event_time', true );
	?>
	<section class="page-hero">
		<div class="wrap">
			<a class="back-link" href="<?php echo esc_url( cise_page_url( 'events' ) ); ?>"><?php esc_html_e( 'All events', 'cise' ); ?></a>
			<h1><?php the_title(); ?></h1>
			<div class="event-meta">
				<span><strong><?php esc_html_e( 'When:', 'cise' ); ?></strong> <?php echo esc_html( cise_event_date_text( get_the_ID() ) . ( $time ? ' · ' . $time : '' ) ); ?></span>
				<?php if ( $location ) : ?>
					<span><strong><?php esc_html_e( 'Where:', 'cise' ); ?></strong> <?php echo esc_html( $location ); ?></span>
				<?php endif; ?>
			</div>
			<?php if ( has_excerpt() ) : ?>
				<p><?php echo esc_html( get_the_excerpt() ); ?></p>
			<?php endif; ?>
		</div>
	</section>
	<section class="section">
		<div class="wrap">
			<?php if ( has_post_thumbnail() ) : ?>
				<div style="margin-bottom:40px;max-width:900px"><?php the_post_thumbnail( 'large', array( 'style' => 'border-radius:16px' ) ); ?></div>
			<?php endif; ?>
			<div class="content"><?php the_content(); ?></div>
		</div>
	</section>
	<?php
endwhile;

get_footer();
