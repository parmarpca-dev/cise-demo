<?php
/**
 * Default page template (About, Community, Gallery, Resources…).
 *
 * @package cise
 */

get_header();

while ( have_posts() ) :
	the_post();
	cise_page_hero( get_the_title(), cise_page_lead() );
	?>
	<section class="section">
		<div class="wrap">
			<?php if ( has_post_thumbnail() ) : ?>
				<div style="margin-bottom:40px"><?php the_post_thumbnail( 'large', array( 'style' => 'border-radius:16px;width:100%;max-height:460px;object-fit:cover' ) ); ?></div>
			<?php endif; ?>
			<div class="content">
				<?php the_content(); ?>
			</div>
		</div>
	</section>
	<?php
endwhile;

get_footer();
