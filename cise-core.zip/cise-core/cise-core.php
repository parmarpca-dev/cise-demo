<?php
/**
 * Plugin Name: CISE Core
 * Description: Events, sponsors, hall booking calendar (with Google Calendar sync), India Day Award nominations and the contact form for the Council of India Societies of Edmonton.
 * Version: 1.0.0
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * Author: ParmarMedia
 * License: GPL-2.0-or-later
 * Text Domain: cise-core
 *
 * @package cise-core
 */

defined( 'ABSPATH' ) || exit;

define( 'CISE_CORE_VERSION', '1.0.0' );
define( 'CISE_CORE_FILE', __FILE__ );
define( 'CISE_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'CISE_CORE_URL', plugin_dir_url( __FILE__ ) );

/** Who can review bookings and nominations (Editors and Administrators). */
define( 'CISE_CORE_CAP', 'edit_others_posts' );

require CISE_CORE_DIR . 'includes/settings.php';
require CISE_CORE_DIR . 'includes/post-types.php';
require CISE_CORE_DIR . 'includes/mail.php';
require CISE_CORE_DIR . 'includes/gcal.php';
require CISE_CORE_DIR . 'includes/booking.php';
require CISE_CORE_DIR . 'includes/booking-admin.php';
require CISE_CORE_DIR . 'includes/nominations.php';
require CISE_CORE_DIR . 'includes/contact.php';
require CISE_CORE_DIR . 'includes/ics.php';

register_activation_hook( __FILE__, function () {
	cise_core_register_post_types();
	cise_core_private_dir();
	if ( ! get_option( 'cise_core_ics_key' ) ) {
		update_option( 'cise_core_ics_key', wp_generate_password( 24, false ) );
	}
	flush_rewrite_rules();
} );

register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

add_action( 'wp_enqueue_scripts', function () {
	$ver = function ( $file ) {
		return (string) filemtime( CISE_CORE_DIR . 'assets/' . $file );
	};
	wp_register_style( 'cise-core', CISE_CORE_URL . 'assets/cise-core.css', array(), $ver( 'cise-core.css' ) );
	wp_register_script( 'cise-booking', CISE_CORE_URL . 'assets/booking.js', array(), $ver( 'booking.js' ), true );
	wp_register_script( 'cise-nomination', CISE_CORE_URL . 'assets/nomination.js', array(), $ver( 'nomination.js' ), true );
} );

/**
 * Private folder for uploaded nomination documents (not web-browsable).
 *
 * @return string Absolute path with trailing slash.
 */
function cise_core_private_dir() {
	$uploads = wp_upload_dir( null, false );
	$dir     = trailingslashit( $uploads['basedir'] ) . 'cise-private/';
	if ( ! is_dir( $dir ) ) {
		wp_mkdir_p( $dir );
	}
	if ( ! file_exists( $dir . '.htaccess' ) ) {
		file_put_contents( $dir . '.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	if ( ! file_exists( $dir . 'index.php' ) ) {
		file_put_contents( $dir . 'index.php', "<?php // Silence.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	return $dir;
}

/**
 * Render a front-end notice box.
 */
function cise_core_notice( $message, $type = 'info' ) {
	printf( '<div class="notice notice--%s" role="status">%s</div>', esc_attr( $type ), wp_kses_post( $message ) );
}
