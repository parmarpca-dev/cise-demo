/* CISE Core: hall booking calendar. Config comes from CISE_BOOKING (inline JSON). */
(function () {
	var root = document.querySelector('[data-cise-booking]');
	if (!root || typeof CISE_BOOKING === 'undefined') return;

	var C = CISE_BOOKING;
	var T = C.i18n;
	var grid = root.querySelector('.cb-cal__grid');
	var title = root.querySelector('.cb-cal__title');
	var navPrev = root.querySelector('[data-nav="-1"]');
	var navNext = root.querySelector('[data-nav="1"]');
	var timesBox = root.querySelector('.cb-times');
	var busyText = root.querySelector('.cb-busy');
	var startSel = root.querySelector('select[name="start"]');
	var endSel = root.querySelector('select[name="end"]');
	var form = root.querySelector('.cb-form');
	var submit = root.querySelector('.cb-submit');
	var errorBox = root.querySelector('.cb-error');
	var orgType = form.querySelector('[name="org_type"]');
	var memberRow = form.querySelector('[data-member-only]');
	var quickBox = root.querySelector('.cb-quick');
	var hallInputs = root.querySelectorAll('input[name="hall"]');
	var opened = Date.now();

	var firstDate = C.window[0];
	var lastDate = C.window[1];
	var month = firstDate.slice(0, 7);
	var cache = {};
	var picked = null;
	var hall = 'main';

	/* ---------- helpers ---------- */

	function pad(n) { return (n < 10 ? '0' : '') + n; }
	function hhmm(m) { return m >= 1440 ? '24:00' : pad(Math.floor(m / 60)) + ':' + pad(m % 60); }
	function label(m) {
		var d = new Date(2000, 0, 1, Math.floor(m / 60) % 24, m % 60);
		if (m >= 1440) return 'midnight';
		return d.toLocaleTimeString(C.locale, { hour: 'numeric', minute: '2-digit' }).toLowerCase();
	}
	function parseDate(s) { var p = s.split('-'); return new Date(+p[0], +p[1] - 1, +(p[2] || 1)); }
	function addMonths(ym, n) {
		var d = parseDate(ym + '-01');
		d.setMonth(d.getMonth() + n);
		return d.getFullYear() + '-' + pad(d.getMonth() + 1);
	}
	function money(n) {
		return '$' + n.toLocaleString(C.locale, { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 });
	}
	function overlaps(s, e, busy) {
		for (var i = 0; i < busy.length; i++) if (s < busy[i][1] && e > busy[i][0]) return true;
		return false;
	}

	/* ---------- calendar ---------- */

	function load(ym) {
		var key = hall + '|' + ym;
		if (cache[key]) return Promise.resolve(cache[key]);
		grid.classList.add('is-loading');
		return fetch(C.api + 'availability?month=' + ym + '&hall=' + hall, { credentials: 'same-origin' })
			.then(function (r) { if (!r.ok) throw new Error(); return r.json(); })
			.then(function (data) { cache[key] = data.days; return data.days; })
			.finally(function () { grid.classList.remove('is-loading'); });
	}

	function render() {
		var d = parseDate(month + '-01');
		title.textContent = d.toLocaleDateString(C.locale, { month: 'long', year: 'numeric' });
		navPrev.disabled = month <= firstDate.slice(0, 7);
		navNext.disabled = month >= lastDate.slice(0, 7);

		load(month).then(function (days) {
			grid.innerHTML = '';
			for (var i = 0; i < 7; i++) {
				var dow = new Date(2023, 0, 1 + ((i + C.weekStart) % 7)); // 2023-01-01 is a Sunday.
				var h = document.createElement('div');
				h.className = 'cb-dow';
				h.textContent = dow.toLocaleDateString(C.locale, { weekday: 'short' });
				grid.appendChild(h);
			}
			var offset = (d.getDay() - C.weekStart + 7) % 7;
			for (var b = 0; b < offset; b++) grid.appendChild(document.createElement('span'));

			Object.keys(days).forEach(function (date) {
				var info = days[date];
				var btn = document.createElement('button');
				btn.type = 'button';
				btn.className = 'cb-day is-' + info.s + (date === picked ? ' is-picked' : '');
				btn.textContent = +date.slice(8);
				btn.dataset.date = date;
				var bookable = info.s === 'open' || info.s === 'partial';
				btn.disabled = !bookable;
				btn.setAttribute('aria-label', parseDate(date).toLocaleDateString(C.locale, { weekday: 'long', month: 'long', day: 'numeric' }) + (bookable ? '' : ' – unavailable'));
				if (date === picked) btn.setAttribute('aria-pressed', 'true');
				grid.appendChild(btn);
			});

			// After a refresh, re-check the picked day (it may have been taken meanwhile).
			if (picked && picked.slice(0, 7) === month) {
				var info = days[picked];
				if (info && (info.s === 'open' || info.s === 'partial')) {
					buildTimes();
				} else {
					picked = null;
					timesBox.hidden = true;
					startSel.innerHTML = '';
					endSel.innerHTML = '';
					quickBox.innerHTML = '';
					summary();
				}
			}
		}).catch(function () {
			grid.innerHTML = '<p class="cb-error" style="grid-column:1/-1">' + T.loadError + '</p>';
		});
	}

	grid.addEventListener('click', function (e) {
		var btn = e.target.closest('.cb-day');
		if (!btn || btn.disabled) return;
		picked = btn.dataset.date;
		grid.querySelectorAll('.is-picked').forEach(function (el) {
			el.classList.remove('is-picked');
			el.removeAttribute('aria-pressed');
		});
		btn.classList.add('is-picked');
		btn.setAttribute('aria-pressed', 'true');
		buildTimes();
	});

	hallInputs.forEach(function (input) {
		input.addEventListener('change', function () {
			if (!input.checked) return;
			hall = input.value;
			if (picked) month = picked.slice(0, 7);
			render(); // Re-checks the picked day for the new hall.
			summary();
		});
	});

	[navPrev, navNext].forEach(function (b) {
		b.addEventListener('click', function () {
			month = addMonths(month, +b.dataset.nav);
			render();
		});
	});

	/* ---------- times ---------- */

	function busyFor(date) {
		var m = cache[hall + '|' + date.slice(0, 7)];
		return (m && m[date] && m[date].b) || [];
	}

	function buildTimes() {
		var busy = busyFor(picked);
		timesBox.hidden = false;
		busyText.textContent = busy.length
			? T.booked + ' ' + busy.map(function (r) {
				return label(Math.max(r[0], C.open)) + ' – ' + label(Math.min(r[1], C.close));
			}).filter(function (s, i, all) { return all.indexOf(s) === i; }).join(', ')
			: T.allFree;

		var prev = startSel.value;
		startSel.innerHTML = '';
		for (var s = C.open; s + C.min <= C.close; s += C.step) {
			if (overlaps(s, s + C.min, busy)) continue;
			startSel.add(new Option(label(s), hhmm(s)));
		}
		if (prev && startSel.querySelector('option[value="' + prev + '"]')) startSel.value = prev;
		buildQuick(busy);
		buildEnds();
	}

	// Half-day / full-day shortcuts that are free on the picked day.
	function buildQuick(busy) {
		quickBox.innerHTML = '';
		var free = C.halls[hall].packages.filter(function (p) {
			return p.s >= C.open && p.e <= C.close && !overlaps(p.s, p.e, busy);
		});
		if (!free.length) return;
		var lead = document.createElement('span');
		lead.textContent = T.quick;
		quickBox.appendChild(lead);
		free.forEach(function (p) {
			var b = document.createElement('button');
			b.type = 'button';
			b.className = 'cb-chip';
			b.textContent = p.label + ' · ' + money(p.price);
			b.addEventListener('click', function () {
				startSel.value = hhmm(p.s);
				buildEnds();
				endSel.value = hhmm(p.e);
				summary();
			});
			quickBox.appendChild(b);
		});
	}

	function buildEnds() {
		var busy = busyFor(picked);
		var s = toMin(startSel.value);
		var prev = endSel.value;
		endSel.innerHTML = '';
		if (isNaN(s)) { summary(); return; }
		var limit = C.close;
		busy.forEach(function (r) { if (r[0] >= s + C.min && r[0] < limit) limit = r[0]; });
		for (var e = s + C.min; e <= limit; e += C.step) endSel.add(new Option(label(e), hhmm(e)));
		if (prev && endSel.querySelector('option[value="' + prev + '"]')) endSel.value = prev;
		summary();
	}

	function toMin(v) { if (!v) return NaN; var p = v.split(':'); return +p[0] * 60 + +p[1]; }

	startSel.addEventListener('change', buildEnds);
	endSel.addEventListener('change', summary);

	/* ---------- summary ---------- */

	function setSum(key, text) { root.querySelector('[data-sum="' + key + '"]').textContent = text; }

	// Same rule as cise_booking_quote(): the cheaper of hourly and any package covering the time.
	function quote(s, e) {
		var h = C.halls[hall];
		var hours = (e - s) / 60;
		var best = { total: Math.round(hours * h.hourly * 100) / 100, label: money(h.hourly) + T.perHr + ' × ' + hours + ' ' + T.hrs };
		h.packages.forEach(function (p) {
			if (s >= p.s && e <= p.e && p.price < best.total) best = { total: p.price, label: p.label };
		});
		return best;
	}

	function summary() {
		memberRow.hidden = orgType.value !== 'member';
		var h = C.halls[hall];
		var s = toMin(startSel.value);
		var e = toMin(endSel.value);
		var ready = picked && !isNaN(s) && !isNaN(e);

		setSum('hall', h.name);
		setSum('date', picked ? parseDate(picked).toLocaleDateString(C.locale, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }) : '—');
		setSum('time', ready ? label(s) + ' – ' + label(e) : '—');

		if (ready && h.hourly) {
			var q = quote(s, e);
			setSum('rate', q.label);
			setSum('total', money(q.total));
		} else {
			setSum('rate', h.hourly ? money(h.hourly) + ' / hr' : ready ? T.tbd : '—');
			setSum('total', ready ? T.tbd : '—');
		}
		submit.disabled = !ready;
	}

	orgType.addEventListener('change', summary);

	/* ---------- submit ---------- */

	function clearErrors() {
		errorBox.hidden = true;
		form.querySelectorAll('.is-invalid').forEach(function (el) { el.classList.remove('is-invalid'); });
		form.querySelectorAll('.cb-field-err').forEach(function (el) { el.remove(); });
	}

	function showError(msg, fields) {
		errorBox.textContent = msg;
		errorBox.hidden = false;
		var first = null;
		Object.keys(fields || {}).forEach(function (name) {
			var input = form.querySelector('[name="' + name + '"]');
			if (!input) return;
			input.classList.add('is-invalid');
			var span = document.createElement('span');
			span.className = 'cb-field-err';
			span.textContent = fields[name];
			(input.closest('label') || input.parentNode).appendChild(span);
			first = first || input;
		});
		(first || errorBox).scrollIntoView({ behavior: 'smooth', block: 'center' });
		if (first) first.focus({ preventScroll: true });
	}

	submit.addEventListener('click', function () {
		clearErrors();
		if (!form.reportValidity()) return;

		var data = { date: picked, start: startSel.value, end: endSel.value, hall: hall, elapsed: Math.round((Date.now() - opened) / 1000) };
		new FormData(form).forEach(function (v, k) { data[k] = v; });
		data.agree = form.querySelector('[name="agree"]').checked;
		if (orgType.value !== 'member') data.org_name = '';

		submit.disabled = true;
		submit.textContent = T.sending;

		fetch(C.api + 'bookings', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(data)
		})
			.then(function (r) { return r.json().then(function (j) { return { ok: r.ok, status: r.status, body: j }; }); })
			.then(function (res) {
				if (res.ok && res.body.ok) {
					root.classList.add('is-done');
					var done = root.querySelector('.cb-done');
					done.hidden = false;
					done.querySelector('.cb-done__msg').textContent = res.body.message;
					done.querySelector('.cb-done__ref').textContent = 'Reference: ' + res.body.ref;
					done.scrollIntoView({ behavior: 'smooth', block: 'start' });
					return;
				}
				var body = res.body || {};
				if (res.status === 409) {
					// Slot taken meanwhile: refresh this month.
					if (picked) month = picked.slice(0, 7);
					cache = {}; // Bookings changed: refetch every hall.
					render();
				}
				showError(body.message || T.error, body.data && body.data.fields);
			})
			.catch(function () { showError(T.error); })
			.finally(function () {
				submit.textContent = T.send;
				summary();
			});
	});

	render();
	summary();
})();
