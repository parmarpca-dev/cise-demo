/* CISE Core: nomination form (conditional sections, word count, file feedback). */
(function () {
	var form = document.querySelector('.cise-nom');
	if (!form) return;

	// Sections shown only for some answers: data-show-if="field=value".
	var conditional = form.querySelectorAll('[data-show-if]');
	function refresh() {
		conditional.forEach(function (el) {
			var rule = el.getAttribute('data-show-if').split('=');
			var checked = form.querySelector('input[name="' + rule[0] + '"]:checked');
			var show = checked && checked.value === rule[1];
			el.hidden = !show;
			el.querySelectorAll('input, select').forEach(function (input) {
				// Contact details for the guardian / nominator become required when shown.
				if (input.type !== 'tel' || input.name === 'guardian_phone') input.required = show;
				input.disabled = !show;
			});
		});
	}
	form.addEventListener('change', function (e) {
		if (e.target.type === 'radio') refresh();
	});
	refresh();

	// Word counter.
	var statement = form.querySelector('[data-max-words]');
	var counter = form.querySelector('.cn-count');
	if (statement && counter) {
		var max = parseInt(statement.getAttribute('data-max-words'), 10);
		var update = function () {
			var words = statement.value.trim() ? statement.value.trim().split(/\s+/).length : 0;
			counter.textContent = words + ' / ' + max + ' words';
			counter.classList.toggle('is-over', words > max);
			statement.setCustomValidity(words > max ? 'Please keep this to ' + max + ' words.' : '');
		};
		statement.addEventListener('input', update);
		update();
	}

	// File boxes: show the chosen file, reject anything over 10 MB.
	form.querySelectorAll('.cn-file input[type=file]').forEach(function (input) {
		input.addEventListener('change', function () {
			var box = input.closest('.cn-file');
			var file = input.files[0];
			input.setCustomValidity(file && file.size > 10485760 ? 'This file is over 10 MB.' : '');
			box.classList.toggle('has-file', !!file && file.size <= 10485760);
			if (file && file.size > 10485760) input.reportValidity();
		});
	});

	// Prevent double submits on slow uploads.
	form.addEventListener('submit', function (e) {
		if (!form.checkValidity()) return;
		var btn = form.querySelector('.cn-submit');
		if (btn.disabled) { e.preventDefault(); return; }
		btn.disabled = true;
		btn.textContent = 'Uploading…';
	});
})();
