<?php
/**
 * India Day Recognition Award: nomination form, private document uploads,
 * committee review screen and CSV export.
 *
 * @package cise-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Text fields: key => [label, required].
 */
function cise_nom_fields() {
	return array(
		'first_name'    => array( __( 'First name', 'cise-core' ), true ),
		'last_name'     => array( __( 'Last name', 'cise-core' ), true ),
		'email'         => array( __( 'Email address', 'cise-core' ), true ),
		'phone'         => array( __( 'Phone number', 'cise-core' ), true ),
		'city'          => array( __( 'City', 'cise-core' ), true ),
		'postal'        => array( __( 'Postal code', 'cise-core' ), true ),
		'under18'       => array( __( 'Under 18', 'cise-core' ), true ),
		'guardian_name' => array( __( 'Parent/guardian name', 'cise-core' ), false ),
		'guardian_email' => array( __( 'Parent/guardian email', 'cise-core' ), false ),
		'guardian_phone' => array( __( 'Parent/guardian phone', 'cise-core' ), false ),
		'submitter'     => array( __( 'Submitted by', 'cise-core' ), true ),
		'sub_name'      => array( __( 'Nominator name', 'cise-core' ), false ),
		'sub_email'     => array( __( 'Nominator email', 'cise-core' ), false ),
		'sub_phone'     => array( __( 'Nominator phone', 'cise-core' ), false ),
		'sub_relation'  => array( __( 'Relationship to nominee', 'cise-core' ), false ),
		'category'      => array( __( 'Award category', 'cise-core' ), true ),
		'school'        => array( __( 'School or institution', 'cise-core' ), true ),
		'grade'         => array( __( 'Grade or program', 'cise-core' ), true ),
		'average'       => array( __( 'Most recent average (%)', 'cise-core' ), true ),
		'grad_year'     => array( __( 'Expected graduation year', 'cise-core' ), false ),
		'association'   => array( __( 'CISE member association', 'cise-core' ), false ),
		'statement'     => array( __( 'Why the nominee deserves this award', 'cise-core' ), true ),
		'activities'    => array( __( 'Volunteering, activities & community involvement', 'cise-core' ), false ),
		'consent_publish' => array( __( 'May publish name and photo', 'cise-core' ), false ),
	);
}

function cise_nom_files() {
	return array(
		'transcript' => array( __( 'Transcript or report card', 'cise-core' ), true, __( 'PDF or JPG, up to 10 MB', 'cise-core' ) ),
		'reference'  => array( __( 'Reference letter', 'cise-core' ), false, __( 'From a teacher or mentor (optional)', 'cise-core' ) ),
		'photo'      => array( __( 'Nominee photo', 'cise-core' ), false, __( 'For the event program (optional)', 'cise-core' ) ),
	);
}

const CISE_NOM_MAX_BYTES = 10485760;
const CISE_NOM_STATEMENT_WORDS = 300;

/**
 * Print the form (theme Recognition Award page, or [cise_nomination_form]).
 */
function cise_core_nomination_form() {
	wp_enqueue_style( 'cise-core' );
	wp_enqueue_script( 'cise-nomination' );

	// phpcs:disable WordPress.Security.NonceVerification
	if ( isset( $_GET['nominated'] ) ) {
		echo '<div class="cn-done"><div class="cb-done__icon" aria-hidden="true">&#10003;</div><h2>' . esc_html__( 'Nomination received', 'cise-core' ) . '</h2><p>' . esc_html__( 'Thank you. We have emailed you a copy of the nomination. The award committee will be in touch with recipients.', 'cise-core' ) . '</p></div>';
		return;
	}
	if ( ! cise_core_award_is_open() ) {
		cise_core_notice( __( 'Nominations are closed for this year. Please check back when the next award opens.', 'cise-core' ), 'warn' );
		return;
	}

	$v      = array();
	$errors = array();
	if ( isset( $_GET['nom_err'] ) ) {
		$saved = get_transient( 'cise_nom_err_' . sanitize_key( $_GET['nom_err'] ) );
		if ( $saved ) {
			$v      = $saved['values'];
			$errors = $saved['errors'];
		}
	}
	// phpcs:enable

	$val = function ( $k, $default = '' ) use ( $v ) {
		return isset( $v[ $k ] ) ? $v[ $k ] : $default;
	};
	$err = function ( $k ) use ( $errors ) {
		return isset( $errors[ $k ] ) ? '<span class="cn-err">' . esc_html( $errors[ $k ] ) . '</span>' : '';
	};
	$input = function ( $k, $label, $type = 'text', $attrs = '' ) use ( $val, $err ) {
		$fields = cise_nom_fields();
		$req    = ! empty( $fields[ $k ][1] );
		printf(
			'<label class="%5$s">%1$s%2$s<input type="%3$s" name="%4$s" value="%6$s" %7$s %8$s>%9$s</label>',
			esc_html( $label ),
			$req ? ' *' : '',
			esc_attr( $type ),
			esc_attr( $k ),
			$err( $k ) ? 'has-err' : '',
			esc_attr( $val( $k ) ),
			$req ? 'required' : '',
			$attrs, // phpcs:ignore WordPress.Security.EscapeOutput -- static attribute strings below.
			$err( $k ) // phpcs:ignore WordPress.Security.EscapeOutput
		);
	};

	$categories = cise_core_lines( 'award_categories' );
	$assoc      = cise_core_lines( 'associations' );
	$under18    = $val( 'under18', 'no' );
	$submitter  = $val( 'submitter', 'self' );
	?>
	<?php if ( $errors ) : ?>
		<div class="notice notice--warn" role="alert"><?php esc_html_e( 'Please fix the highlighted fields. For your security, attached files need to be chosen again.', 'cise-core' ); ?></div>
	<?php endif; ?>
	<form class="cise-nom" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
		<input type="hidden" name="action" value="cise_nominate">
		<input type="hidden" name="return" value="<?php echo esc_url( get_permalink() ); ?>">
		<input type="hidden" name="started" value="<?php echo esc_attr( time() ); ?>">
		<?php wp_nonce_field( 'cise_nominate', 'cise_nom_nonce' ); ?>
		<label class="cb-hp" aria-hidden="true">Website<input name="website" tabindex="-1" autocomplete="off"></label>

		<section class="cb-step">
			<h2><span class="cb-num">1</span><?php esc_html_e( 'Nominee details', 'cise-core' ); ?></h2>
			<p class="cn-help"><?php esc_html_e( 'The person being considered for the award. Fields marked * are required.', 'cise-core' ); ?></p>
			<div class="cb-row cb-row--3">
				<?php $input( 'first_name', __( 'First name', 'cise-core' ), 'text', 'autocomplete="given-name"' ); ?>
				<?php $input( 'last_name', __( 'Last name', 'cise-core' ), 'text', 'autocomplete="family-name"' ); ?>
				<?php $input( 'email', __( 'Email address', 'cise-core' ), 'email', 'placeholder="name@example.com"' ); ?>
				<?php $input( 'phone', __( 'Phone number', 'cise-core' ), 'tel', 'placeholder="780 555 0123"' ); ?>
				<?php $input( 'city', __( 'City', 'cise-core' ), 'text', 'placeholder="Edmonton"' ); ?>
				<?php $input( 'postal', __( 'Postal code', 'cise-core' ), 'text', 'placeholder="T6E 5K3" autocomplete="postal-code"' ); ?>
			</div>
			<fieldset class="cn-choice">
				<legend><?php esc_html_e( 'Is the nominee under 18?', 'cise-core' ); ?> *</legend>
				<label><input type="radio" name="under18" value="yes" <?php checked( $under18, 'yes' ); ?>><span><?php esc_html_e( 'Yes', 'cise-core' ); ?></span></label>
				<label><input type="radio" name="under18" value="no" <?php checked( $under18, 'no' ); ?>><span><?php esc_html_e( 'No', 'cise-core' ); ?></span></label>
			</fieldset>
			<div class="cb-row cb-row--3" data-show-if="under18=yes">
				<?php $input( 'guardian_name', __( 'Parent/guardian name', 'cise-core' ) ); ?>
				<?php $input( 'guardian_email', __( 'Parent/guardian email', 'cise-core' ), 'email' ); ?>
				<?php $input( 'guardian_phone', __( 'Parent/guardian phone', 'cise-core' ), 'tel' ); ?>
			</div>
		</section>

		<section class="cb-step">
			<h2><span class="cb-num">2</span><?php esc_html_e( 'Who is submitting?', 'cise-core' ); ?></h2>
			<fieldset class="cn-choice">
				<legend class="screen-reader-text"><?php esc_html_e( 'Who is submitting?', 'cise-core' ); ?></legend>
				<label><input type="radio" name="submitter" value="self" <?php checked( $submitter, 'self' ); ?>><span><?php esc_html_e( "I'm applying for myself", 'cise-core' ); ?></span></label>
				<label><input type="radio" name="submitter" value="other" <?php checked( $submitter, 'other' ); ?>><span><?php esc_html_e( "I'm nominating someone else", 'cise-core' ); ?></span></label>
			</fieldset>
			<div class="cb-row" data-show-if="submitter=other">
				<?php $input( 'sub_name', __( 'Your name', 'cise-core' ) ); ?>
				<?php $input( 'sub_email', __( 'Your email', 'cise-core' ), 'email' ); ?>
				<?php $input( 'sub_phone', __( 'Your phone', 'cise-core' ), 'tel' ); ?>
				<label class="<?php echo $err( 'sub_relation' ) ? 'has-err' : ''; ?>"><?php esc_html_e( 'Relationship to nominee', 'cise-core' ); ?>
					<select name="sub_relation">
						<?php foreach ( array( '', 'Parent or guardian', 'Teacher or professor', 'Community member', 'Other' ) as $opt ) : ?>
							<option value="<?php echo esc_attr( $opt ); ?>" <?php selected( $val( 'sub_relation' ), $opt ); ?>><?php echo esc_html( $opt ? $opt : __( 'Select', 'cise-core' ) ); ?></option>
						<?php endforeach; ?>
					</select>
					<?php echo $err( 'sub_relation' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</label>
			</div>
		</section>

		<section class="cb-step">
			<h2><span class="cb-num">3</span><?php esc_html_e( 'Award & studies', 'cise-core' ); ?></h2>
			<label class="cb-full <?php echo $err( 'category' ) ? 'has-err' : ''; ?>"><?php esc_html_e( 'Award category', 'cise-core' ); ?> *
				<select name="category" required>
					<?php foreach ( $categories as $c ) : ?>
						<option <?php selected( $val( 'category' ), $c ); ?>><?php echo esc_html( $c ); ?></option>
					<?php endforeach; ?>
				</select>
				<?php echo $err( 'category' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</label>
			<div class="cb-row cb-row--3">
				<?php $input( 'school', __( 'School or institution', 'cise-core' ) ); ?>
				<?php $input( 'grade', __( 'Grade or program', 'cise-core' ), 'text', 'placeholder="' . esc_attr__( 'e.g. Grade 12, BSc Year 2', 'cise-core' ) . '"' ); ?>
				<?php $input( 'average', __( 'Most recent average (%)', 'cise-core' ), 'number', 'min="0" max="100" step="0.1" placeholder="' . esc_attr__( 'e.g. 92', 'cise-core' ) . '"' ); ?>
				<?php $input( 'grad_year', __( 'Expected graduation year', 'cise-core' ), 'number', 'min="2000" max="2100" placeholder="' . esc_attr( wp_date( 'Y' ) + 1 ) . '"' ); ?>
			</div>
			<label class="cb-full"><?php esc_html_e( 'CISE member association the family belongs to (optional)', 'cise-core' ); ?>
				<?php if ( $assoc ) : ?>
					<select name="association">
						<option value=""><?php esc_html_e( 'Select an association', 'cise-core' ); ?></option>
						<?php foreach ( $assoc as $a ) : ?>
							<option <?php selected( $val( 'association' ), $a ); ?>><?php echo esc_html( $a ); ?></option>
						<?php endforeach; ?>
						<option value="None" <?php selected( $val( 'association' ), 'None' ); ?>><?php esc_html_e( 'None', 'cise-core' ); ?></option>
					</select>
				<?php else : ?>
					<input name="association" value="<?php echo esc_attr( $val( 'association' ) ); ?>">
				<?php endif; ?>
			</label>
		</section>

		<section class="cb-step">
			<h2><span class="cb-num">4</span><?php esc_html_e( 'Achievements', 'cise-core' ); ?></h2>
			<label class="cb-full <?php echo $err( 'statement' ) ? 'has-err' : ''; ?>"><?php esc_html_e( 'Why does the nominee deserve this award?', 'cise-core' ); ?> *
				<textarea name="statement" rows="6" required data-max-words="<?php echo (int) CISE_NOM_STATEMENT_WORDS; ?>" placeholder="<?php esc_attr_e( 'Academic results, awards, leadership and what makes them stand out.', 'cise-core' ); ?>"><?php echo esc_textarea( $val( 'statement' ) ); ?></textarea>
				<span class="cn-count" aria-live="polite"><?php /* translators: %d: words */ echo esc_html( sprintf( __( 'Up to %d words', 'cise-core' ), CISE_NOM_STATEMENT_WORDS ) ); ?></span>
				<?php echo $err( 'statement' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</label>
			<label class="cb-full"><?php esc_html_e( 'Volunteering, activities & community involvement', 'cise-core' ); ?>
				<textarea name="activities" rows="4" placeholder="<?php esc_attr_e( 'Clubs, sports, arts, volunteering, cultural programs…', 'cise-core' ); ?>"><?php echo esc_textarea( $val( 'activities' ) ); ?></textarea>
			</label>
		</section>

		<section class="cb-step">
			<h2><span class="cb-num">5</span><?php esc_html_e( 'Supporting documents', 'cise-core' ); ?></h2>
			<div class="cn-files">
				<?php foreach ( cise_nom_files() as $k => $f ) : ?>
					<label class="cn-file <?php echo $err( $k ) ? 'has-err' : ''; ?>">
						<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 15V4"/><path d="m7.5 8.5 4.5-4.5 4.5 4.5"/><path d="M5 15v4h14v-4"/></svg>
						<strong><?php echo esc_html( $f[0] ) . ( $f[1] ? ' *' : '' ); ?></strong>
						<small><?php echo esc_html( $f[2] ); ?></small>
						<input type="file" name="<?php echo esc_attr( $k ); ?>" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" <?php echo $f[1] ? 'required' : ''; ?>>
						<?php echo $err( $k ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					</label>
				<?php endforeach; ?>
			</div>
		</section>

		<section class="cb-step">
			<h2><span class="cb-num">6</span><?php esc_html_e( 'Review & consent', 'cise-core' ); ?></h2>
			<label class="cb-check <?php echo $err( 'consent_accurate' ) ? 'has-err' : ''; ?>"><input type="checkbox" name="consent_accurate" value="1" required><span><?php esc_html_e( 'I confirm the information in this nomination is accurate and complete.', 'cise-core' ); ?> *</span></label>
			<label class="cb-check"><input type="checkbox" name="consent_publish" value="1" <?php checked( $val( 'consent_publish' ), 'Yes' ); ?>><span><?php esc_html_e( "If selected, CISE may share the recipient's name and photo in event programs, its website and social media.", 'cise-core' ); ?></span></label>
			<label class="cb-check <?php echo $err( 'consent_privacy' ) ? 'has-err' : ''; ?>"><input type="checkbox" name="consent_privacy" value="1" required><span>
				<?php
				$privacy = get_privacy_policy_url();
				printf(
					/* translators: %s: privacy notice link */
					wp_kses_post( __( 'I have read the %s. Information is used only to assess this award.', 'cise-core' ) ),
					$privacy ? '<a href="' . esc_url( $privacy ) . '" target="_blank">' . esc_html__( 'privacy notice', 'cise-core' ) . '</a>' : esc_html__( 'privacy notice', 'cise-core' )
				);
				?>
				*</span></label>
			<button type="submit" class="btn btn--primary cn-submit"><?php esc_html_e( 'Submit nomination', 'cise-core' ); ?></button>
			<p class="cn-help"><?php esc_html_e( "You'll receive a confirmation email with a copy of your submission.", 'cise-core' ); ?></p>
		</section>
	</form>
	<?php
}

add_shortcode( 'cise_nomination_form', function () {
	ob_start();
	cise_core_nomination_form();
	return ob_get_clean();
} );

/* ---------- Submission ---------- */

add_action( 'admin_post_nopriv_cise_nominate', 'cise_nom_handle' );
add_action( 'admin_post_cise_nominate', 'cise_nom_handle' );

function cise_nom_handle() {
	$return = isset( $_POST['return'] ) ? esc_url_raw( wp_unslash( $_POST['return'] ) ) : home_url( '/' );
	$return = wp_validate_redirect( $return, home_url( '/' ) );

	// Uploads over PHP's post_max_size arrive with an empty $_POST.
	if ( empty( $_POST ) ) {
		wp_safe_redirect( add_query_arg( 'nom_err', cise_nom_store_errors( array(), array( 'transcript' => __( 'Your files were too large to upload. Please keep each under 10 MB.', 'cise-core' ) ) ), wp_get_referer() ? wp_get_referer() : $return ) . '#nominate' );
		exit;
	}
	if ( ! isset( $_POST['cise_nom_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['cise_nom_nonce'] ), 'cise_nominate' ) ) {
		wp_die( esc_html__( 'This form expired. Please go back, refresh the page and try again.', 'cise-core' ), '', array( 'back_link' => true ) );
	}
	if ( ! empty( $_POST['website'] ) || ( time() - absint( $_POST['started'] ?? 0 ) ) < 10 ) {
		wp_safe_redirect( add_query_arg( 'nominated', 1, $return ) );
		exit;
	}
	if ( ! cise_core_award_is_open() ) {
		wp_safe_redirect( $return );
		exit;
	}
	if ( ! cise_rate_limit( 'nominate', 10 ) ) {
		wp_die( esc_html__( 'Too many submissions from your connection. Please try again later or email us.', 'cise-core' ), '', array( 'back_link' => true ) );
	}

	$values = array();
	$errors = array();
	foreach ( cise_nom_fields() as $k => $def ) {
		$raw          = isset( $_POST[ $k ] ) ? wp_unslash( $_POST[ $k ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$values[ $k ] = in_array( $k, array( 'statement', 'activities' ), true ) ? sanitize_textarea_field( $raw ) : sanitize_text_field( $raw );
	}
	$values['consent_publish'] = empty( $_POST['consent_publish'] ) ? 'No' : 'Yes';
	$values['under18']         = 'yes' === $values['under18'] ? 'yes' : 'no';
	$values['submitter']       = 'other' === $values['submitter'] ? 'other' : 'self';

	$required = array_keys( array_filter( cise_nom_fields(), function ( $d ) {
		return $d[1];
	} ) );
	if ( 'yes' === $values['under18'] ) {
		array_push( $required, 'guardian_name', 'guardian_email', 'guardian_phone' );
	}
	if ( 'other' === $values['submitter'] ) {
		array_push( $required, 'sub_name', 'sub_email', 'sub_relation' );
	}
	foreach ( $required as $k ) {
		if ( '' === $values[ $k ] ) {
			$errors[ $k ] = __( 'Required', 'cise-core' );
		}
	}
	foreach ( array( 'email', 'guardian_email', 'sub_email' ) as $k ) {
		if ( '' !== $values[ $k ] && ! is_email( $values[ $k ] ) ) {
			$errors[ $k ] = __( 'Enter a valid email', 'cise-core' );
		}
	}
	if ( '' !== $values['average'] && ( ! is_numeric( $values['average'] ) || $values['average'] < 0 || $values['average'] > 100 ) ) {
		$errors['average'] = __( 'Enter a percentage from 0 to 100', 'cise-core' );
	}
	if ( str_word_count( $values['statement'] ) > CISE_NOM_STATEMENT_WORDS ) {
		/* translators: %d: words */
		$errors['statement'] = sprintf( __( 'Please keep this to %d words', 'cise-core' ), CISE_NOM_STATEMENT_WORDS );
	}
	if ( ! in_array( $values['category'], cise_core_lines( 'award_categories' ), true ) ) {
		$errors['category'] = __( 'Choose a category', 'cise-core' );
	}
	if ( empty( $_POST['consent_accurate'] ) ) {
		$errors['consent_accurate'] = __( 'Required', 'cise-core' );
	}
	if ( empty( $_POST['consent_privacy'] ) ) {
		$errors['consent_privacy'] = __( 'Required', 'cise-core' );
	}

	// Check files before saving anything.
	$uploads = array();
	foreach ( cise_nom_files() as $k => $f ) {
		$file = $_FILES[ $k ] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( ! $file || UPLOAD_ERR_NO_FILE === $file['error'] ) {
			if ( $f[1] ) {
				$errors[ $k ] = __( 'Please attach this document', 'cise-core' );
			}
			continue;
		}
		if ( UPLOAD_ERR_OK !== $file['error'] || $file['size'] > CISE_NOM_MAX_BYTES ) {
			$errors[ $k ] = __( 'Upload failed. Files must be under 10 MB.', 'cise-core' );
			continue;
		}
		$check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], array(
			'pdf'      => 'application/pdf',
			'jpg|jpeg' => 'image/jpeg',
			'png'      => 'image/png',
		) );
		if ( ! $check['ext'] || ! $check['type'] ) {
			$errors[ $k ] = __( 'Please upload a PDF, JPG or PNG', 'cise-core' );
			continue;
		}
		$uploads[ $k ] = array( $file, $check['ext'] );
	}

	if ( $errors ) {
		wp_safe_redirect( add_query_arg( 'nom_err', cise_nom_store_errors( $values, $errors ), $return ) . '#nominate' );
		exit;
	}

	$year = (string) cise_core_get( 'award_year' );
	$id   = wp_insert_post( array(
		'post_type'   => 'cise_nomination',
		'post_status' => 'publish',
		'post_title'  => $values['first_name'] . ' ' . $values['last_name'],
	), true );
	if ( is_wp_error( $id ) ) {
		wp_die( esc_html__( 'We could not save your nomination. Please email us.', 'cise-core' ), '', array( 'back_link' => true ) );
	}
	foreach ( $values as $k => $v ) {
		update_post_meta( $id, '_n_' . $k, $v );
	}
	update_post_meta( $id, '_n_year', $year );
	update_post_meta( $id, '_n_review', 'new' );

	// Store files privately with unguessable names.
	$dir = cise_core_private_dir() . 'nominations/' . $year . '/';
	wp_mkdir_p( $dir );
	foreach ( $uploads as $k => $u ) {
		$name = $id . '-' . $k . '-' . wp_generate_password( 16, false ) . '.' . $u[1];
		if ( move_uploaded_file( $u[0]['tmp_name'], $dir . $name ) ) {
			update_post_meta( $id, '_n_file_' . $k, 'nominations/' . $year . '/' . $name );
			update_post_meta( $id, '_n_filename_' . $k, sanitize_file_name( $u[0]['name'] ) );
		}
	}

	// Possible duplicate (same nominee email this year).
	$dupes = get_posts( array(
		'post_type'      => 'cise_nomination',
		'posts_per_page' => 1,
		'fields'         => 'ids',
		'exclude'        => array( $id ),
		'meta_query'     => array(
			array( 'key' => '_n_email', 'value' => $values['email'] ),
			array( 'key' => '_n_year', 'value' => $year ),
		),
	) );
	if ( $dupes ) {
		update_post_meta( $id, '_n_duplicate_of', $dupes[0] );
	}

	cise_nom_emails( $id );

	wp_safe_redirect( add_query_arg( 'nominated', 1, $return ) . '#nominate' );
	exit;
}

function cise_nom_store_errors( $values, $errors ) {
	$token = wp_generate_password( 12, false );
	set_transient( 'cise_nom_err_' . strtolower( $token ), array( 'values' => $values, 'errors' => $errors ), 20 * MINUTE_IN_SECONDS );
	return strtolower( $token );
}

/**
 * Readable rows for emails / the review screen / CSV.
 */
function cise_nom_rows( $id ) {
	$rows = array();
	foreach ( cise_nom_fields() as $k => $def ) {
		$v = get_post_meta( $id, '_n_' . $k, true );
		if ( 'under18' === $k ) {
			$v = 'yes' === $v ? __( 'Yes', 'cise-core' ) : __( 'No', 'cise-core' );
		} elseif ( 'submitter' === $k ) {
			$v = 'other' === $v ? __( 'Someone else', 'cise-core' ) : __( 'The nominee', 'cise-core' );
		}
		$rows[ $def[0] ] = $v;
	}
	return $rows;
}

function cise_nom_emails( $id ) {
	$rows  = cise_nom_rows( $id );
	$files = array();
	foreach ( cise_nom_files() as $k => $f ) {
		if ( get_post_meta( $id, '_n_file_' . $k, true ) ) {
			$files[] = $f[0];
		}
	}
	$rows[ __( 'Documents', 'cise-core' ) ] = implode( ', ', $files );
	$name                                  = get_the_title( $id );

	cise_core_mail(
		cise_core_staff_email(),
		/* translators: %s: nominee */
		sprintf( __( 'New award nomination: %s', 'cise-core' ), $name ),
		__( 'A new India Day Recognition Award nomination was submitted. Documents are stored privately on the website.', 'cise-core' ) . ( get_post_meta( $id, '_n_duplicate_of', true ) ? "\n\n" . __( 'Note: another nomination for this email already exists this year.', 'cise-core' ) : '' ),
		$rows,
		array(
			'reply_to'     => get_post_meta( $id, '_n_email', true ),
			'button_url'   => admin_url( 'post.php?action=edit&post=' . $id ),
			'button_label' => __( 'Open nomination', 'cise-core' ),
		)
	);

	$to = array_filter( array_unique( array(
		get_post_meta( $id, '_n_email', true ),
		get_post_meta( $id, '_n_sub_email', true ),
	) ) );
	cise_core_mail(
		$to,
		__( 'We received your India Day Award nomination', 'cise-core' ),
		/* translators: %s: nominee */
		sprintf( __( "Thank you for nominating %s. Here is a copy of the nomination for your records. The award committee will contact recipients.", 'cise-core' ), $name ),
		$rows,
		array( 'reply_to' => cise_core_public_email() )
	);
}

/* ---------- Admin: review screen, columns, file download, CSV ---------- */

function cise_nom_review_states() {
	return array(
		'new'         => __( 'New', 'cise-core' ),
		'reviewing'   => __( 'Under review', 'cise-core' ),
		'shortlisted' => __( 'Shortlisted', 'cise-core' ),
		'recipient'   => __( 'Recipient', 'cise-core' ),
		'not_selected' => __( 'Not selected', 'cise-core' ),
	);
}

add_filter( 'manage_cise_nomination_posts_columns', function () {
	return array(
		'cb'        => '<input type="checkbox">',
		'title'     => __( 'Nominee', 'cise-core' ),
		'cise_cat'  => __( 'Category', 'cise-core' ),
		'cise_avg'  => __( 'Average', 'cise-core' ),
		'cise_year' => __( 'Award year', 'cise-core' ),
		'cise_rev'  => __( 'Review', 'cise-core' ),
		'date'      => __( 'Submitted', 'cise-core' ),
	);
} );

add_action( 'manage_cise_nomination_posts_custom_column', function ( $col, $id ) {
	$states = cise_nom_review_states();
	switch ( $col ) {
		case 'cise_cat':
			echo esc_html( get_post_meta( $id, '_n_category', true ) ) . '<br><small>' . esc_html( get_post_meta( $id, '_n_school', true ) ) . '</small>';
			break;
		case 'cise_avg':
			$avg = get_post_meta( $id, '_n_average', true );
			echo '' !== $avg ? esc_html( $avg . '%' ) : '';
			break;
		case 'cise_year':
			echo esc_html( get_post_meta( $id, '_n_year', true ) );
			break;
		case 'cise_rev':
			$s = get_post_meta( $id, '_n_review', true );
			echo esc_html( $states[ $s ] ?? $s );
			if ( get_post_meta( $id, '_n_duplicate_of', true ) ) {
				echo '<br><small style="color:#b26a00">' . esc_html__( 'Possible duplicate', 'cise-core' ) . '</small>';
			}
			break;
	}
}, 10, 2 );

add_filter( 'manage_edit-cise_nomination_sortable_columns', function ( $cols ) {
	$cols['cise_avg'] = 'cise_avg';
	return $cols;
} );

add_action( 'pre_get_posts', function ( WP_Query $q ) {
	if ( ! is_admin() || ! $q->is_main_query() || 'cise_nomination' !== $q->get( 'post_type' ) ) {
		return;
	}
	if ( 'cise_avg' === $q->get( 'orderby' ) ) {
		$q->set( 'meta_key', '_n_average' );
		$q->set( 'orderby', 'meta_value_num' );
	}
	$year = isset( $_GET['cise_year'] ) ? sanitize_text_field( wp_unslash( $_GET['cise_year'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	if ( $year ) {
		$q->set( 'meta_query', array( array( 'key' => '_n_year', 'value' => $year ) ) );
	}
} );

add_action( 'restrict_manage_posts', function ( $type ) {
	if ( 'cise_nomination' !== $type ) {
		return;
	}
	global $wpdb;
	$years   = $wpdb->get_col( "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_n_year' ORDER BY meta_value DESC" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$current = isset( $_GET['cise_year'] ) ? sanitize_text_field( wp_unslash( $_GET['cise_year'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	echo '<select name="cise_year"><option value="">' . esc_html__( 'All years', 'cise-core' ) . '</option>';
	foreach ( $years as $y ) {
		printf( '<option value="%1$s" %2$s>%1$s</option>', esc_attr( $y ), selected( $current, $y, false ) );
	}
	echo '</select>';
} );

/* Export button above the list. */
add_action( 'manage_posts_extra_tablenav', function ( $which ) {
	if ( 'top' !== $which || 'cise_nomination' !== get_current_screen()->post_type ) {
		return;
	}
	$year = isset( $_GET['cise_year'] ) ? sanitize_text_field( wp_unslash( $_GET['cise_year'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$url  = wp_nonce_url( admin_url( 'admin-post.php?action=cise_nom_export&year=' . rawurlencode( $year ) ), 'cise_nom_export' );
	echo '<div class="alignleft actions"><a class="button" href="' . esc_url( $url ) . '">' . esc_html__( 'Download spreadsheet (CSV)', 'cise-core' ) . '</a></div>';
} );

add_action( 'add_meta_boxes_cise_nomination', function () {
	remove_meta_box( 'submitdiv', 'cise_nomination', 'side' );
	add_meta_box( 'cise_nom_view', __( 'Nomination', 'cise-core' ), 'cise_nom_view_box', 'cise_nomination', 'normal', 'high' );
	add_meta_box( 'cise_nom_review', __( 'Committee review', 'cise-core' ), 'cise_nom_review_box', 'cise_nomination', 'side', 'high' );
} );

function cise_nom_view_box( $post ) {
	echo '<table class="widefat striped"><tbody>';
	foreach ( cise_nom_rows( $post->ID ) as $label => $value ) {
		if ( '' === (string) $value ) {
			continue;
		}
		echo '<tr><th style="width:240px">' . esc_html( $label ) . '</th><td>' . nl2br( esc_html( $value ) ) . '</td></tr>';
	}
	echo '<tr><th>' . esc_html__( 'Award year', 'cise-core' ) . '</th><td>' . esc_html( get_post_meta( $post->ID, '_n_year', true ) ) . '</td></tr>';
	foreach ( cise_nom_files() as $k => $f ) {
		$path = get_post_meta( $post->ID, '_n_file_' . $k, true );
		echo '<tr><th>' . esc_html( $f[0] ) . '</th><td>';
		if ( $path ) {
			$url = wp_nonce_url( admin_url( 'admin-post.php?action=cise_nom_file&id=' . $post->ID . '&f=' . $k ), 'cise_nom_file_' . $post->ID );
			echo '<a class="button" href="' . esc_url( $url ) . '">' . esc_html( get_post_meta( $post->ID, '_n_filename_' . $k, true ) ) . '</a>';
		} else {
			echo '&mdash;';
		}
		echo '</td></tr>';
	}
	$dupe = get_post_meta( $post->ID, '_n_duplicate_of', true );
	if ( $dupe ) {
		echo '<tr><th>' . esc_html__( 'Possible duplicate of', 'cise-core' ) . '</th><td><a href="' . esc_url( get_edit_post_link( $dupe ) ) . '">' . esc_html( get_the_title( $dupe ) ) . '</a></td></tr>';
	}
	echo '</tbody></table>';
}

function cise_nom_review_box( $post ) {
	wp_nonce_field( 'cise_nom_review', 'cise_nom_review_nonce' );
	$state = get_post_meta( $post->ID, '_n_review', true );
	echo '<p><select name="cise_nom_review" style="width:100%">';
	foreach ( cise_nom_review_states() as $k => $label ) {
		printf( '<option value="%s" %s>%s</option>', esc_attr( $k ), selected( $state, $k, false ), esc_html( $label ) );
	}
	echo '</select></p><p><label for="cise_nom_notes"><strong>' . esc_html__( 'Committee notes (private)', 'cise-core' ) . '</strong></label><textarea id="cise_nom_notes" name="cise_nom_notes" rows="6" style="width:100%">' . esc_textarea( get_post_meta( $post->ID, '_n_notes', true ) ) . '</textarea></p>';
	submit_button( __( 'Save review', 'cise-core' ), 'primary', 'save', false );
	echo '<input type="hidden" name="post_status" value="publish">';
	echo '<p style="margin-top:12px"><a class="submitdelete" style="color:#a00" href="' . esc_url( get_delete_post_link( $post->ID ) ) . '">' . esc_html__( 'Move to trash', 'cise-core' ) . '</a></p>';
}

add_action( 'save_post_cise_nomination', function ( $id ) {
	if ( ! isset( $_POST['cise_nom_review_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['cise_nom_review_nonce'] ), 'cise_nom_review' ) || ! current_user_can( CISE_CORE_CAP ) ) {
		return;
	}
	$state = isset( $_POST['cise_nom_review'] ) ? sanitize_key( $_POST['cise_nom_review'] ) : 'new';
	update_post_meta( $id, '_n_review', isset( cise_nom_review_states()[ $state ] ) ? $state : 'new' );
	update_post_meta( $id, '_n_notes', isset( $_POST['cise_nom_notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['cise_nom_notes'] ) ) : '' );
} );

/* Hide the title box on nominations (it's the nominee name). */
add_action( 'admin_head-post.php', function () {
	if ( 'cise_nomination' === get_current_screen()->post_type ) {
		echo '<style>#titlediv{pointer-events:none}#titlediv #title{background:#f6f7f7}</style>';
	}
} );

/* Download a private document. */
add_action( 'admin_post_cise_nom_file', function () {
	$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
	$k  = isset( $_GET['f'] ) ? sanitize_key( $_GET['f'] ) : '';
	check_admin_referer( 'cise_nom_file_' . $id );
	if ( ! current_user_can( CISE_CORE_CAP ) || 'cise_nomination' !== get_post_type( $id ) || ! isset( cise_nom_files()[ $k ] ) ) {
		wp_die( esc_html__( 'Not allowed.', 'cise-core' ) );
	}
	$rel  = get_post_meta( $id, '_n_file_' . $k, true );
	$path = realpath( cise_core_private_dir() . $rel );
	$base = realpath( cise_core_private_dir() );
	if ( ! $rel || ! $path || 0 !== strpos( $path, $base ) || ! is_readable( $path ) ) {
		wp_die( esc_html__( 'File not found.', 'cise-core' ) );
	}
	$type = wp_check_filetype( $path );
	nocache_headers();
	header( 'Content-Type: ' . ( $type['type'] ? $type['type'] : 'application/octet-stream' ) );
	header( 'Content-Disposition: inline; filename="' . sanitize_file_name( get_post_meta( $id, '_n_filename_' . $k, true ) ) . '"' );
	header( 'Content-Length: ' . filesize( $path ) );
	header( 'X-Content-Type-Options: nosniff' );
	readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	exit;
} );

/* CSV export for the committee. */
add_action( 'admin_post_cise_nom_export', function () {
	check_admin_referer( 'cise_nom_export' );
	if ( ! current_user_can( CISE_CORE_CAP ) ) {
		wp_die( esc_html__( 'Not allowed.', 'cise-core' ) );
	}
	$year = isset( $_GET['year'] ) ? sanitize_text_field( wp_unslash( $_GET['year'] ) ) : '';
	$args = array(
		'post_type'      => 'cise_nomination',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'orderby'        => 'date',
		'order'          => 'ASC',
	);
	if ( $year ) {
		$args['meta_query'] = array( array( 'key' => '_n_year', 'value' => $year ) );
	}
	$posts  = get_posts( $args );
	$states = cise_nom_review_states();

	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="cise-nominations' . ( $year ? '-' . sanitize_file_name( $year ) : '' ) . '.csv"' );
	$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- BOM so Excel reads UTF-8.

	$head = array( __( 'Submitted', 'cise-core' ), __( 'Award year', 'cise-core' ), __( 'Review', 'cise-core' ) );
	foreach ( cise_nom_fields() as $def ) {
		$head[] = $def[0];
	}
	foreach ( cise_nom_files() as $f ) {
		$head[] = $f[0];
	}
	$head[] = __( 'Committee notes', 'cise-core' );
	$head[] = __( 'Link', 'cise-core' );
	fputcsv( $out, $head, ',', '"', '' );

	foreach ( $posts as $p ) {
		$row = array( get_the_date( 'Y-m-d H:i', $p ), get_post_meta( $p->ID, '_n_year', true ), $states[ get_post_meta( $p->ID, '_n_review', true ) ] ?? '' );
		foreach ( cise_nom_rows( $p->ID ) as $v ) {
			// Stop spreadsheet formula injection.
			$row[] = preg_match( '/^[=+\-@]/', (string) $v ) ? "'" . $v : $v;
		}
		foreach ( cise_nom_files() as $k => $f ) {
			$row[] = get_post_meta( $p->ID, '_n_file_' . $k, true ) ? __( 'Yes', 'cise-core' ) : __( 'No', 'cise-core' );
		}
		$row[] = get_post_meta( $p->ID, '_n_notes', true );
		$row[] = admin_url( 'post.php?action=edit&post=' . $p->ID );
		fputcsv( $out, $row, ',', '"', '' );
	}
	fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	exit;
} );

/* Remove a nomination's documents when it is permanently deleted. */
add_action( 'before_delete_post', function ( $id ) {
	if ( 'cise_nomination' !== get_post_type( $id ) ) {
		return;
	}
	foreach ( array_keys( cise_nom_files() ) as $k ) {
		$rel = get_post_meta( $id, '_n_file_' . $k, true );
		if ( $rel && file_exists( cise_core_private_dir() . $rel ) ) {
			wp_delete_file( cise_core_private_dir() . $rel );
		}
	}
} );
