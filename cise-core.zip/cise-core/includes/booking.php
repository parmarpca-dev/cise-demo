<?php
/**
 * Hall booking: availability calendar, price estimate and booking requests.
 *
 * Flow (like Square Appointments, without online payment): the visitor picks an
 * open date and a free time range, enters event details and sends a request. The
 * request holds the time as "pending" so nobody else can take it. Staff confirm
 * or decline it under CISE > Hall bookings; on confirm they send the Square
 * invoice. Every change is mirrored to Google Calendar.
 *
 * @package cise-core
 */

defined( 'ABSPATH' ) || exit;

/** Statuses that occupy the hall. */
const CISE_BOOKING_HOLDING = array( 'pending', 'confirmed' );

/**
 * Format money.
 */
function cise_money( $amount ) {
	if ( '' === $amount || null === $amount ) {
		return '';
	}
	$amount = (float) $amount;
	return '$' . number_format_i18n( $amount, floor( $amount ) == $amount ? 0 : 2 ); // phpcs:ignore Universal.Operators.StrictComparisons
}

/**
 * "17:30" -> minutes since midnight.
 */
function cise_min( $hhmm ) {
	$p = explode( ':', $hhmm );
	return (int) $p[0] * 60 + (int) ( $p[1] ?? 0 );
}

/**
 * Closing time in minutes; "00:00" (or anything not after opening) means midnight.
 */
function cise_close_min() {
	$close = cise_min( cise_core_get( 'close_time' ) );
	return $close <= cise_min( cise_core_get( 'open_time' ) ) ? 1440 : $close;
}

/**
 * Minutes since midnight -> "17:30".
 */
function cise_hhmm( $minutes ) {
	return sprintf( '%02d:%02d', floor( $minutes / 60 ), $minutes % 60 );
}

/**
 * Minutes -> "5:30 pm".
 */
function cise_time_label( $minutes ) {
	if ( $minutes >= 1440 ) {
		return __( 'midnight', 'cise-core' );
	}
	return date_i18n( get_option( 'time_format', 'g:i a' ), strtotime( '2000-01-01 ' . cise_hhmm( $minutes ) . ':00' ) );
}

/**
 * The bookable halls: key => name. "both" books the two halls together.
 */
function cise_halls() {
	$main = trim( cise_core_get( 'main_name' ) );
	$base = trim( cise_core_get( 'base_name' ) );
	return array(
		'main'     => $main,
		'basement' => $base,
		/* translators: 1: hall 1, 2: hall 2 */
		'both'     => sprintf( __( 'Both halls (%1$s + %2$s)', 'cise-core' ), $main, $base ),
	);
}

/**
 * Hall key from user input; unknown values fall back to the main hall.
 */
function cise_hall_key( $hall ) {
	return isset( cise_halls()[ $hall ] ) ? $hall : 'main';
}

/**
 * Hall name for a stored booking (bookings saved before halls existed blocked the whole centre).
 */
function cise_hall_label( $hall ) {
	$halls = cise_halls();
	return isset( $halls[ $hall ] ) ? $halls[ $hall ] : $halls['both'];
}

/**
 * Do bookings in these two halls compete for the same space?
 */
function cise_halls_clash( $a, $b ) {
	return $a === $b || 'both' === $a || 'both' === $b || '' === $a || '' === $b;
}

/**
 * "08:00-15:00" setting -> array( start minutes, end minutes ); an end of 00:00 is midnight.
 */
function cise_slot_range( $key ) {
	$p = explode( '-', (string) cise_core_get( $key ) );
	$s = cise_min( $p[0] );
	$e = isset( $p[1] ) ? cise_min( $p[1] ) : 0;
	return array( $s, $e <= $s ? 1440 : $e );
}

/**
 * Hourly rate and fixed-price packages for a hall.
 *
 * @return array( 'hourly' => float, 'packages' => list of array( key, label, start, end, price ) ).
 */
function cise_hall_pricing( $hall ) {
	$am   = cise_slot_range( 'slot_am' );
	$pm   = cise_slot_range( 'slot_pm' );
	$full = array( cise_min( cise_core_get( 'open_time' ) ), cise_close_min() );
	if ( 'both' === $hall ) {
		$hourly = (float) cise_core_get( 'rate_main_hour' ) + (float) cise_core_get( 'rate_base_hour' );
		$prices = array( cise_core_get( 'price_both_half' ), cise_core_get( 'price_both_half' ), cise_core_get( 'price_both_full' ) );
	} else {
		$p      = 'main' === $hall ? 'main' : 'base';
		$hourly = (float) cise_core_get( 'rate_' . $p . '_hour' );
		$prices = array( cise_core_get( 'price_' . $p . '_am' ), cise_core_get( 'price_' . $p . '_pm' ), cise_core_get( 'price_' . $p . '_full' ) );
	}
	$slots    = array(
		'am'   => array( __( 'Half day', 'cise-core' ), $am ),
		'pm'   => array( __( 'Half day', 'cise-core' ), $pm ),
		'full' => array( __( 'Full day', 'cise-core' ), $full ),
	);
	$packages = array();
	foreach ( $slots as $key => $slot ) {
		$price = array_shift( $prices );
		if ( '' === (string) $price ) {
			continue; // No package price set: hourly only.
		}
		$packages[] = array(
			'key'   => $key,
			'label' => sprintf( '%s, %s – %s', $slot[0], cise_time_label( $slot[1][0] ), cise_time_label( $slot[1][1] ) ),
			's'     => $slot[1][0],
			'e'     => $slot[1][1],
			'price' => (float) $price,
		);
	}
	return array( 'hourly' => $hourly, 'packages' => $packages );
}

/**
 * All booking fields as an array.
 */
function cise_booking_data( $id ) {
	$keys = array( 'status', 'date', 'start', 'end', 'hall', 'name', 'email', 'phone', 'org_type', 'org_name', 'event_type', 'guests', 'notes', 'estimate', 'staff_note' );
	$out  = array( 'id' => $id );
	foreach ( $keys as $k ) {
		$out[ $k ] = (string) get_post_meta( $id, '_' . $k, true );
	}
	return $out;
}

function cise_booking_statuses() {
	return array(
		'pending'   => __( 'Pending', 'cise-core' ),
		'confirmed' => __( 'Confirmed', 'cise-core' ),
		'declined'  => __( 'Declined', 'cise-core' ),
		'cancelled' => __( 'Cancelled', 'cise-core' ),
	);
}

/**
 * Price quote: the cheaper of the hourly total and any half/full-day package
 * that covers the booked time. (Member discounts are applied on the invoice.)
 *
 * @return array( 'total' => float, 'label' => string ).
 */
function cise_booking_quote( $hall, $start_min, $end_min ) {
	$pricing = cise_hall_pricing( $hall );
	$hours   = max( 0, ( $end_min - $start_min ) / 60 );
	$best    = array(
		'total' => round( $hours * $pricing['hourly'], 2 ),
		/* translators: 1: hourly rate, 2: hours */
		'label' => sprintf( __( '%1$s/hr × %2$s hrs', 'cise-core' ), cise_money( $pricing['hourly'] ), $hours ),
	);
	foreach ( $pricing['packages'] as $p ) {
		if ( $start_min >= $p['s'] && $end_min <= $p['e'] && $p['price'] < $best['total'] ) {
			$best = array( 'total' => $p['price'], 'label' => $p['label'] );
		}
	}
	return $best;
}

function cise_booking_estimate( $hall, $start_min, $end_min ) {
	return cise_booking_quote( $hall, $start_min, $end_min )['total'];
}

/**
 * Busy minute ranges per date (YYYY-MM-DD => [[start, end], …]) for one hall in a
 * month, from website bookings (with the cleanup gap) and Google Calendar. A
 * booking of both halls blocks each hall, and "both" needs both halls free.
 *
 * @param string $month       YYYY-MM.
 * @param string $hall        main | basement | both.
 * @param int    $exclude_id  Booking to ignore (when re-checking an edit).
 */
function cise_booking_busy( $month, $hall, $exclude_id = 0 ) {
	$buffer = (int) cise_core_get( 'buffer_minutes' );
	$busy   = array();

	$bookings = get_posts( array(
		'post_type'      => 'cise_booking',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'fields'         => 'ids',
		'exclude'        => $exclude_id ? array( $exclude_id ) : array(),
		'meta_query'     => array(
			'relation' => 'AND',
			array(
				'key'     => '_date',
				'value'   => $month . '-',
				'compare' => 'LIKE',
			),
			array(
				'key'     => '_status',
				'value'   => CISE_BOOKING_HOLDING,
				'compare' => 'IN',
			),
		),
	) );
	foreach ( $bookings as $id ) {
		if ( ! cise_halls_clash( $hall, (string) get_post_meta( $id, '_hall', true ) ) ) {
			continue;
		}
		$date            = get_post_meta( $id, '_date', true );
		$busy[ $date ][] = array(
			max( 0, cise_min( get_post_meta( $id, '_start', true ) ) - $buffer ),
			min( 1440, cise_min( get_post_meta( $id, '_end', true ) ) + $buffer ),
		);
	}

	// Google busy times, split per day.
	$tz = wp_timezone();
	foreach ( cise_gcal_busy( $month ) as $range ) {
		if ( ! cise_halls_clash( $hall, $range[2] ?? 'both' ) ) {
			continue;
		}
		$cursor = ( new DateTime( '@' . $range[0] ) )->setTimezone( $tz );
		$end    = ( new DateTime( '@' . $range[1] ) )->setTimezone( $tz );
		while ( $cursor < $end ) {
			$day      = $cursor->format( 'Y-m-d' );
			$next_day = ( new DateTime( $day . ' 00:00:00', $tz ) )->modify( '+1 day' );
			$s        = (int) $cursor->format( 'G' ) * 60 + (int) $cursor->format( 'i' );
			$e        = $end < $next_day ? (int) $end->format( 'G' ) * 60 + (int) $end->format( 'i' ) : 1440;
			if ( substr( $day, 0, 7 ) === $month && $e > $s ) {
				$busy[ $day ][] = array( $s, $e );
			}
			$cursor = $next_day;
		}
	}

	foreach ( $busy as $day => $ranges ) {
		$busy[ $day ] = cise_merge_ranges( $ranges );
	}
	return $busy;
}

function cise_merge_ranges( $ranges ) {
	usort( $ranges, function ( $a, $b ) {
		return $a[0] - $b[0];
	} );
	$out = array();
	foreach ( $ranges as $r ) {
		$last = count( $out ) - 1;
		if ( $last >= 0 && $r[0] <= $out[ $last ][1] ) {
			$out[ $last ][1] = max( $out[ $last ][1], $r[1] );
		} else {
			$out[] = $r;
		}
	}
	return $out;
}

/**
 * Bookable window: first and last bookable dates.
 */
function cise_booking_window() {
	$tz    = wp_timezone();
	$first = new DateTime( 'today', $tz );
	$first->modify( '+' . (int) cise_core_get( 'notice_days' ) . ' days' );
	$last = new DateTime( 'today', $tz );
	$last->modify( '+' . max( 1, (int) cise_core_get( 'max_months' ) ) . ' months' );
	return array( $first->format( 'Y-m-d' ), $last->format( 'Y-m-d' ) );
}

/**
 * Availability for a month: date => [ status, busy ranges ].
 * Status: open | partial | full | closed | past.
 */
function cise_booking_month( $month, $hall ) {
	list( $first, $last ) = cise_booking_window();

	$open   = cise_min( cise_core_get( 'open_time' ) );
	$close  = cise_close_min();
	$min    = (int) round( (float) cise_core_get( 'min_hours' ) * 60 );
	$closed = array_map( 'intval', (array) cise_core_get( 'closed_weekdays' ) );
	$busy   = cise_booking_busy( $month, $hall );
	$days   = (int) gmdate( 't', strtotime( $month . '-01' ) );
	$out    = array();

	for ( $d = 1; $d <= $days; $d++ ) {
		$date   = sprintf( '%s-%02d', $month, $d );
		$ranges = isset( $busy[ $date ] ) ? $busy[ $date ] : array();
		if ( $date < $first ) {
			$status = 'past';
		} elseif ( $date > $last || in_array( (int) gmdate( 'w', strtotime( $date ) ), $closed, true ) ) {
			$status = 'closed';
		} else {
			$gap    = cise_largest_gap( $ranges, $open, $close );
			$status = $gap < $min ? 'full' : ( $ranges ? 'partial' : 'open' );
		}
		$out[ $date ] = array(
			's' => $status,
			'b' => 'past' === $status || 'closed' === $status ? array() : $ranges,
		);
	}
	return $out;
}

function cise_largest_gap( $ranges, $open, $close ) {
	$best   = 0;
	$cursor = $open;
	foreach ( $ranges as $r ) {
		if ( $r[0] > $cursor ) {
			$best = max( $best, min( $r[0], $close ) - $cursor );
		}
		$cursor = max( $cursor, $r[1] );
	}
	return max( $best, $close - $cursor );
}

/**
 * Check a requested slot.
 *
 * @return true|WP_Error
 */
function cise_booking_check_slot( $date, $start, $end, $hall, $exclude_id = 0 ) {
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || ! preg_match( '/^\d{2}:\d{2}$/', $start ) || ! preg_match( '/^\d{2}:\d{2}$/', $end ) ) {
		return new WP_Error( 'bad_slot', __( 'Please choose a date and time.', 'cise-core' ) );
	}
	list( $first, $last ) = cise_booking_window();
	if ( $date < $first || $date > $last ) {
		return new WP_Error( 'bad_slot', __( 'That date can no longer be booked online. Please pick another date or contact us.', 'cise-core' ) );
	}
	if ( in_array( (int) gmdate( 'w', strtotime( $date ) ), array_map( 'intval', (array) cise_core_get( 'closed_weekdays' ) ), true ) ) {
		return new WP_Error( 'bad_slot', __( 'The hall is closed that day.', 'cise-core' ) );
	}
	$s = cise_min( $start );
	$e = cise_min( $end );
	if ( $s < cise_min( cise_core_get( 'open_time' ) ) || $e > cise_close_min() ) {
		return new WP_Error( 'bad_slot', __( 'Those times are outside the hall hours.', 'cise-core' ) );
	}
	if ( $e - $s < (int) round( (float) cise_core_get( 'min_hours' ) * 60 ) ) {
		/* translators: %s: hours */
		return new WP_Error( 'bad_slot', sprintf( __( 'The minimum booking is %s hours.', 'cise-core' ), cise_core_get( 'min_hours' ) ) );
	}
	$busy = cise_booking_busy( substr( $date, 0, 7 ), $hall, $exclude_id );
	foreach ( isset( $busy[ $date ] ) ? $busy[ $date ] : array() as $r ) {
		if ( $s < $r[1] && $e > $r[0] ) {
			return new WP_Error( 'taken', __( 'Sorry, that hall is booked at that time. Please choose another time or hall.', 'cise-core' ) );
		}
	}
	return true;
}

/* ---------- REST API ---------- */

add_action( 'rest_api_init', function () {
	register_rest_route( 'cise/v1', '/availability', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'args'                => array(
			'month' => array(
				'required'          => true,
				'validate_callback' => function ( $v ) {
					return (bool) preg_match( '/^\d{4}-\d{2}$/', $v );
				},
			),
			'hall'  => array(
				'default' => 'main',
			),
		),
		'callback'            => function ( WP_REST_Request $req ) {
			$res = rest_ensure_response( array( 'days' => cise_booking_month( $req['month'], cise_hall_key( (string) $req['hall'] ) ) ) );
			$res->header( 'Cache-Control', 'no-store' );
			return $res;
		},
	) );

	register_rest_route( 'cise/v1', '/bookings', array(
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => 'cise_booking_rest_create',
	) );
} );

/**
 * Create a booking request from the public form.
 */
function cise_booking_rest_create( WP_REST_Request $req ) {
	if ( '1' !== (string) cise_core_get( 'booking_open' ) ) {
		return new WP_Error( 'closed', __( 'Online booking requests are paused. Please contact us.', 'cise-core' ), array( 'status' => 403 ) );
	}
	$p = $req->get_json_params();
	if ( ! is_array( $p ) ) {
		return new WP_Error( 'bad', __( 'Something went wrong. Please try again.', 'cise-core' ), array( 'status' => 400 ) );
	}

	// Spam traps: hidden field must be empty, and humans take more than a few seconds.
	if ( ! empty( $p['website'] ) || ( isset( $p['elapsed'] ) && (int) $p['elapsed'] < 4 ) ) {
		return new WP_Error( 'bad', __( 'Something went wrong. Please try again.', 'cise-core' ), array( 'status' => 400 ) );
	}
	if ( ! cise_rate_limit( 'booking', 6 ) ) {
		return new WP_Error( 'slow', __( 'Too many requests from your connection. Please try again later or email us.', 'cise-core' ), array( 'status' => 429 ) );
	}

	$f = array(
		'date'       => sanitize_text_field( $p['date'] ?? '' ),
		'start'      => sanitize_text_field( $p['start'] ?? '' ),
		'end'        => sanitize_text_field( $p['end'] ?? '' ),
		'hall'       => cise_hall_key( sanitize_key( $p['hall'] ?? '' ) ),
		'name'       => sanitize_text_field( $p['name'] ?? '' ),
		'email'      => sanitize_email( $p['email'] ?? '' ),
		'phone'      => sanitize_text_field( $p['phone'] ?? '' ),
		'org_type'   => 'member' === ( $p['org_type'] ?? '' ) ? 'member' : 'nonmember',
		'org_name'   => sanitize_text_field( $p['org_name'] ?? '' ),
		'event_type' => sanitize_text_field( $p['event_type'] ?? '' ),
		'guests'     => (string) absint( $p['guests'] ?? 0 ),
		'notes'      => sanitize_textarea_field( $p['notes'] ?? '' ),
	);

	$errors = array();
	if ( '' === $f['name'] ) {
		$errors['name'] = __( 'Please enter your name.', 'cise-core' );
	}
	if ( ! is_email( $f['email'] ) ) {
		$errors['email'] = __( 'Please enter a valid email.', 'cise-core' );
	}
	if ( strlen( preg_replace( '/\D/', '', $f['phone'] ) ) < 7 ) {
		$errors['phone'] = __( 'Please enter a phone number.', 'cise-core' );
	}
	if ( 'member' === $f['org_type'] && '' === $f['org_name'] ) {
		$errors['org_name'] = __( 'Which member society is booking?', 'cise-core' );
	}
	if ( '' === $f['event_type'] ) {
		$errors['event_type'] = __( 'Please choose the type of event.', 'cise-core' );
	}
	$cap = (int) cise_core_get( 'hall_capacity' );
	if ( (int) $f['guests'] < 1 ) {
		$errors['guests'] = __( 'How many guests do you expect?', 'cise-core' );
	} elseif ( $cap && (int) $f['guests'] > $cap ) {
		/* translators: %d: capacity */
		$errors['guests'] = sprintf( __( 'The hall holds up to %d guests.', 'cise-core' ), $cap );
	}
	if ( empty( $p['agree'] ) ) {
		$errors['agree'] = __( 'Please agree to the hall rental rules.', 'cise-core' );
	}
	if ( $errors ) {
		return new WP_Error( 'invalid', __( 'Please check the highlighted fields.', 'cise-core' ), array( 'status' => 422, 'fields' => $errors ) );
	}

	$slot = cise_booking_check_slot( $f['date'], $f['start'], $f['end'], $f['hall'] );
	if ( is_wp_error( $slot ) ) {
		$slot->add_data( array( 'status' => 409 ) );
		return $slot;
	}

	$f['estimate'] = (string) cise_booking_estimate( $f['hall'], cise_min( $f['start'] ), cise_min( $f['end'] ) );
	$f['status']   = 'pending';

	$id = wp_insert_post( array(
		'post_type'   => 'cise_booking',
		'post_status' => 'publish',
		'post_title'  => cise_booking_title( $f ),
	), true );
	if ( is_wp_error( $id ) ) {
		return new WP_Error( 'save', __( 'We could not save your request. Please email us.', 'cise-core' ), array( 'status' => 500 ) );
	}
	foreach ( $f as $k => $v ) {
		update_post_meta( $id, '_' . $k, $v );
	}
	update_post_meta( $id, '_ref', strtoupper( wp_generate_password( 6, false ) ) );

	cise_booking_notify( $id, 'new' );
	cise_gcal_sync_booking( $id );

	return rest_ensure_response( array(
		'ok'      => true,
		'ref'     => get_post_meta( $id, '_ref', true ),
		'message' => sprintf(
			/* translators: 1: email, 2: business days */
			__( 'Thank you! Your request is in and the time is held for you. We have emailed a copy to %1$s and will confirm within %2$s business days, then send your invoice.', 'cise-core' ),
			$f['email'],
			cise_core_get( 'confirm_days' )
		),
	) );
}

/**
 * Admin list title: "Nov 20, 2026 – Main Hall – Gujarati Samaj".
 */
function cise_booking_title( $b ) {
	$who = $b['org_name'] ? $b['org_name'] : ( $b['name'] ? $b['name'] : ( $b['event_type'] ? $b['event_type'] : __( 'Blocked', 'cise-core' ) ) );
	$all = cise_halls();
	return sprintf(
		'%s – %s – %s',
		$b['date'] ? date_i18n( 'M j, Y', strtotime( $b['date'] ) ) : '?',
		'both' === $b['hall'] ? __( 'Both halls', 'cise-core' ) : ( $all[ $b['hall'] ] ?? $all['main'] ),
		$who
	);
}

/**
 * Simple per-IP rate limit.
 */
function cise_rate_limit( $action, $per_hour ) {
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'cise_rl_' . $action . '_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= $per_hour ) {
		return false;
	}
	set_transient( $key, $n + 1, HOUR_IN_SECONDS );
	return true;
}

/**
 * Booking emails.
 *
 * @param string $event new | confirmed | declined | cancelled.
 */
function cise_booking_notify( $id, $event ) {
	$b    = cise_booking_data( $id );
	$ref  = get_post_meta( $id, '_ref', true );
	$when = date_i18n( 'l, F j, Y', strtotime( $b['date'] ) ) . ', ' . cise_time_label( cise_min( $b['start'] ) ) . ' – ' . cise_time_label( cise_min( $b['end'] ) );
	$rows = array(
		__( 'Reference', 'cise-core' )     => $ref,
		__( 'When', 'cise-core' )          => $when,
		__( 'Hall', 'cise-core' )          => cise_hall_label( $b['hall'] ) . ', ' . cise_core_get( 'venue_name' ),
		__( 'Event', 'cise-core' )         => $b['event_type'],
		__( 'Guests', 'cise-core' )        => $b['guests'],
		__( 'Name', 'cise-core' )          => $b['name'],
		__( 'Organization', 'cise-core' )  => ( 'member' === $b['org_type'] ? __( 'Member society', 'cise-core' ) : __( 'Non-member', 'cise-core' ) ) . ( $b['org_name'] ? ' – ' . $b['org_name'] : '' ),
		__( 'Email', 'cise-core' )         => $b['email'],
		__( 'Phone', 'cise-core' )         => $b['phone'],
		__( 'Notes', 'cise-core' )         => $b['notes'],
		__( 'Estimated rental', 'cise-core' ) => cise_money( $b['estimate'] ),
	);
	$staff_note = $b['staff_note'];

	switch ( $event ) {
		case 'new':
			cise_core_mail(
				cise_core_staff_email(),
				/* translators: %s: date */
				sprintf( __( 'New hall booking request: %s', 'cise-core' ), $when ),
				__( 'A new hall booking request came in. The time is held as pending until you confirm or decline it.', 'cise-core' ),
				$rows,
				array(
					'reply_to'     => $b['email'],
					'button_url'   => admin_url( 'post.php?action=edit&post=' . $id ),
					'button_label' => __( 'Review request', 'cise-core' ),
				)
			);
			cise_core_mail(
				$b['email'],
				__( 'We received your hall booking request', 'cise-core' ),
				/* translators: 1: name, 2: days */
				sprintf( __( "Hi %1\$s,\n\nThanks for your request. Your time is held while we review it, and we will confirm within %2\$s business days.", 'cise-core' ), $b['name'], cise_core_get( 'confirm_days' ) ),
				$rows,
				array( 'outro' => cise_core_get( 'invoice_note' ), 'reply_to' => cise_core_public_email() )
			);
			break;

		case 'confirmed':
			cise_core_mail(
				$b['email'],
				__( 'Your hall booking is confirmed', 'cise-core' ),
				/* translators: %s: name */
				sprintf( __( "Hi %s,\n\nGood news: your hall booking is confirmed. We will email your invoice through Square shortly.", 'cise-core' ), $b['name'] ) . ( $staff_note ? "\n\n" . $staff_note : '' ),
				$rows,
				array( 'outro' => __( 'Questions? Just reply to this email.', 'cise-core' ), 'reply_to' => cise_core_public_email() )
			);
			break;

		case 'declined':
		case 'cancelled':
			cise_core_mail(
				$b['email'],
				'declined' === $event ? __( 'About your hall booking request', 'cise-core' ) : __( 'Your hall booking was cancelled', 'cise-core' ),
				( 'declined' === $event
					/* translators: %s: name */
					? sprintf( __( "Hi %s,\n\nSorry, we can't accept this booking request.", 'cise-core' ), $b['name'] )
					/* translators: %s: name */
					: sprintf( __( "Hi %s,\n\nYour hall booking has been cancelled.", 'cise-core' ), $b['name'] )
				) . ( $staff_note ? "\n\n" . $staff_note : '' ),
				$rows,
				array( 'outro' => __( 'Questions? Just reply to this email.', 'cise-core' ), 'reply_to' => cise_core_public_email() )
			);
			break;
	}
}

/* ---------- Front end ---------- */

/**
 * Print the booking app (called by the theme's hall booking page, or [cise_hall_booking]).
 */
function cise_core_booking_app() {
	wp_enqueue_style( 'cise-core' );
	wp_enqueue_script( 'cise-booking' );

	$assoc = cise_core_lines( 'associations' );
	$types = cise_core_lines( 'event_types' );
	$rules = get_page_by_path( 'hall-booking' ) ? '#rules' : '';
	$halls = array();
	foreach ( cise_halls() as $key => $name ) {
		$halls[ $key ] = array_merge( array( 'name' => $name ), cise_hall_pricing( $key ) );
	}

	// Inline JSON (not wp_localize_script, which turns numbers into strings).
	wp_add_inline_script( 'cise-booking', 'var CISE_BOOKING = ' . wp_json_encode( array(
		'api'      => esc_url_raw( rest_url( 'cise/v1/' ) ),
		'open'     => cise_min( cise_core_get( 'open_time' ) ),
		'close'    => cise_close_min(),
		'step'     => (int) cise_core_get( 'slot_minutes' ),
		'min'      => (int) round( (float) cise_core_get( 'min_hours' ) * 60 ),
		'window'   => cise_booking_window(),
		'halls'    => $halls,
		'locale'   => str_replace( '_', '-', get_locale() ),
		'weekStart' => (int) get_option( 'start_of_week', 0 ),
		'i18n'     => array(
			'pickDate'  => __( 'Pick a date', 'cise-core' ),
			'pickTime'  => __( 'Pick a time', 'cise-core' ),
			'booked'    => __( 'Unavailable:', 'cise-core' ),
			'allFree'   => __( 'The whole day is open.', 'cise-core' ),
			'hrs'       => __( 'hrs', 'cise-core' ),
			'sending'   => __( 'Sending…', 'cise-core' ),
			'send'      => __( 'Request booking', 'cise-core' ),
			'error'     => __( 'Something went wrong. Please try again or email us.', 'cise-core' ),
			'loadError' => __( 'Could not load availability. Please refresh the page.', 'cise-core' ),
			'tbd'       => __( 'Set by CISE', 'cise-core' ),
			'perHr'     => __( '/hr', 'cise-core' ),
			'quick'     => __( 'Quick pick:', 'cise-core' ),
		),
	) ) . ';', 'before' );

	if ( '1' !== (string) cise_core_get( 'booking_open' ) ) {
		cise_core_notice( __( 'Online booking requests are paused right now. Please contact us to book the hall.', 'cise-core' ), 'warn' );
		return;
	}
	$money = function ( $key, $suffix = '' ) {
		$v = cise_core_get( $key );
		return '' === $v ? '—' : cise_money( $v ) . $suffix;
	};
	?>
	<div class="cise-booking" data-cise-booking>
		<div class="cb-main">
			<section class="cb-step" aria-labelledby="cb-h1">
				<h2 id="cb-h1"><span class="cb-num">1</span><?php esc_html_e( 'Choose a hall and date', 'cise-core' ); ?></h2>
				<fieldset class="cb-halls">
					<legend class="screen-reader-text"><?php esc_html_e( 'Hall', 'cise-core' ); ?></legend>
					<?php foreach ( $halls as $key => $h ) : ?>
						<?php
						$from = $h['hourly'] ? cise_money( $h['hourly'] ) . __( '/hr', 'cise-core' ) : '';
						foreach ( $h['packages'] as $p ) {
							if ( 'full' === $p['key'] ) {
								/* translators: %s: price */
								$from .= ( $from ? ' · ' : '' ) . sprintf( __( 'full day %s', 'cise-core' ), cise_money( $p['price'] ) );
							}
						}
						?>
						<label class="cb-hall">
							<input type="radio" name="hall" value="<?php echo esc_attr( $key ); ?>" <?php checked( 'main', $key ); ?>>
							<span><strong><?php echo esc_html( 'both' === $key ? __( 'Both halls', 'cise-core' ) : $h['name'] ); ?></strong><small><?php echo esc_html( $from ); ?></small></span>
						</label>
					<?php endforeach; ?>
				</fieldset>
				<div class="cb-cal">
					<div class="cb-cal__head">
						<button type="button" class="cb-cal__nav" data-nav="-1" aria-label="<?php esc_attr_e( 'Previous month', 'cise-core' ); ?>">&#8249;</button>
						<strong class="cb-cal__title" aria-live="polite"></strong>
						<button type="button" class="cb-cal__nav" data-nav="1" aria-label="<?php esc_attr_e( 'Next month', 'cise-core' ); ?>">&#8250;</button>
					</div>
					<div class="cb-cal__grid" role="grid"></div>
					<div class="cb-legend">
						<span><i class="lg-open"></i><?php esc_html_e( 'Available', 'cise-core' ); ?></span>
						<span><i class="lg-partial"></i><?php esc_html_e( 'Partly booked', 'cise-core' ); ?></span>
						<span><i class="lg-full"></i><?php esc_html_e( 'Booked', 'cise-core' ); ?></span>
						<span><i class="lg-pick"></i><?php esc_html_e( 'Your pick', 'cise-core' ); ?></span>
					</div>
				</div>
				<div class="cb-times" hidden>
					<p class="cb-busy"></p>
					<div class="cb-quick"></div>
					<div class="cb-row">
						<label><?php esc_html_e( 'Start time', 'cise-core' ); ?><select name="start"></select></label>
						<label><?php esc_html_e( 'End time', 'cise-core' ); ?><select name="end"></select></label>
					</div>
				</div>
			</section>

			<form class="cb-step cb-form" novalidate aria-labelledby="cb-h2">
				<h2 id="cb-h2"><span class="cb-num">2</span><?php esc_html_e( 'Your event', 'cise-core' ); ?></h2>
				<div class="cb-row">
					<label><?php esc_html_e( 'Full name', 'cise-core' ); ?><input name="name" autocomplete="name" placeholder="<?php esc_attr_e( 'Your name', 'cise-core' ); ?>" required></label>
					<label><?php esc_html_e( 'Organization', 'cise-core' ); ?>
						<select name="org_type">
							<option value="member"><?php esc_html_e( 'Member society (discounted rate)', 'cise-core' ); ?></option>
							<option value="nonmember"><?php esc_html_e( 'Non-member or individual', 'cise-core' ); ?></option>
						</select>
					</label>
				</div>
				<div class="cb-row" data-member-only>
					<label class="cb-full"><?php esc_html_e( 'Member society', 'cise-core' ); ?>
						<?php if ( $assoc ) : ?>
							<select name="org_name">
								<option value=""><?php esc_html_e( 'Select your society', 'cise-core' ); ?></option>
								<?php foreach ( $assoc as $a ) : ?>
									<option><?php echo esc_html( $a ); ?></option>
								<?php endforeach; ?>
							</select>
						<?php else : ?>
							<input name="org_name" placeholder="<?php esc_attr_e( 'Name of your society', 'cise-core' ); ?>">
						<?php endif; ?>
					</label>
				</div>
				<div class="cb-row">
					<label><?php esc_html_e( 'Email', 'cise-core' ); ?><input type="email" name="email" autocomplete="email" placeholder="you@example.com" required></label>
					<label><?php esc_html_e( 'Phone', 'cise-core' ); ?><input type="tel" name="phone" autocomplete="tel" placeholder="780 555 0123" required></label>
				</div>
				<div class="cb-row">
					<label><?php esc_html_e( 'Type of event', 'cise-core' ); ?>
						<select name="event_type" required>
							<?php foreach ( $types as $t ) : ?>
								<option><?php echo esc_html( $t ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<label><?php esc_html_e( 'Expected guests', 'cise-core' ); ?><input type="number" name="guests" min="1" <?php echo cise_core_get( 'hall_capacity' ) ? 'max="' . (int) cise_core_get( 'hall_capacity' ) . '"' : ''; ?> inputmode="numeric" placeholder="<?php esc_attr_e( 'e.g. 120', 'cise-core' ); ?>" required></label>
				</div>
				<label class="cb-full"><?php esc_html_e( 'Anything we should know?', 'cise-core' ); ?><textarea name="notes" rows="4" placeholder="<?php esc_attr_e( 'Kitchen use, setup time, A/V needs…', 'cise-core' ); ?>"></textarea></label>
				<label class="cb-hp" aria-hidden="true">Website<input name="website" tabindex="-1" autocomplete="off"></label>
				<label class="cb-check"><input type="checkbox" name="agree" required>
					<span><?php
					printf(
						/* translators: %s: link to rules */
						wp_kses_post( __( 'I have read and agree to the %s and cancellation policy.', 'cise-core' ) ),
						'<a href="' . esc_attr( $rules ) . '">' . esc_html__( 'hall rental rules', 'cise-core' ) . '</a>'
					);
					?></span>
				</label>
				<div class="cb-error" role="alert" hidden></div>
			</form>

			<section class="cb-step" aria-labelledby="cb-h3">
				<h2 id="cb-h3"><span class="cb-num">3</span><?php esc_html_e( 'Confirmation & payment', 'cise-core' ); ?></h2>
				<p><?php echo esc_html( cise_core_get( 'invoice_note' ) ); ?></p>
			</section>
		</div>

		<aside class="cb-side">
			<div class="cb-summary">
				<h2><?php esc_html_e( 'Booking summary', 'cise-core' ); ?></h2>
				<div class="kv"><span><?php esc_html_e( 'Hall', 'cise-core' ); ?></span><strong data-sum="hall">—</strong></div>
				<div class="kv"><span><?php esc_html_e( 'Date', 'cise-core' ); ?></span><strong data-sum="date">—</strong></div>
				<div class="kv"><span><?php esc_html_e( 'Time', 'cise-core' ); ?></span><strong data-sum="time">—</strong></div>
				<div class="kv"><span><?php esc_html_e( 'Rate', 'cise-core' ); ?></span><strong data-sum="rate">—</strong></div>
				<div class="cb-total">
					<div class="kv"><span><?php esc_html_e( 'Estimated rental', 'cise-core' ); ?></span><strong data-sum="total">—</strong></div>
					<div class="kv cb-due"><span><?php esc_html_e( 'Due today', 'cise-core' ); ?></span><strong>$0</strong></div>
				</div>
				<button type="button" class="btn btn--primary btn--block cb-submit" disabled><?php esc_html_e( 'Request booking', 'cise-core' ); ?></button>
				<p class="cb-small"><?php esc_html_e( 'Questions? Email', 'cise-core' ); ?> <a href="mailto:<?php echo esc_attr( antispambot( cise_core_public_email() ) ); ?>"><?php echo esc_html( antispambot( cise_core_public_email() ) ); ?></a></p>
				<div class="cb-rates">
					<h3><?php esc_html_e( 'Rates', 'cise-core' ); ?></h3>
					<?php foreach ( $halls as $key => $h ) : ?>
						<div class="kv"><span><?php echo esc_html( 'both' === $key ? __( 'Both halls', 'cise-core' ) : $h['name'] ); ?></span><span><?php echo esc_html( $h['hourly'] ? cise_money( $h['hourly'] ) . ' / hr' : '—' ); ?></span></div>
						<?php foreach ( $h['packages'] as $p ) : ?>
							<div class="kv cb-sub"><span><?php echo esc_html( $p['label'] ); ?></span><span><?php echo esc_html( cise_money( $p['price'] ) ); ?></span></div>
						<?php endforeach; ?>
					<?php endforeach; ?>
					<?php if ( cise_core_get( 'damage_deposit' ) ) : ?>
						<div class="kv"><span><?php esc_html_e( 'Damage deposit', 'cise-core' ); ?></span><span><?php echo esc_html( $money( 'damage_deposit' ) ); ?></span></div>
					<?php endif; ?>
					<p class="cb-small"><?php esc_html_e( 'Member society discounts are applied on your invoice.', 'cise-core' ); ?><?php echo $rules ? ' <a href="#fees">' . esc_html__( 'All fees', 'cise-core' ) . '</a>' : ''; ?></p>
				</div>
			</div>
		</aside>

		<div class="cb-done" hidden>
			<div class="cb-done__icon" aria-hidden="true">&#10003;</div>
			<h2><?php esc_html_e( 'Request sent', 'cise-core' ); ?></h2>
			<p class="cb-done__msg"></p>
			<p class="cb-done__ref"></p>
		</div>
	</div>
	<?php
}

add_shortcode( 'cise_hall_booking', function () {
	ob_start();
	cise_core_booking_app();
	return ob_get_clean();
} );
