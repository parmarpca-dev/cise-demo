<?php
/**
 * Post types: Events, Sponsors, Hall bookings, Nominations.
 *
 * @package cise-core
 */

defined( 'ABSPATH' ) || exit;

function cise_core_register_post_types() {
	register_post_type( 'cise_event', array(
		'labels'        => array(
			'name'          => __( 'Events', 'cise-core' ),
			'singular_name' => __( 'Event', 'cise-core' ),
			'add_new_item'  => __( 'Add event', 'cise-core' ),
			'edit_item'     => __( 'Edit event', 'cise-core' ),
			'all_items'     => __( 'Events', 'cise-core' ),
		),
		'public'        => true,
		'show_in_rest'  => true,
		'show_in_menu'  => 'cise',
		'has_archive'   => false,
		'rewrite'       => array( 'slug' => 'event' ),
		'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
		'menu_icon'     => 'dashicons-calendar-alt',
	) );

	register_post_type( 'cise_sponsor', array(
		'labels'       => array(
			'name'          => __( 'Sponsors', 'cise-core' ),
			'singular_name' => __( 'Sponsor', 'cise-core' ),
			'add_new_item'  => __( 'Add sponsor', 'cise-core' ),
			'edit_item'     => __( 'Edit sponsor', 'cise-core' ),
			'all_items'     => __( 'Sponsors', 'cise-core' ),
			'featured_image' => __( 'Sponsor logo', 'cise-core' ),
			'set_featured_image' => __( 'Set sponsor logo', 'cise-core' ),
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => 'cise',
		'supports'     => array( 'title', 'thumbnail', 'page-attributes' ),
	) );

	$private = array(
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => 'cise',
		'supports'        => array( 'title' ),
		'capability_type' => 'post',
		'capabilities'    => array(
			'edit_post'          => CISE_CORE_CAP,
			'read_post'          => CISE_CORE_CAP,
			'delete_post'        => CISE_CORE_CAP,
			'edit_posts'         => CISE_CORE_CAP,
			'edit_others_posts'  => CISE_CORE_CAP,
			'publish_posts'      => CISE_CORE_CAP,
			'read_private_posts' => CISE_CORE_CAP,
			'delete_posts'       => CISE_CORE_CAP,
			'create_posts'       => CISE_CORE_CAP,
		),
		'map_meta_cap'    => false,
	);

	register_post_type( 'cise_booking', array_merge( $private, array(
		'labels' => array(
			'name'          => __( 'Hall bookings', 'cise-core' ),
			'singular_name' => __( 'Hall booking', 'cise-core' ),
			'add_new_item'  => __( 'Add booking (or block off time)', 'cise-core' ),
			'edit_item'     => __( 'Booking', 'cise-core' ),
			'all_items'     => __( 'Hall bookings', 'cise-core' ),
		),
	) ) );

	register_post_type( 'cise_nomination', array_merge( $private, array(
		'labels'       => array(
			'name'          => __( 'Nominations', 'cise-core' ),
			'singular_name' => __( 'Nomination', 'cise-core' ),
			'edit_item'     => __( 'Nomination', 'cise-core' ),
			'all_items'     => __( 'Award nominations', 'cise-core' ),
		),
		'capabilities' => array_merge( $private['capabilities'], array( 'create_posts' => 'do_not_allow' ) ),
	) ) );
}
add_action( 'init', 'cise_core_register_post_types' );

/* ---------- Event details meta box ---------- */

add_action( 'add_meta_boxes_cise_event', function () {
	add_meta_box( 'cise_event_details', __( 'Event details', 'cise-core' ), 'cise_core_event_box', 'cise_event', 'side', 'high' );
} );

function cise_core_event_box( $post ) {
	wp_nonce_field( 'cise_event_save', 'cise_event_nonce' );
	$date     = get_post_meta( $post->ID, '_cise_event_date', true );
	$tbc      = get_post_meta( $post->ID, '_cise_event_tbc', true );
	$time     = get_post_meta( $post->ID, '_cise_event_time', true );
	$location = get_post_meta( $post->ID, '_cise_event_location', true );
	?>
	<p><label for="cise_event_date"><strong><?php esc_html_e( 'Date', 'cise-core' ); ?></strong></label><br>
		<input type="date" id="cise_event_date" name="cise_event_date" value="<?php echo esc_attr( $date ); ?>" style="width:100%"></p>
	<p><label><input type="checkbox" name="cise_event_tbc" value="1" <?php checked( $tbc, '1' ); ?>> <?php esc_html_e( 'Exact day not confirmed yet (shows "TBC")', 'cise-core' ); ?></label></p>
	<p><label for="cise_event_time"><strong><?php esc_html_e( 'Time', 'cise-core' ); ?></strong></label><br>
		<input type="text" id="cise_event_time" name="cise_event_time" value="<?php echo esc_attr( $time ); ?>" placeholder="5:00 pm – 9:00 pm" style="width:100%"></p>
	<p><label for="cise_event_location"><strong><?php esc_html_e( 'Location', 'cise-core' ); ?></strong></label><br>
		<input type="text" id="cise_event_location" name="cise_event_location" value="<?php echo esc_attr( $location ); ?>" placeholder="India Centre" style="width:100%"></p>
	<p class="description"><?php esc_html_e( 'The short summary under each event comes from the Excerpt panel; the photo from the Featured image.', 'cise-core' ); ?></p>
	<?php
}

add_action( 'save_post_cise_event', function ( $post_id ) {
	if ( ! isset( $_POST['cise_event_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['cise_event_nonce'] ), 'cise_event_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$date = isset( $_POST['cise_event_date'] ) ? sanitize_text_field( wp_unslash( $_POST['cise_event_date'] ) ) : '';
	update_post_meta( $post_id, '_cise_event_date', preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ? $date : '' );
	update_post_meta( $post_id, '_cise_event_tbc', empty( $_POST['cise_event_tbc'] ) ? '' : '1' );
	update_post_meta( $post_id, '_cise_event_time', isset( $_POST['cise_event_time'] ) ? sanitize_text_field( wp_unslash( $_POST['cise_event_time'] ) ) : '' );
	update_post_meta( $post_id, '_cise_event_location', isset( $_POST['cise_event_location'] ) ? sanitize_text_field( wp_unslash( $_POST['cise_event_location'] ) ) : '' );
} );

add_filter( 'manage_cise_event_posts_columns', function ( $cols ) {
	return array_slice( $cols, 0, 2, true ) + array( 'cise_date' => __( 'Event date', 'cise-core' ) ) + array_slice( $cols, 2, null, true );
} );

add_action( 'manage_cise_event_posts_custom_column', function ( $col, $post_id ) {
	if ( 'cise_date' === $col ) {
		$date = get_post_meta( $post_id, '_cise_event_date', true );
		echo $date ? esc_html( date_i18n( 'M j, Y', strtotime( $date ) ) . ( get_post_meta( $post_id, '_cise_event_tbc', true ) ? ' (TBC)' : '' ) ) : '&mdash;';
	}
}, 10, 2 );

/* ---------- Sponsor link ---------- */

add_action( 'add_meta_boxes_cise_sponsor', function () {
	add_meta_box( 'cise_sponsor_link', __( 'Sponsor website', 'cise-core' ), function ( $post ) {
		wp_nonce_field( 'cise_sponsor_save', 'cise_sponsor_nonce' );
		printf( '<input type="url" name="cise_sponsor_url" value="%s" placeholder="https://" style="width:100%%">', esc_attr( get_post_meta( $post->ID, '_cise_sponsor_url', true ) ) );
		echo '<p class="description">' . esc_html__( 'Upload the logo as the featured image. Order sponsors with the "Order" box.', 'cise-core' ) . '</p>';
	}, 'cise_sponsor', 'normal' );
} );

add_action( 'save_post_cise_sponsor', function ( $post_id ) {
	if ( ! isset( $_POST['cise_sponsor_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['cise_sponsor_nonce'] ), 'cise_sponsor_save' ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	update_post_meta( $post_id, '_cise_sponsor_url', isset( $_POST['cise_sponsor_url'] ) ? esc_url_raw( wp_unslash( $_POST['cise_sponsor_url'] ) ) : '' );
} );
