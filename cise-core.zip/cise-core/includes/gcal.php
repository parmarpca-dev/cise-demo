<?php
/**
 * Google Calendar sync through a service account (free, no plugin).
 *
 * Bookings are written to the calendar (insert / update / delete), and busy times
 * already in the calendar are read back so the website shows them as booked.
 *
 * The key can be pasted in CISE > Settings > Google Calendar, or kept outside the
 * database by defining CISE_GCAL_KEY_FILE (path to the JSON key) in wp-config.php.
 *
 * @package cise-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Service account credentials, or null.
 */
function cise_gcal_key() {
	if ( defined( 'CISE_GCAL_KEY_FILE' ) && is_readable( CISE_GCAL_KEY_FILE ) ) {
		$json = json_decode( file_get_contents( CISE_GCAL_KEY_FILE ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	} else {
		$saved = get_option( 'cise_core_settings', array() );
		$json  = ! empty( $saved['gcal_key'] ) ? json_decode( $saved['gcal_key'], true ) : null;
	}
	return ( is_array( $json ) && ! empty( $json['client_email'] ) && ! empty( $json['private_key'] ) ) ? $json : null;
}

function cise_gcal_enabled() {
	return cise_gcal_key() && cise_core_get( 'gcal_calendar_id' ) && function_exists( 'openssl_sign' );
}

function cise_gcal_b64( $data ) {
	return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
}

/**
 * OAuth access token (cached ~50 minutes).
 *
 * @return string|WP_Error
 */
function cise_gcal_token() {
	$cached = get_transient( 'cise_gcal_token' );
	if ( $cached ) {
		return $cached;
	}
	$key = cise_gcal_key();
	if ( ! $key ) {
		return new WP_Error( 'cise_gcal', __( 'No Google service account key saved.', 'cise-core' ) );
	}
	$now   = time();
	$aud   = ! empty( $key['token_uri'] ) ? $key['token_uri'] : 'https://oauth2.googleapis.com/token';
	$head  = cise_gcal_b64( wp_json_encode( array( 'alg' => 'RS256', 'typ' => 'JWT' ) ) );
	$claim = cise_gcal_b64( wp_json_encode( array(
		'iss'   => $key['client_email'],
		'scope' => 'https://www.googleapis.com/auth/calendar',
		'aud'   => $aud,
		'iat'   => $now,
		'exp'   => $now + 3600,
	) ) );
	$signature = '';
	if ( ! openssl_sign( $head . '.' . $claim, $signature, $key['private_key'], 'sha256WithRSAEncryption' ) ) {
		return new WP_Error( 'cise_gcal', __( 'Could not sign the Google request. Check the private key in the JSON.', 'cise-core' ) );
	}
	$response = wp_remote_post( $aud, array(
		'timeout' => 15,
		'body'    => array(
			'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
			'assertion'  => $head . '.' . $claim . '.' . cise_gcal_b64( $signature ),
		),
	) );
	if ( is_wp_error( $response ) ) {
		return $response;
	}
	$body = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( empty( $body['access_token'] ) ) {
		/* translators: %s: Google error */
		return new WP_Error( 'cise_gcal', sprintf( __( 'Google refused the key: %s', 'cise-core' ), isset( $body['error_description'] ) ? $body['error_description'] : wp_remote_retrieve_body( $response ) ) );
	}
	set_transient( 'cise_gcal_token', $body['access_token'], 50 * MINUTE_IN_SECONDS );
	return $body['access_token'];
}

/**
 * Call the Calendar API.
 *
 * @return array|WP_Error Decoded JSON (empty array for 204).
 */
function cise_gcal_request( $method, $path, $body = null, $query = array() ) {
	$token = cise_gcal_token();
	if ( is_wp_error( $token ) ) {
		return $token;
	}
	$url = 'https://www.googleapis.com/calendar/v3' . $path;
	if ( $query ) {
		$url = add_query_arg( array_map( 'rawurlencode', $query ), $url );
	}
	$args = array(
		'method'  => $method,
		'timeout' => 15,
		'headers' => array(
			'Authorization' => 'Bearer ' . $token,
			'Content-Type'  => 'application/json',
		),
	);
	if ( null !== $body ) {
		$args['body'] = wp_json_encode( $body );
	}
	$response = wp_remote_request( $url, $args );
	if ( is_wp_error( $response ) ) {
		return $response;
	}
	$code = wp_remote_retrieve_response_code( $response );
	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( $code >= 300 ) {
		$msg = isset( $data['error']['message'] ) ? $data['error']['message'] : 'HTTP ' . $code;
		return new WP_Error( 'cise_gcal', $msg, array( 'status' => $code ) );
	}
	return is_array( $data ) ? $data : array();
}

function cise_gcal_calendar_path() {
	return '/calendars/' . rawurlencode( cise_core_get( 'gcal_calendar_id' ) );
}

/**
 * Google event body for a booking.
 */
function cise_gcal_event_body( $booking_id ) {
	$b       = cise_booking_data( $booking_id );
	$tz      = wp_timezone_string();
	$pending = 'pending' === $b['status'];
	$hall    = 'both' === $b['hall'] || '' === $b['hall'] ? __( 'Both halls', 'cise-core' ) : cise_hall_label( $b['hall'] );
	$who     = $b['org_name'] ? $b['org_name'] : $b['name'];
	$summary = ( $pending ? 'PENDING: ' : '' ) . $hall . ' – ' . ( $b['event_type'] ? $b['event_type'] : 'Booked' ) . ( $who ? ' (' . $who . ')' : '' );
	$lines   = array(
		'Name: ' . $b['name'],
		'Email: ' . $b['email'],
		'Phone: ' . $b['phone'],
		'Organization: ' . ( 'member' === $b['org_type'] ? 'Member society' : 'Non-member' ) . ( $b['org_name'] ? ' – ' . $b['org_name'] : '' ),
		'Guests: ' . $b['guests'],
		'Status: ' . ucfirst( $b['status'] ),
		'Estimate: ' . cise_money( $b['estimate'] ),
	);
	if ( $b['notes'] ) {
		$lines[] = 'Notes: ' . $b['notes'];
	}
	$lines[] = 'Manage: ' . admin_url( 'post.php?action=edit&post=' . $booking_id );

	return array(
		'summary'     => $summary,
		'location'    => cise_hall_label( $b['hall'] ) . ', ' . trim( cise_core_get( 'venue_name' ) ),
		'description' => implode( "\n", $lines ),
		'start'       => array( 'dateTime' => $b['date'] . 'T' . $b['start'] . ':00', 'timeZone' => $tz ),
		'end'         => array( 'dateTime' => '24:00' === $b['end'] ? gmdate( 'Y-m-d', strtotime( $b['date'] . ' +1 day' ) ) . 'T00:00:00' : $b['date'] . 'T' . $b['end'] . ':00', 'timeZone' => $tz ),
		'status'      => $pending ? 'tentative' : 'confirmed',
		'colorId'     => $pending ? '5' : '10',
		'extendedProperties' => array( 'private' => array( 'cise_booking' => (string) $booking_id ) ),
	);
}

/**
 * Bring Google in line with a booking's status: create, update or remove its event.
 */
function cise_gcal_sync_booking( $booking_id ) {
	if ( ! cise_gcal_enabled() ) {
		return;
	}
	$status   = get_post_meta( $booking_id, '_status', true );
	$event_id = get_post_meta( $booking_id, '_gcal_id', true );
	$show     = 'confirmed' === $status || ( 'pending' === $status && '1' === (string) cise_core_get( 'gcal_push_pending' ) );
	$path     = cise_gcal_calendar_path() . '/events';

	if ( ! $show || 'publish' !== get_post_status( $booking_id ) ) {
		if ( $event_id ) {
			$res = cise_gcal_request( 'DELETE', $path . '/' . rawurlencode( $event_id ) );
			if ( ! is_wp_error( $res ) || in_array( $res->get_error_data()['status'] ?? 0, array( 404, 410 ), true ) ) {
				delete_post_meta( $booking_id, '_gcal_id' );
			}
		}
		cise_gcal_note( $booking_id, isset( $res ) && is_wp_error( $res ) ? $res : null );
		delete_transient( 'cise_gcal_busy_' . substr( get_post_meta( $booking_id, '_date', true ), 0, 7 ) );
		return;
	}

	$body = cise_gcal_event_body( $booking_id );
	$res  = $event_id
		? cise_gcal_request( 'PUT', $path . '/' . rawurlencode( $event_id ), $body )
		: cise_gcal_request( 'POST', $path, $body );

	if ( is_wp_error( $res ) && $event_id && in_array( $res->get_error_data()['status'] ?? 0, array( 404, 410 ), true ) ) {
		// Someone deleted it in Google: create it again.
		$res = cise_gcal_request( 'POST', $path, $body );
	}
	if ( ! is_wp_error( $res ) && ! empty( $res['id'] ) ) {
		update_post_meta( $booking_id, '_gcal_id', $res['id'] );
	}
	cise_gcal_note( $booking_id, is_wp_error( $res ) ? $res : null );
	delete_transient( 'cise_gcal_busy_' . substr( get_post_meta( $booking_id, '_date', true ), 0, 7 ) );
}

/**
 * Remember the last sync result on the booking (shown in the admin).
 */
function cise_gcal_note( $booking_id, $error ) {
	if ( $error ) {
		update_post_meta( $booking_id, '_gcal_error', $error->get_error_message() );
	} else {
		delete_post_meta( $booking_id, '_gcal_error' );
	}
}

/**
 * Busy intervals from Google for a month, excluding our own booking events.
 *
 * @param string $month YYYY-MM.
 * @return array List of [start_ts, end_ts, hall].
 */
function cise_gcal_busy( $month ) {
	if ( ! cise_gcal_enabled() || '1' !== (string) cise_core_get( 'gcal_read_busy' ) ) {
		return array();
	}
	$cache_key = 'cise_gcal_busy_' . $month;
	$cached    = get_transient( $cache_key );
	if ( false !== $cached ) {
		return $cached;
	}
	$tz    = wp_timezone();
	$start = new DateTime( $month . '-01 00:00:00', $tz );
	$end   = ( clone $start )->modify( '+1 month' );
	$busy  = array();
	$page  = '';

	do {
		$query = array(
			'timeMin'      => $start->format( DATE_RFC3339 ),
			'timeMax'      => $end->format( DATE_RFC3339 ),
			'singleEvents' => 'true',
			'maxResults'   => '250',
		);
		if ( $page ) {
			$query['pageToken'] = $page;
		}
		$res = cise_gcal_request( 'GET', cise_gcal_calendar_path() . '/events', null, $query );
		if ( is_wp_error( $res ) ) {
			// Don't hammer Google on errors; the website still blocks its own bookings.
			set_transient( $cache_key, $busy, 2 * MINUTE_IN_SECONDS );
			return $busy;
		}
		foreach ( (array) ( $res['items'] ?? array() ) as $item ) {
			if ( 'cancelled' === ( $item['status'] ?? '' ) || 'transparent' === ( $item['transparency'] ?? '' ) ) {
				continue;
			}
			if ( ! empty( $item['extendedProperties']['private']['cise_booking'] ) ) {
				continue; // Our own booking; already counted from the database.
			}
			$hall = cise_gcal_guess_hall( ( $item['summary'] ?? '' ) . ' ' . ( $item['location'] ?? '' ) );
			if ( ! empty( $item['start']['dateTime'] ) ) {
				$busy[] = array( strtotime( $item['start']['dateTime'] ), strtotime( $item['end']['dateTime'] ), $hall );
			} elseif ( ! empty( $item['start']['date'] ) ) {
				// All-day event blocks the whole day(s).
				$s      = new DateTime( $item['start']['date'] . ' 00:00:00', $tz );
				$e      = new DateTime( $item['end']['date'] . ' 00:00:00', $tz );
				$busy[] = array( $s->getTimestamp(), $e->getTimestamp(), $hall );
			}
		}
		$page = $res['nextPageToken'] ?? '';
	} while ( $page );

	set_transient( $cache_key, $busy, 5 * MINUTE_IN_SECONDS );
	return $busy;
}

/**
 * Which hall a Google Calendar event blocks: an event naming only one hall in its
 * title or location blocks just that hall; anything else blocks both.
 */
function cise_gcal_guess_hall( $text ) {
	$text = strtolower( $text );
	$main = false !== strpos( $text, strtolower( cise_core_get( 'main_name' ) ) );
	$base = false !== strpos( $text, strtolower( cise_core_get( 'base_name' ) ) );
	if ( $main xor $base ) {
		return $main ? 'main' : 'basement';
	}
	return 'both';
}

/**
 * Settings-page connection test.
 *
 * @return string|WP_Error
 */
function cise_gcal_test() {
	if ( ! function_exists( 'openssl_sign' ) ) {
		return new WP_Error( 'cise_gcal', __( 'This server is missing the PHP OpenSSL extension. Ask your host to enable it.', 'cise-core' ) );
	}
	if ( ! cise_gcal_key() ) {
		return new WP_Error( 'cise_gcal', __( 'Paste the service account key first.', 'cise-core' ) );
	}
	if ( ! cise_core_get( 'gcal_calendar_id' ) ) {
		return new WP_Error( 'cise_gcal', __( 'Enter the Calendar ID first.', 'cise-core' ) );
	}
	delete_transient( 'cise_gcal_token' );
	$res = cise_gcal_request( 'GET', cise_gcal_calendar_path() );
	if ( is_wp_error( $res ) ) {
		$key = cise_gcal_key();
		/* translators: 1: error, 2: service account email */
		return new WP_Error( 'cise_gcal', sprintf( __( 'Could not open the calendar (%1$s). Make sure it is shared with %2$s with "Make changes to events".', 'cise-core' ), rtrim( $res->get_error_message(), '.' ), $key['client_email'] ) );
	}
	/* translators: %s: calendar name */
	return sprintf( __( 'Connected to "%s". Bookings will sync.', 'cise-core' ), $res['summary'] ?? cise_core_get( 'gcal_calendar_id' ) );
}
