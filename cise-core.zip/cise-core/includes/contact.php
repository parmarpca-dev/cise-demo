<?php
/**
 * Contact form (emails the CISE office; nothing is stored).
 *
 * @package cise-core
 */

defined( 'ABSPATH' ) || exit;

function cise_core_contact_form() {
	wp_enqueue_style( 'cise-core' );
	// phpcs:disable WordPress.Security.NonceVerification
	if ( isset( $_GET['sent'] ) ) {
		cise_core_notice( __( 'Thanks! Your message is on its way. We will reply by email.', 'cise-core' ), 'info' );
		return;
	}
	if ( isset( $_GET['contact_err'] ) ) {
		cise_core_notice( __( 'Please fill in your name, a valid email and a message.', 'cise-core' ), 'warn' );
	}
	// phpcs:enable
	?>
	<form class="cise-contact cb-step" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="cise_contact">
		<input type="hidden" name="return" value="<?php echo esc_url( get_permalink() ); ?>">
		<input type="hidden" name="started" value="<?php echo esc_attr( time() ); ?>">
		<?php wp_nonce_field( 'cise_contact', 'cise_contact_nonce' ); ?>
		<h2><?php esc_html_e( 'Send us a message', 'cise-core' ); ?></h2>
		<div class="cb-row">
			<label><?php esc_html_e( 'Name', 'cise-core' ); ?><input name="name" autocomplete="name" required></label>
			<label><?php esc_html_e( 'Email', 'cise-core' ); ?><input type="email" name="email" autocomplete="email" required></label>
		</div>
		<label class="cb-full"><?php esc_html_e( 'Subject', 'cise-core' ); ?><input name="subject"></label>
		<label class="cb-full"><?php esc_html_e( 'Message', 'cise-core' ); ?><textarea name="message" rows="6" required></textarea></label>
		<label class="cb-hp" aria-hidden="true">Website<input name="website" tabindex="-1" autocomplete="off"></label>
		<button type="submit" class="btn btn--primary"><?php esc_html_e( 'Send message', 'cise-core' ); ?></button>
	</form>
	<?php
}

add_shortcode( 'cise_contact_form', function () {
	ob_start();
	cise_core_contact_form();
	return ob_get_clean();
} );

add_action( 'admin_post_nopriv_cise_contact', 'cise_contact_handle' );
add_action( 'admin_post_cise_contact', 'cise_contact_handle' );

function cise_contact_handle() {
	$return = wp_validate_redirect( isset( $_POST['return'] ) ? esc_url_raw( wp_unslash( $_POST['return'] ) ) : '', home_url( '/' ) );
	if ( ! isset( $_POST['cise_contact_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['cise_contact_nonce'] ), 'cise_contact' ) ) {
		wp_die( esc_html__( 'This form expired. Please go back, refresh the page and try again.', 'cise-core' ), '', array( 'back_link' => true ) );
	}
	// Bots: pretend it worked.
	if ( ! empty( $_POST['website'] ) || ( time() - absint( $_POST['started'] ?? 0 ) ) < 4 ) {
		wp_safe_redirect( add_query_arg( 'sent', 1, $return ) );
		exit;
	}
	$name    = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
	$email   = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$subject = sanitize_text_field( wp_unslash( $_POST['subject'] ?? '' ) );
	$message = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) );

	if ( '' === $name || ! is_email( $email ) || '' === $message ) {
		wp_safe_redirect( add_query_arg( 'contact_err', 1, $return ) );
		exit;
	}
	if ( ! cise_rate_limit( 'contact', 5 ) ) {
		wp_die( esc_html__( 'Too many messages from your connection. Please email us directly.', 'cise-core' ), '', array( 'back_link' => true ) );
	}

	cise_core_mail(
		cise_core_staff_email(),
		/* translators: %s: subject */
		sprintf( __( 'Website message: %s', 'cise-core' ), $subject ? $subject : $name ),
		__( 'New message from the website contact form. Reply to this email to answer.', 'cise-core' ),
		array(
			__( 'Name', 'cise-core' )    => $name,
			__( 'Email', 'cise-core' )   => $email,
			__( 'Subject', 'cise-core' ) => $subject,
			__( 'Message', 'cise-core' ) => $message,
		),
		array( 'reply_to' => $email )
	);

	wp_safe_redirect( add_query_arg( 'sent', 1, $return ) );
	exit;
}
