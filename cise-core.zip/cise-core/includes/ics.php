<?php
/**
 * iCalendar feeds: public events, and a private hall bookings feed for staff.
 *
 * Subscribing to the bookings feed in Google Calendar is the no-setup way to see
 * bookings there (Google refreshes it every few hours). For instant two-way sync
 * use the service account in gcal.php.
 *
 * @package cise-core
 */

defined( 'ABSPATH' ) || exit;

function cise_core_ics_url( $feed ) {
	$args = array( 'cise_ics' => $feed );
	if ( 'bookings' === $feed ) {
		$args['key'] = get_option( 'cise_core_ics_key' );
	}
	return add_query_arg( $args, home_url( '/' ) );
}

function cise_ics_escape( $text ) {
	return str_replace( array( '\\', ';', ',', "\r\n", "\n" ), array( '\\\\', '\\;', '\\,', '\\n', '\\n' ), (string) $text );
}

/**
 * Fold lines at 75 octets as RFC 5545 asks.
 */
function cise_ics_line( $line ) {
	$out = '';
	while ( strlen( $line ) > 75 ) {
		$cut = 75;
		// Don't split a multibyte character.
		while ( $cut > 0 && ( ord( $line[ $cut ] ) & 0xC0 ) === 0x80 ) {
			$cut--;
		}
		$out .= substr( $line, 0, $cut ) . "\r\n ";
		$line = substr( $line, $cut );
	}
	return $out . $line . "\r\n";
}

add_action( 'template_redirect', function () {
	// phpcs:disable WordPress.Security.NonceVerification
	if ( empty( $_GET['cise_ics'] ) ) {
		return;
	}
	$feed = sanitize_key( $_GET['cise_ics'] );
	if ( 'bookings' === $feed ) {
		$key = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
		if ( ! $key || ! hash_equals( (string) get_option( 'cise_core_ics_key' ), $key ) ) {
			status_header( 403 );
			exit;
		}
	} elseif ( 'events' !== $feed ) {
		return;
	}
	// phpcs:enable

	$tzid  = wp_timezone_string();
	$host  = wp_parse_url( home_url(), PHP_URL_HOST );
	$stamp = gmdate( 'Ymd\THis\Z' );
	$lines = array(
		'BEGIN:VCALENDAR',
		'VERSION:2.0',
		'PRODID:-//CISE//Website//EN',
		'CALSCALE:GREGORIAN',
		'X-WR-CALNAME:' . ( 'bookings' === $feed ? 'CISE hall bookings' : 'CISE events' ),
		'X-WR-TIMEZONE:' . $tzid,
		'REFRESH-INTERVAL;VALUE=DURATION:PT1H',
	);

	if ( 'events' === $feed ) {
		$posts = get_posts( array(
			'post_type'      => 'cise_event',
			'posts_per_page' => 200,
			'meta_key'       => '_cise_event_date',
			'orderby'        => 'meta_value',
			'order'          => 'DESC',
		) );
		foreach ( $posts as $p ) {
			$date = get_post_meta( $p->ID, '_cise_event_date', true );
			if ( ! $date || get_post_meta( $p->ID, '_cise_event_tbc', true ) ) {
				continue;
			}
			$time    = get_post_meta( $p->ID, '_cise_event_time', true );
			$lines[] = 'BEGIN:VEVENT';
			$lines[] = 'UID:event-' . $p->ID . '@' . $host;
			$lines[] = 'DTSTAMP:' . $stamp;
			$lines[] = 'DTSTART;VALUE=DATE:' . str_replace( '-', '', $date );
			$lines[] = 'DTEND;VALUE=DATE:' . gmdate( 'Ymd', strtotime( $date . ' +1 day' ) );
			$lines[] = 'SUMMARY:' . cise_ics_escape( get_the_title( $p ) );
			$lines[] = 'DESCRIPTION:' . cise_ics_escape( trim( ( $time ? $time . "\n" : '' ) . wp_strip_all_tags( $p->post_excerpt ) . "\n" . get_permalink( $p ) ) );
			$lines[] = 'LOCATION:' . cise_ics_escape( get_post_meta( $p->ID, '_cise_event_location', true ) );
			$lines[] = 'URL:' . get_permalink( $p );
			$lines[] = 'END:VEVENT';
		}
	} else {
		$ids = get_posts( array(
			'post_type'      => 'cise_booking',
			'post_status'    => 'publish',
			'posts_per_page' => 500,
			'fields'         => 'ids',
			'meta_query'     => array(
				array(
					'key'     => '_status',
					'value'   => CISE_BOOKING_HOLDING,
					'compare' => 'IN',
				),
				array(
					'key'     => '_date',
					'value'   => wp_date( 'Y-m-d', strtotime( '-60 days' ) ),
					'compare' => '>=',
				),
			),
		) );
		foreach ( $ids as $id ) {
			$b       = cise_booking_data( $id );
			$day     = str_replace( '-', '', $b['date'] );
			$end     = '24:00' === $b['end'] ? gmdate( 'Ymd', strtotime( $b['date'] . ' +1 day' ) ) . 'T000000' : $day . 'T' . str_replace( ':', '', $b['end'] ) . '00';
			$who     = $b['org_name'] ? $b['org_name'] : $b['name'];
			$lines[] = 'BEGIN:VEVENT';
			$lines[] = 'UID:booking-' . $id . '@' . $host;
			$lines[] = 'DTSTAMP:' . $stamp;
			$lines[] = 'DTSTART;TZID=' . $tzid . ':' . $day . 'T' . str_replace( ':', '', $b['start'] ) . '00';
			$lines[] = 'DTEND;TZID=' . $tzid . ':' . $end;
			$hall    = 'both' === $b['hall'] || '' === $b['hall'] ? __( 'Both halls', 'cise-core' ) : cise_hall_label( $b['hall'] );
			$lines[] = 'SUMMARY:' . cise_ics_escape( ( 'pending' === $b['status'] ? 'PENDING: ' : '' ) . $hall . ' – ' . ( $b['event_type'] ? $b['event_type'] : 'Booked' ) . ( $who ? ' (' . $who . ')' : '' ) );
			$lines[] = 'LOCATION:' . cise_ics_escape( cise_hall_label( $b['hall'] ) . ', ' . cise_core_get( 'venue_name' ) );
			$lines[] = 'DESCRIPTION:' . cise_ics_escape( implode( "\n", array_filter( array( $b['name'], $b['email'], $b['phone'], $b['guests'] ? $b['guests'] . ' guests' : '', $b['notes'], admin_url( 'post.php?action=edit&post=' . $id ) ) ) ) );
			$lines[] = 'STATUS:' . ( 'pending' === $b['status'] ? 'TENTATIVE' : 'CONFIRMED' );
			$lines[] = 'END:VEVENT';
		}
	}
	$lines[] = 'END:VCALENDAR';

	nocache_headers();
	header( 'Content-Type: text/calendar; charset=utf-8' );
	header( 'Content-Disposition: inline; filename="cise-' . $feed . '.ics"' );
	foreach ( $lines as $line ) {
		echo cise_ics_line( $line ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
	exit;
} );
