<?php
/**
 * Email helpers: simple branded HTML emails through wp_mail().
 *
 * @package cise-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Send an email.
 *
 * @param string|array $to       Recipient(s).
 * @param string       $subject  Subject.
 * @param string       $intro    Opening paragraph (plain text, may contain line breaks).
 * @param array        $rows     Label => value table (plain text values).
 * @param array        $opts     reply_to, button_url, button_label, outro, attachments.
 */
function cise_core_mail( $to, $subject, $intro, $rows = array(), $opts = array() ) {
	$opts = wp_parse_args( $opts, array(
		'reply_to'     => '',
		'button_url'   => '',
		'button_label' => '',
		'outro'        => '',
		'attachments'  => array(),
	) );

	$table = '';
	foreach ( $rows as $label => $value ) {
		if ( '' === (string) $value ) {
			continue;
		}
		$table .= '<tr><td style="padding:7px 12px 7px 0;color:#77807b;vertical-align:top;white-space:nowrap">' . esc_html( $label ) . '</td><td style="padding:7px 0;color:#1b1d1c">' . nl2br( esc_html( $value ) ) . '</td></tr>';
	}

	$button = '';
	if ( $opts['button_url'] ) {
		$button = '<p style="margin:24px 0"><a href="' . esc_url( $opts['button_url'] ) . '" style="background:#0e4a37;color:#fff;padding:12px 22px;border-radius:999px;text-decoration:none;font-weight:bold">' . esc_html( $opts['button_label'] ) . '</a></p>';
	}

	$body = '<div style="background:#f4efe7;padding:28px 12px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.55">'
		. '<div style="max-width:600px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden">'
		. '<div style="background:#0a3a2c;color:#fff;padding:18px 24px;font-weight:bold;font-size:17px">CISE <span style="font-weight:normal;opacity:.8;font-size:13px">Council of India Societies of Edmonton</span></div>'
		. '<div style="padding:24px">'
		. '<p style="margin:0 0 16px">' . nl2br( esc_html( $intro ) ) . '</p>'
		. ( $table ? '<table style="border-collapse:collapse;width:100%;font-size:14px;border-top:1px solid #e6e1d8">' . $table . '</table>' : '' )
		. $button
		. ( $opts['outro'] ? '<p style="margin:16px 0 0;color:#4a4f4c">' . nl2br( esc_html( $opts['outro'] ) ) . '</p>' : '' )
		. '</div></div></div>';

	$headers = array( 'Content-Type: text/html; charset=UTF-8' );
	if ( $opts['reply_to'] && is_email( $opts['reply_to'] ) ) {
		$headers[] = 'Reply-To: ' . $opts['reply_to'];
	}

	return wp_mail( $to, $subject, $body, $headers, $opts['attachments'] );
}

/**
 * Public contact address: the theme's email setting, else the first staff address.
 */
function cise_core_public_email() {
	if ( function_exists( 'cise_mod' ) && cise_mod( 'email' ) ) {
		return cise_mod( 'email' );
	}
	return trim( explode( ',', cise_core_staff_email() )[0] );
}

/**
 * Staff notification address(es).
 */
function cise_core_staff_email() {
	$to = cise_core_get( 'notify_email' );
	return $to ? $to : get_option( 'admin_email' );
}
