<?php
/**
 * Hall bookings admin: list columns, quick confirm/decline, edit screen.
 *
 * @package cise-core
 */

defined( 'ABSPATH' ) || exit;

/* ---------- List table ---------- */

add_filter( 'manage_cise_booking_posts_columns', function () {
	return array(
		'cb'         => '<input type="checkbox">',
		'title'      => __( 'Booking', 'cise-core' ),
		'cise_when'  => __( 'When', 'cise-core' ),
		'cise_who'   => __( 'Contact', 'cise-core' ),
		'cise_event' => __( 'Event', 'cise-core' ),
		'cise_est'   => __( 'Estimate', 'cise-core' ),
		'cise_stat'  => __( 'Status', 'cise-core' ),
	);
} );

add_action( 'manage_cise_booking_posts_custom_column', function ( $col, $id ) {
	$b = cise_booking_data( $id );
	switch ( $col ) {
		case 'cise_when':
			if ( $b['date'] ) {
				echo esc_html( date_i18n( 'D, M j, Y', strtotime( $b['date'] ) ) ) . '<br>' . esc_html( cise_time_label( cise_min( $b['start'] ) ) . ' – ' . cise_time_label( cise_min( $b['end'] ) ) );
				echo '<br><small>' . esc_html( cise_hall_label( $b['hall'] ) ) . '</small>';
			}
			break;
		case 'cise_who':
			echo esc_html( $b['name'] ) . '<br><a href="mailto:' . esc_attr( $b['email'] ) . '">' . esc_html( $b['email'] ) . '</a><br>' . esc_html( $b['phone'] );
			break;
		case 'cise_event':
			echo esc_html( $b['event_type'] ) . ( $b['guests'] ? '<br>' . esc_html( $b['guests'] . ' ' . __( 'guests', 'cise-core' ) ) : '' );
			echo '<br><small>' . esc_html( ( 'member' === $b['org_type'] ? __( 'Member', 'cise-core' ) : __( 'Non-member', 'cise-core' ) ) . ( $b['org_name'] ? ': ' . $b['org_name'] : '' ) ) . '</small>';
			break;
		case 'cise_est':
			echo esc_html( cise_money( $b['estimate'] ) );
			break;
		case 'cise_stat':
			$colors = array(
				'pending'   => '#b26a00',
				'confirmed' => '#0e7a4f',
				'declined'  => '#a00',
				'cancelled' => '#777',
			);
			$labels = cise_booking_statuses();
			printf( '<strong style="color:%s">%s</strong>', esc_attr( $colors[ $b['status'] ] ?? '#333' ), esc_html( $labels[ $b['status'] ] ?? $b['status'] ) );
			if ( 'pending' === $b['status'] ) {
				foreach ( array( 'confirmed' => __( 'Confirm', 'cise-core' ), 'declined' => __( 'Decline', 'cise-core' ) ) as $to => $label ) {
					$url = wp_nonce_url( admin_url( 'admin-post.php?action=cise_booking_status&id=' . $id . '&to=' . $to ), 'cise_booking_status_' . $id );
					printf( '<br><a href="%s">%s</a>', esc_url( $url ), esc_html( $label ) );
				}
			}
			if ( get_post_meta( $id, '_gcal_error', true ) ) {
				echo '<br><small style="color:#a00">' . esc_html__( 'Google sync failed', 'cise-core' ) . '</small>';
			} elseif ( get_post_meta( $id, '_gcal_id', true ) ) {
				echo '<br><small style="color:#777">' . esc_html__( 'In Google Calendar', 'cise-core' ) . '</small>';
			}
			break;
	}
}, 10, 2 );

add_filter( 'manage_edit-cise_booking_sortable_columns', function ( $cols ) {
	$cols['cise_when'] = 'cise_when';
	return $cols;
} );

/* Sort by event date (newest upcoming first by default) and filter by status. */
add_action( 'pre_get_posts', function ( WP_Query $q ) {
	if ( ! is_admin() || ! $q->is_main_query() || 'cise_booking' !== $q->get( 'post_type' ) ) {
		return;
	}
	$orderby = $q->get( 'orderby' );
	if ( ! $orderby || 'cise_when' === $orderby ) {
		$q->set( 'meta_key', '_date' );
		$q->set( 'orderby', 'meta_value' );
		if ( ! $q->get( 'order' ) || ! isset( $_GET['order'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$q->set( 'order', 'DESC' );
		}
	}
	$status = isset( $_GET['cise_status'] ) ? sanitize_key( $_GET['cise_status'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	if ( $status && isset( cise_booking_statuses()[ $status ] ) ) {
		$q->set( 'meta_query', array(
			array(
				'key'   => '_status',
				'value' => $status,
			),
		) );
	}
} );

add_action( 'restrict_manage_posts', function ( $type ) {
	if ( 'cise_booking' !== $type ) {
		return;
	}
	$current = isset( $_GET['cise_status'] ) ? sanitize_key( $_GET['cise_status'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	echo '<select name="cise_status"><option value="">' . esc_html__( 'All statuses', 'cise-core' ) . '</option>';
	foreach ( cise_booking_statuses() as $k => $label ) {
		printf( '<option value="%s" %s>%s</option>', esc_attr( $k ), selected( $current, $k, false ), esc_html( $label ) );
	}
	echo '</select>';
} );

/* Pending count bubble on the menu. */
add_action( 'admin_menu', function () {
	global $submenu;
	if ( empty( $submenu['cise'] ) ) {
		return;
	}
	$pending = count( get_posts( array(
		'post_type'      => 'cise_booking',
		'posts_per_page' => 99,
		'fields'         => 'ids',
		'meta_key'       => '_status',
		'meta_value'     => 'pending',
	) ) );
	if ( ! $pending ) {
		return;
	}
	foreach ( $submenu['cise'] as $i => $item ) {
		if ( 'edit.php?post_type=cise_booking' === $item[2] ) {
			$submenu['cise'][ $i ][0] .= ' <span class="awaiting-mod">' . (int) $pending . '</span>'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		}
	}
}, 99 );

/* ---------- Quick status change ---------- */

add_action( 'admin_post_cise_booking_status', function () {
	$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
	$to = isset( $_GET['to'] ) ? sanitize_key( $_GET['to'] ) : '';
	check_admin_referer( 'cise_booking_status_' . $id );
	if ( ! current_user_can( CISE_CORE_CAP ) || 'cise_booking' !== get_post_type( $id ) || ! isset( cise_booking_statuses()[ $to ] ) ) {
		wp_die( esc_html__( 'Not allowed.', 'cise-core' ) );
	}
	cise_booking_set_status( $id, $to, true );
	wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url( 'edit.php?post_type=cise_booking' ) );
	exit;
} );

/**
 * Change status, email the customer (optional) and sync Google.
 */
function cise_booking_set_status( $id, $to, $email ) {
	$from = get_post_meta( $id, '_status', true );
	update_post_meta( $id, '_status', $to );
	if ( $from !== $to && $email && 'pending' !== $to && get_post_meta( $id, '_email', true ) ) {
		cise_booking_notify( $id, $to );
	}
	cise_gcal_sync_booking( $id );
}

/* Keep Google in step when a booking is trashed, restored or deleted. */
add_action( 'trashed_post', function ( $id ) {
	if ( 'cise_booking' === get_post_type( $id ) ) {
		cise_gcal_sync_booking( $id );
	}
} );
add_action( 'untrashed_post', function ( $id ) {
	if ( 'cise_booking' === get_post_type( $id ) ) {
		// WordPress restores to draft; bookings live as published posts.
		wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ) );
		cise_gcal_sync_booking( $id );
	}
} );
add_action( 'before_delete_post', function ( $id ) {
	if ( 'cise_booking' === get_post_type( $id ) && get_post_meta( $id, '_gcal_id', true ) && cise_gcal_enabled() ) {
		cise_gcal_request( 'DELETE', cise_gcal_calendar_path() . '/events/' . rawurlencode( get_post_meta( $id, '_gcal_id', true ) ) );
	}
} );

/* ---------- Edit screen ---------- */

add_action( 'add_meta_boxes_cise_booking', function () {
	remove_meta_box( 'submitdiv', 'cise_booking', 'side' );
	add_meta_box( 'cise_booking_main', __( 'Booking details', 'cise-core' ), 'cise_booking_box', 'cise_booking', 'normal', 'high' );
	add_meta_box( 'cise_booking_status', __( 'Status', 'cise-core' ), 'cise_booking_status_box', 'cise_booking', 'side', 'high' );
} );

/* The title is generated from the date and name. */
add_action( 'admin_head-post.php', 'cise_booking_hide_title' );
add_action( 'admin_head-post-new.php', 'cise_booking_hide_title' );
function cise_booking_hide_title() {
	if ( 'cise_booking' === get_current_screen()->post_type ) {
		echo '<style>#titlediv{display:none}.cise-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px 20px}.cise-grid label{display:block;font-weight:600}.cise-grid input,.cise-grid select,.cise-grid textarea{width:100%;font-weight:normal;margin-top:4px}.cise-grid .full{grid-column:1/-1}</style>';
	}
}

function cise_booking_box( $post ) {
	wp_nonce_field( 'cise_booking_save', 'cise_booking_nonce' );
	$b     = cise_booking_data( $post->ID );
	$types = cise_core_lines( 'event_types' );
	$times = function ( $name, $value ) {
		echo '<select name="cise_b[' . esc_attr( $name ) . ']">';
		for ( $m = 0; $m <= 1440; $m += 30 ) {
			$hm = 1440 === $m ? '24:00' : cise_hhmm( $m );
			printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $hm ), selected( $value, $hm, false ), esc_html( 1440 === $m ? __( 'Midnight', 'cise-core' ) : cise_time_label( $m ) ) );
		}
		echo '</select>';
	};
	if ( ! $post->post_title || 'auto-draft' === $post->post_status ) {
		echo '<p>' . esc_html__( 'Use this to add a booking taken by phone, or to block off time (e.g. maintenance). Leave the contact fields blank to just block the time.', 'cise-core' ) . '</p>';
	}
	if ( get_post_meta( $post->ID, '_ref', true ) ) {
		/* translators: %s: reference */
		echo '<p>' . esc_html( sprintf( __( 'Reference: %s', 'cise-core' ), get_post_meta( $post->ID, '_ref', true ) ) ) . '</p>';
	}
	?>
	<div class="cise-grid">
		<label><?php esc_html_e( 'Date', 'cise-core' ); ?><input type="date" name="cise_b[date]" value="<?php echo esc_attr( $b['date'] ); ?>" required></label>
		<div class="cise-grid" style="gap:12px">
			<label><?php esc_html_e( 'Start', 'cise-core' ); ?><?php $times( 'start', $b['start'] ? $b['start'] : cise_core_get( 'open_time' ) ); ?></label>
			<label><?php esc_html_e( 'End', 'cise-core' ); ?><?php $times( 'end', $b['end'] ? $b['end'] : cise_hhmm( cise_close_min() ) ); ?></label>
		</div>
		<label><?php esc_html_e( 'Hall', 'cise-core' ); ?>
			<select name="cise_b[hall]">
				<?php foreach ( cise_halls() as $key => $label ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $b['hall'] ? $b['hall'] : 'both', $key ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<label><?php esc_html_e( 'Name', 'cise-core' ); ?><input name="cise_b[name]" value="<?php echo esc_attr( $b['name'] ); ?>"></label>
		<label><?php esc_html_e( 'Email', 'cise-core' ); ?><input type="email" name="cise_b[email]" value="<?php echo esc_attr( $b['email'] ); ?>"></label>
		<label><?php esc_html_e( 'Phone', 'cise-core' ); ?><input name="cise_b[phone]" value="<?php echo esc_attr( $b['phone'] ); ?>"></label>
		<label><?php esc_html_e( 'Organization type', 'cise-core' ); ?>
			<select name="cise_b[org_type]">
				<option value="member" <?php selected( $b['org_type'], 'member' ); ?>><?php esc_html_e( 'Member society', 'cise-core' ); ?></option>
				<option value="nonmember" <?php selected( $b['org_type'], 'nonmember' ); ?>><?php esc_html_e( 'Non-member', 'cise-core' ); ?></option>
			</select>
		</label>
		<label><?php esc_html_e( 'Organization name', 'cise-core' ); ?><input name="cise_b[org_name]" value="<?php echo esc_attr( $b['org_name'] ); ?>"></label>
		<label><?php esc_html_e( 'Event type', 'cise-core' ); ?>
			<input name="cise_b[event_type]" list="cise-types" value="<?php echo esc_attr( $b['event_type'] ); ?>">
			<datalist id="cise-types"><?php foreach ( $types as $t ) : ?><option value="<?php echo esc_attr( $t ); ?>"><?php endforeach; ?></datalist>
		</label>
		<label><?php esc_html_e( 'Guests', 'cise-core' ); ?><input type="number" name="cise_b[guests]" value="<?php echo esc_attr( $b['guests'] ); ?>"></label>
		<label><?php esc_html_e( 'Estimated rental ($)', 'cise-core' ); ?><input name="cise_b[estimate]" value="<?php echo esc_attr( $b['estimate'] ); ?>" placeholder="<?php esc_attr_e( 'Blank = calculate from rates', 'cise-core' ); ?>"></label>
		<label class="full"><?php esc_html_e( "Customer's notes", 'cise-core' ); ?><textarea name="cise_b[notes]" rows="3"><?php echo esc_textarea( $b['notes'] ); ?></textarea></label>
		<label class="full"><?php esc_html_e( 'Message to customer (added to the next status email)', 'cise-core' ); ?><textarea name="cise_b[staff_note]" rows="2"><?php echo esc_textarea( $b['staff_note'] ); ?></textarea></label>
	</div>
	<?php
}

function cise_booking_status_box( $post ) {
	$status = get_post_meta( $post->ID, '_status', true );
	$status = $status ? $status : 'confirmed';
	$err    = get_post_meta( $post->ID, '_gcal_error', true );
	?>
	<p><select name="cise_b[status]" style="width:100%">
		<?php foreach ( cise_booking_statuses() as $k => $label ) : ?>
			<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $status, $k ); ?>><?php echo esc_html( $label ); ?></option>
		<?php endforeach; ?>
	</select></p>
	<p><label><input type="checkbox" name="cise_b[notify]" value="1" checked> <?php esc_html_e( 'Email the customer if the status changes', 'cise-core' ); ?></label></p>
	<?php if ( cise_gcal_enabled() ) : ?>
		<p style="color:<?php echo $err ? '#a00' : '#666'; ?>">
			<?php
			if ( $err ) {
				/* translators: %s: error */
				echo esc_html( sprintf( __( 'Google Calendar sync failed: %s. Saving again retries.', 'cise-core' ), $err ) );
			} elseif ( get_post_meta( $post->ID, '_gcal_id', true ) ) {
				esc_html_e( 'Synced to Google Calendar.', 'cise-core' );
			} else {
				esc_html_e( 'Syncs to Google Calendar when saved.', 'cise-core' );
			}
			?>
		</p>
	<?php endif; ?>
	<?php submit_button( __( 'Save booking', 'cise-core' ), 'primary large', 'save', false, array( 'style' => 'width:100%' ) ); ?>
	<?php if ( 'auto-draft' !== $post->post_status ) : ?>
		<p style="margin-top:12px"><a class="submitdelete" style="color:#a00" href="<?php echo esc_url( get_delete_post_link( $post->ID ) ); ?>"><?php esc_html_e( 'Move to trash', 'cise-core' ); ?></a></p>
	<?php endif; ?>
	<input type="hidden" name="post_status" value="publish">
	<?php
}

add_action( 'save_post_cise_booking', function ( $id ) {
	static $saving = false;
	if ( $saving ) {
		return; // Our own wp_update_post() below.
	}
	if ( ! isset( $_POST['cise_booking_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['cise_booking_nonce'] ), 'cise_booking_save' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( CISE_CORE_CAP ) ) {
		return;
	}
	$in   = isset( $_POST['cise_b'] ) ? wp_unslash( $_POST['cise_b'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$old  = cise_booking_data( $id );
	$data = array(
		'date'       => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $in['date'] ?? '' ) ? $in['date'] : $old['date'],
		'start'      => preg_match( '/^\d{2}:\d{2}$/', $in['start'] ?? '' ) ? $in['start'] : $old['start'],
		'end'        => preg_match( '/^\d{2}:\d{2}$/', $in['end'] ?? '' ) ? $in['end'] : $old['end'],
		'hall'       => isset( cise_halls()[ $in['hall'] ?? '' ] ) ? $in['hall'] : 'both',
		'name'       => sanitize_text_field( $in['name'] ?? '' ),
		'email'      => sanitize_email( $in['email'] ?? '' ),
		'phone'      => sanitize_text_field( $in['phone'] ?? '' ),
		'org_type'   => 'member' === ( $in['org_type'] ?? '' ) ? 'member' : 'nonmember',
		'org_name'   => sanitize_text_field( $in['org_name'] ?? '' ),
		'event_type' => sanitize_text_field( $in['event_type'] ?? '' ),
		'guests'     => (string) absint( $in['guests'] ?? 0 ),
		'notes'      => sanitize_textarea_field( $in['notes'] ?? '' ),
		'staff_note' => sanitize_textarea_field( $in['staff_note'] ?? '' ),
	);
	$est              = trim( (string) ( $in['estimate'] ?? '' ) );
	$data['estimate'] = '' === $est ? (string) cise_booking_estimate( $data['hall'], cise_min( $data['start'] ), cise_min( $data['end'] ) ) : (string) round( (float) preg_replace( '/[^0-9.]/', '', $est ), 2 );

	foreach ( $data as $k => $v ) {
		update_post_meta( $id, '_' . $k, $v );
	}
	if ( ! get_post_meta( $id, '_ref', true ) ) {
		update_post_meta( $id, '_ref', strtoupper( wp_generate_password( 6, false ) ) );
	}

	// Title + published status.
	$saving = true;
	wp_update_post( array(
		'ID'          => $id,
		'post_title'  => cise_booking_title( $data ),
		'post_status' => 'publish',
	) );
	$saving = false;

	// Warn about overlaps (staff may still save on purpose).
	$status = isset( cise_booking_statuses()[ $in['status'] ?? '' ] ) ? $in['status'] : 'confirmed';
	if ( in_array( $status, CISE_BOOKING_HOLDING, true ) && $data['date'] ) {
		$busy = cise_booking_busy( substr( $data['date'], 0, 7 ), $data['hall'], $id );
		$s    = cise_min( $data['start'] );
		$e    = cise_min( $data['end'] );
		foreach ( $busy[ $data['date'] ] ?? array() as $r ) {
			if ( $s < $r[1] && $e > $r[0] ) {
				set_transient( 'cise_booking_overlap_' . get_current_user_id(), $id, 60 );
				break;
			}
		}
	}

	cise_booking_set_status( $id, $status, ! empty( $in['notify'] ) );
} );

add_action( 'admin_notices', function () {
	$id = get_transient( 'cise_booking_overlap_' . get_current_user_id() );
	if ( $id ) {
		delete_transient( 'cise_booking_overlap_' . get_current_user_id() );
		echo '<div class="notice notice-warning"><p>' . esc_html__( 'Heads up: this booking overlaps another booking, a Google Calendar event, or the cleanup gap between bookings.', 'cise-core' ) . '</p></div>';
	}
} );

/* Remove "Published" wording from row actions; bookings have their own status. */
add_filter( 'display_post_states', function ( $states, $post ) {
	return in_array( $post->post_type, array( 'cise_booking', 'cise_nomination' ), true ) ? array() : $states;
}, 10, 2 );

add_filter( 'post_row_actions', function ( $actions, $post ) {
	if ( 'cise_booking' === $post->post_type || 'cise_nomination' === $post->post_type ) {
		unset( $actions['inline hide-if-no-js'], $actions['view'] );
	}
	return $actions;
}, 10, 2 );
