<?php
/**
 * Settings (CISE > Settings): hall rates and hours, award dates, Google Calendar, Gmail.
 *
 * @package cise-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Field definitions grouped by tab: key => [label, type, default, help].
 */
function cise_core_fields() {
	return array(
		'general' => array(
			'title'  => __( 'General', 'cise-core' ),
			'fields' => array(
				'notify_email'        => array( __( 'Send notifications to', 'cise-core' ), 'email', get_option( 'admin_email' ), __( 'Booking requests, nominations and contact messages go here. Separate several addresses with commas.', 'cise-core' ) ),
				'yearly_celebrations' => array( __( 'Yearly celebrations', 'cise-core' ), 'textarea', "India (Republic) Day|February\nInternational Yoga Day|June 21\nCanada Day|July 1\nSummer Camp|July\nHeritage Festival|August long weekend\nIndia (Independence) Day|August 15\nHindi Divas|September 14\nGandhi Jayanti|October 2\nConsular Camp|November", __( 'One per line: Name|When. Shown on the homepage and events page.', 'cise-core' ) ),
			),
		),
		'hall'    => array(
			'title'  => __( 'Hall booking', 'cise-core' ),
			'fields' => array(
				'booking_open'      => array( __( 'Accept booking requests', 'cise-core' ), 'checkbox', '1', '' ),
				'venue_name'        => array( __( 'Venue name', 'cise-core' ), 'text', 'India Centre', '' ),
				'hall_capacity'     => array( __( 'Capacity (guests)', 'cise-core' ), 'number', '200', '' ),
				'main_name'         => array( __( 'Hall 1 name', 'cise-core' ), 'text', 'Main Hall', '' ),
				'base_name'         => array( __( 'Hall 2 name', 'cise-core' ), 'text', 'Basement', '' ),
				'slot_am'           => array( __( 'Morning half day', 'cise-core' ), 'timerange', '08:00-15:00', __( 'Start-end, e.g. 08:00-15:00.', 'cise-core' ) ),
				'slot_pm'           => array( __( 'Evening half day', 'cise-core' ), 'timerange', '17:00-00:00', __( 'Start-end; 00:00 means midnight. A full day runs from opening to closing time.', 'cise-core' ) ),
				'rate_main_hour'    => array( __( 'Hall 1: per hour ($)', 'cise-core' ), 'money', '106', '' ),
				'price_main_am'     => array( __( 'Hall 1: morning half day ($)', 'cise-core' ), 'money', '500', '' ),
				'price_main_pm'     => array( __( 'Hall 1: evening half day ($)', 'cise-core' ), 'money', '565', '' ),
				'price_main_full'   => array( __( 'Hall 1: full day ($)', 'cise-core' ), 'money', '750', '' ),
				'rate_base_hour'    => array( __( 'Hall 2: per hour ($)', 'cise-core' ), 'money', '75', '' ),
				'price_base_am'     => array( __( 'Hall 2: morning half day ($)', 'cise-core' ), 'money', '300', '' ),
				'price_base_pm'     => array( __( 'Hall 2: evening half day ($)', 'cise-core' ), 'money', '300', '' ),
				'price_base_full'   => array( __( 'Hall 2: full day ($)', 'cise-core' ), 'money', '500', '' ),
				'price_both_half'   => array( __( 'Both halls: half day ($)', 'cise-core' ), 'money', '815', __( 'Booking both halls by the hour is charged both hourly rates added together.', 'cise-core' ) ),
				'price_both_full'   => array( __( 'Both halls: full day ($)', 'cise-core' ), 'money', '1125', __( 'The estimate always uses the cheapest option that covers the booked time. The member society discount is applied on the invoice.', 'cise-core' ) ),
				'damage_deposit'    => array( __( 'Damage deposit ($)', 'cise-core' ), 'money', '250', __( 'Shown on the booking page; collected on your Square invoice.', 'cise-core' ) ),
				'open_time'         => array( __( 'Hall available from', 'cise-core' ), 'time', '08:00', '' ),
				'close_time'        => array( __( 'Hall available until', 'cise-core' ), 'time', '00:00', __( '00:00 means midnight.', 'cise-core' ) ),
				'slot_minutes'      => array( __( 'Time steps (minutes)', 'cise-core' ), 'select:30,60', '30', '' ),
				'min_hours'         => array( __( 'Minimum booking (hours)', 'cise-core' ), 'number', '2', '' ),
				'buffer_minutes'    => array( __( 'Gap between bookings (minutes)', 'cise-core' ), 'number', '30', __( 'For cleanup and setup.', 'cise-core' ) ),
				'notice_days'       => array( __( 'Book at least this many days ahead', 'cise-core' ), 'number', '3', '' ),
				'max_months'        => array( __( 'Book up to this many months ahead', 'cise-core' ), 'number', '4', __( 'The old CISE policy: up to four months ahead.', 'cise-core' ) ),
				'closed_weekdays'   => array( __( 'Closed on', 'cise-core' ), 'weekdays', array(), '' ),
				'confirm_days'      => array( __( 'We confirm within (business days)', 'cise-core' ), 'number', '3', '' ),
				'event_types'       => array( __( 'Event types', 'cise-core' ), 'textarea', "CISE event\nMember society event\nLanguage classes\nMusic class\nDance classes\nSenior gathering\nWorkshop\nYouth program\nAGM or meeting\nWedding, birthday or family celebration\nOther", __( 'One per line.', 'cise-core' ) ),
				'invoice_note'      => array( __( 'Payment note shown to customers', 'cise-core' ), 'textarea', 'No payment is taken online. Your request holds the date while we review it. Once we confirm, we email you an invoice through Square; please pay within 14 days or the hold is released.', '' ),
			),
		),
		'award'   => array(
			'title'  => __( 'Recognition Award', 'cise-core' ),
			'fields' => array(
				'award_open'        => array( __( 'Accept nominations', 'cise-core' ), 'checkbox', '1', __( 'Nominations also close automatically after the deadline.', 'cise-core' ) ),
				'award_year'        => array( __( 'Award year', 'cise-core' ), 'number', (string) ( (int) wp_date( 'Y' ) + 1 ), '' ),
				'award_deadline'    => array( __( 'Nominations close', 'cise-core' ), 'date', '', '' ),
				'award_notified'    => array( __( 'Recipients notified', 'cise-core' ), 'date', '', '' ),
				'award_ceremony'    => array( __( 'Award ceremony', 'cise-core' ), 'date', '', '' ),
				'award_categories'  => array( __( 'Award categories', 'cise-core' ), 'textarea', "Academic excellence: high school (Grade 12)\nAcademic excellence: post-secondary\nCommunity service", __( 'One per line.', 'cise-core' ) ),
				'award_eligibility' => array( __( 'Eligibility (sidebar)', 'cise-core' ), 'textarea', "Lives in Edmonton or the surrounding area\nCurrently in Grade 12 or post-secondary\nOne nomination per person per year", __( 'One point per line.', 'cise-core' ) ),
				'associations'      => array( __( 'Member associations', 'cise-core' ), 'textarea', "Alberta Gujarati Association\nAlberta Hindi Parishad\nAsian Youth Club\nBhartiya Cultural Society of Alberta\nCanadian Kerala Cultural Association\nEdmonton Bengali Association\nEdmonton Kannada Association\nEdmonton Tamil Cultural Association\nGarvi Gujarat Association of Canada\nGujarat Cultural Society\nHindu Society of Alberta\nIndo-Canadian Women's Association\nKrishti Bengali Cultural Society of Edmonton\nManoranjan Club\nMillwoods Culture Society for Retired & Semi-Retired\nShantiniketan Society of Retired and Semi-retired\nShirdi Sai Baba Mandir\nSociety for the Education and Assistance of Rural Indian Children (SEARIC)\nTelugu Cultural Association of Edmonton\nUniversity of Alberta Indian Students Association", __( 'One per line. Used in the nomination form and the booking form.', 'cise-core' ) ),
			),
		),
		'google'  => array(
			'title'  => __( 'Google Calendar', 'cise-core' ),
			'fields' => array(
				'gcal_calendar_id'  => array( __( 'Calendar ID', 'cise-core' ), 'text', '', __( 'Google Calendar > Settings > (your calendar) > Integrate calendar > Calendar ID. Looks like abc123@group.calendar.google.com.', 'cise-core' ) ),
				'gcal_key'          => array( __( 'Service account key (JSON)', 'cise-core' ), 'secret', '', __( 'Paste the whole JSON key file. Share the calendar with the service account email and give it "Make changes to events".', 'cise-core' ) ),
				'gcal_push_pending' => array( __( 'Add pending requests to Google Calendar', 'cise-core' ), 'checkbox', '1', __( 'Shown as "PENDING:" until you confirm, so staff see requests right away. Declined requests are removed.', 'cise-core' ) ),
				'gcal_read_busy'    => array( __( 'Block times that are busy in Google Calendar', 'cise-core' ), 'checkbox', '1', __( 'Anything added directly in Google Calendar (e.g. a CISE meeting) shows as booked on the website.', 'cise-core' ) ),
			),
		),
		'mail'    => array(
			'title'  => __( 'Email (Gmail)', 'cise-core' ),
			'fields' => array(
				'gmail_user'      => array( __( 'Gmail address', 'cise-core' ), 'email', '', __( 'All website emails (booking requests, confirmations, nominations, contact messages) are sent from this Google account. Leave empty to use the host\'s mail server.', 'cise-core' ) ),
				'gmail_app_pass'  => array( __( 'App password', 'cise-core' ), 'password', '', __( 'Not the normal Google password: turn on 2-Step Verification, then create one at myaccount.google.com/apppasswords (16 letters).', 'cise-core' ) ),
				'gmail_from_name' => array( __( 'Sender name', 'cise-core' ), 'text', 'CISE Edmonton', '' ),
			),
		),
	);
}

/**
 * Get one setting (with default).
 */
function cise_core_get( $key ) {
	static $saved = null;
	if ( null === $saved ) {
		$saved = get_option( 'cise_core_settings', array() );
	}
	if ( isset( $saved[ $key ] ) && '' !== $saved[ $key ] ) {
		return $saved[ $key ];
	}
	foreach ( cise_core_fields() as $tab ) {
		if ( isset( $tab['fields'][ $key ] ) ) {
			// Checkboxes saved as unchecked are stored as '0', so a missing key means "use the default".
			return isset( $saved[ $key ] ) ? $saved[ $key ] : $tab['fields'][ $key ][2];
		}
	}
	return '';
}

/**
 * Multi-line setting as an array of non-empty lines.
 */
function cise_core_lines( $key ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) cise_core_get( $key ) ) ) ) );
}

/**
 * Whether nominations are being accepted right now.
 */
function cise_core_award_is_open() {
	if ( '1' !== (string) cise_core_get( 'award_open' ) ) {
		return false;
	}
	$deadline = cise_core_get( 'award_deadline' );
	if ( $deadline ) {
		$end = new DateTime( $deadline . ' 23:59:59', wp_timezone() );
		if ( new DateTime( 'now', wp_timezone() ) > $end ) {
			return false;
		}
	}
	return true;
}

add_action( 'admin_menu', function () {
	add_menu_page( 'CISE', 'CISE', CISE_CORE_CAP, 'cise', '__return_null', 'dashicons-groups', 25 );
	add_submenu_page( 'cise', __( 'CISE settings', 'cise-core' ), __( 'Settings', 'cise-core' ), 'manage_options', 'cise-settings', 'cise_core_settings_screen' );
	// The parent slug only exists to group the post type menus; drop its duplicate first entry.
	remove_submenu_page( 'cise', 'cise' );
}, 20 );

add_action( 'admin_init', function () {
	register_setting( 'cise_core', 'cise_core_settings', array(
		'type'              => 'array',
		'sanitize_callback' => 'cise_core_sanitize_settings',
	) );
} );

/**
 * Sanitize the posted settings. Only the submitted tab's fields are replaced.
 */
function cise_core_sanitize_settings( $input ) {
	$saved  = get_option( 'cise_core_settings', array() );
	$fields = cise_core_fields();
	$tab    = isset( $input['_tab'] ) ? sanitize_key( $input['_tab'] ) : '';
	if ( ! isset( $fields[ $tab ] ) ) {
		return $saved;
	}
	foreach ( $fields[ $tab ]['fields'] as $key => $field ) {
		$type  = $field[1];
		$value = isset( $input[ $key ] ) ? $input[ $key ] : '';
		switch ( true ) {
			case 'checkbox' === $type:
				$value = $value ? '1' : '0';
				break;
			case 'textarea' === $type:
				$value = sanitize_textarea_field( $value );
				break;
			case 'email' === $type:
				$value = implode( ', ', array_filter( array_map( 'sanitize_email', explode( ',', $value ) ) ) );
				break;
			case 'number' === $type:
				$value = '' === $value ? '' : (string) absint( $value );
				break;
			case 'money' === $type:
				$value = '' === $value ? '' : (string) round( (float) preg_replace( '/[^0-9.]/', '', $value ), 2 );
				break;
			case 'date' === $type:
				$value = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ? $value : '';
				break;
			case 'time' === $type:
				$value = preg_match( '/^\d{2}:\d{2}$/', $value ) ? $value : $field[2];
				break;
			case 'timerange' === $type:
				$value = preg_replace( '/\s+/', '', (string) $value );
				$value = preg_match( '/^\d{2}:\d{2}-\d{2}:\d{2}$/', $value ) ? $value : $field[2];
				break;
			case 'weekdays' === $type:
				$value = array_values( array_intersect( array_map( 'absint', (array) $value ), range( 0, 6 ) ) );
				break;
			case 'secret' === $type:
				// Blank means "keep what is stored"; the stored key is never echoed back.
				if ( '' === trim( $value ) ) {
					$value = isset( $saved[ $key ] ) ? $saved[ $key ] : '';
				} elseif ( '-' === trim( $value ) ) {
					$value = '';
				} else {
					// options.php has already unslashed the value; unslashing again would break the key's \n escapes.
					$json  = json_decode( $value, true );
					$value = ( is_array( $json ) && ! empty( $json['client_email'] ) && ! empty( $json['private_key'] ) ) ? wp_json_encode( $json ) : ( isset( $saved[ $key ] ) ? $saved[ $key ] : '' );
					if ( ! $json ) {
						add_settings_error( 'cise_core_settings', 'bad_json', __( 'That service account key is not valid JSON, so it was not saved.', 'cise-core' ) );
					}
				}
				break;
			case 'password' === $type:
				// Same rules as the key: blank keeps it, - removes it, and it is never echoed back.
				$value = trim( (string) $value );
				if ( '' === $value ) {
					$value = isset( $saved[ $key ] ) ? $saved[ $key ] : '';
				} elseif ( '-' === $value ) {
					$value = '';
				} else {
					// Google shows app passwords in groups of four; the spaces are not part of it.
					$value = preg_replace( '/\s+/', '', $value );
				}
				break;
			case 0 === strpos( $type, 'select:' ):
				$options = explode( ',', substr( $type, 7 ) );
				$value   = in_array( $value, $options, true ) ? $value : $field[2];
				break;
			default:
				$value = sanitize_text_field( $value );
		}
		$saved[ $key ] = $value;
	}
	delete_transient( 'cise_gcal_token' );
	return $saved;
}

function cise_core_settings_screen() {
	$fields = cise_core_fields();
	$tab    = isset( $_GET['tab'] ) && isset( $fields[ $_GET['tab'] ] ) ? sanitize_key( $_GET['tab'] ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification
	$saved  = get_option( 'cise_core_settings', array() );
	$days   = array( __( 'Sun', 'cise-core' ), __( 'Mon', 'cise-core' ), __( 'Tue', 'cise-core' ), __( 'Wed', 'cise-core' ), __( 'Thu', 'cise-core' ), __( 'Fri', 'cise-core' ), __( 'Sat', 'cise-core' ) );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'CISE settings', 'cise-core' ); ?></h1>
		<?php settings_errors( 'cise_core_settings' ); ?>
		<nav class="nav-tab-wrapper">
			<?php foreach ( $fields as $id => $def ) : ?>
				<a class="nav-tab <?php echo $id === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=cise-settings&tab=' . $id ) ); ?>"><?php echo esc_html( $def['title'] ); ?></a>
			<?php endforeach; ?>
		</nav>
		<form method="post" action="options.php">
			<?php settings_fields( 'cise_core' ); ?>
			<input type="hidden" name="cise_core_settings[_tab]" value="<?php echo esc_attr( $tab ); ?>">
			<table class="form-table" role="presentation">
				<?php
				foreach ( $fields[ $tab ]['fields'] as $key => $field ) :
					list( $label, $type, $default, $help ) = $field;
					$name  = 'cise_core_settings[' . $key . ']';
					$value = cise_core_get( $key );
					?>
					<tr>
						<th scope="row"><label for="cise-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td>
							<?php
							if ( 'checkbox' === $type ) {
								printf( '<label><input type="checkbox" id="cise-%1$s" name="%2$s" value="1" %3$s> %4$s</label>', esc_attr( $key ), esc_attr( $name ), checked( '1', (string) $value, false ), esc_html__( 'Yes', 'cise-core' ) );
							} elseif ( 'textarea' === $type ) {
								printf( '<textarea id="cise-%1$s" name="%2$s" rows="6" class="large-text">%3$s</textarea>', esc_attr( $key ), esc_attr( $name ), esc_textarea( $value ) );
							} elseif ( 'weekdays' === $type ) {
								foreach ( $days as $i => $day ) {
									printf( '<label style="margin-right:12px"><input type="checkbox" name="%1$s[]" value="%2$d" %3$s> %4$s</label>', esc_attr( $name ), (int) $i, checked( in_array( $i, array_map( 'intval', (array) $value ), true ), true, false ), esc_html( $day ) );
								}
							} elseif ( 'secret' === $type ) {
								$stored = ! empty( $saved[ $key ] ) ? json_decode( $saved[ $key ], true ) : null;
								if ( $stored ) {
									/* translators: %s: service account email */
									echo '<p><strong>' . esc_html( sprintf( __( 'Key saved for %s.', 'cise-core' ), $stored['client_email'] ) ) . '</strong> ' . esc_html__( 'Leave the box empty to keep it, paste a new key to replace it, or type - to remove it.', 'cise-core' ) . '</p>';
								}
								printf( '<textarea id="cise-%1$s" name="%2$s" rows="5" class="large-text code" autocomplete="off" placeholder="{ &quot;type&quot;: &quot;service_account&quot;, ... }"></textarea>', esc_attr( $key ), esc_attr( $name ) );
							} elseif ( 'password' === $type ) {
								if ( ! empty( $saved[ $key ] ) ) {
									echo '<p><strong>' . esc_html__( 'Saved.', 'cise-core' ) . '</strong> ' . esc_html__( 'Leave the box empty to keep it, type a new one to replace it, or type - to remove it.', 'cise-core' ) . '</p>';
								}
								printf( '<input type="password" id="cise-%1$s" name="%2$s" value="" class="regular-text" autocomplete="new-password">', esc_attr( $key ), esc_attr( $name ) );
							} elseif ( 0 === strpos( $type, 'select:' ) ) {
								printf( '<select id="cise-%1$s" name="%2$s">', esc_attr( $key ), esc_attr( $name ) );
								foreach ( explode( ',', substr( $type, 7 ) ) as $opt ) {
									printf( '<option value="%1$s" %2$s>%1$s</option>', esc_attr( $opt ), selected( $opt, (string) $value, false ) );
								}
								echo '</select>';
							} else {
								$html_type = array(
									'money'  => 'text',
									'number' => 'number',
									'date'   => 'date',
									'time'   => 'time',
									'email'  => 'text',
								);
								$t = isset( $html_type[ $type ] ) ? $html_type[ $type ] : 'text';
								printf( '<input type="%1$s" id="cise-%2$s" name="%3$s" value="%4$s" class="%5$s" %6$s>', esc_attr( $t ), esc_attr( $key ), esc_attr( $name ), esc_attr( $value ), 'text' === $t ? 'regular-text' : 'small-text" style="width:auto', 'money' === $type ? 'inputmode="decimal"' : '' );
							}
							if ( $help ) {
								echo '<p class="description">' . esc_html( $help ) . '</p>';
							}
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
			<?php submit_button(); ?>
		</form>

		<?php if ( 'google' === $tab ) : ?>
			<hr>
			<h2><?php esc_html_e( 'Connection test', 'cise-core' ); ?></h2>
			<?php
			if ( isset( $_GET['gcal_test'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				$result = cise_gcal_test();
				if ( is_wp_error( $result ) ) {
					echo '<div class="notice notice-error inline"><p>' . esc_html( $result->get_error_message() ) . '</p></div>';
				} else {
					echo '<div class="notice notice-success inline"><p>' . esc_html( $result ) . '</p></div>';
				}
			}
			?>
			<p><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=cise-settings&tab=google&gcal_test=1' ) ); ?>"><?php esc_html_e( 'Test Google Calendar connection', 'cise-core' ); ?></a></p>

			<h2><?php esc_html_e( 'Calendar feeds (no Google setup needed)', 'cise-core' ); ?></h2>
			<p><?php esc_html_e( 'Subscribe to these in Google Calendar (Other calendars > + > From URL). Google refreshes subscribed feeds every few hours, so use the service account above for instant sync.', 'cise-core' ); ?></p>
			<p><strong><?php esc_html_e( 'Hall bookings (private, staff only):', 'cise-core' ); ?></strong><br><code><?php echo esc_html( cise_core_ics_url( 'bookings' ) ); ?></code></p>
			<p><strong><?php esc_html_e( 'Public events:', 'cise-core' ); ?></strong><br><code><?php echo esc_html( cise_core_ics_url( 'events' ) ); ?></code></p>
		<?php endif; ?>

		<?php if ( 'mail' === $tab ) : ?>
			<hr>
			<h2><?php esc_html_e( 'Test email', 'cise-core' ); ?></h2>
			<?php
			if ( isset( $_GET['mail_test'] ) && check_admin_referer( 'cise_mail_test' ) ) {
				$result = cise_core_mail_test();
				if ( is_wp_error( $result ) ) {
					echo '<div class="notice notice-error inline"><p>' . esc_html( $result->get_error_message() ) . '</p></div>';
				} else {
					echo '<div class="notice notice-success inline"><p>' . esc_html( $result ) . '</p></div>';
				}
			}
			?>
			<p><?php
				/* translators: %s: staff email address(es) */
				echo esc_html( sprintf( __( 'Sends a test message to %s (General > Send notifications to).', 'cise-core' ), cise_core_staff_email() ) );
			?></p>
			<p><a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=cise-settings&tab=mail&mail_test=1' ), 'cise_mail_test' ) ); ?>"><?php esc_html_e( 'Send test email', 'cise-core' ); ?></a></p>
		<?php endif; ?>
	</div>
	<?php
}
